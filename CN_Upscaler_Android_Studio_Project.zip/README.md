# CN Upscaler (`com.cn.upscaler`)

**Professional Offline AI Image Super-Resolution Android Application**

CN Upscaler is a complete, production-oriented Android application built with **Kotlin**, **Jetpack Compose**, **Material 3**, **Room**, **WorkManager**, **AndroidX ExifInterface**, and **ONNX Runtime Android** (`com.microsoft.onnxruntime:onnxruntime-android`).

---

## Core Engineering Highlights

1. **Strict Independence of Target Resolution & AI Enhancement Level**:
   - **Target Resolution (`2K`, `4K`, `8K`, `16K` UHD)**: Governs the exact final output pixel dimensions using an orientation-aware, aspect-ratio-preserving bounding-box fit policy (`ResolutionCalculator`). Non-16:9 images are never stretched or distorted.
   - **AI Enhancement Level (`4×`, `8×`, `16×`)**: Selects the verified neural processing strategy (`EnhancementProfileResolver`), never multiplying source width/height by 4, 8, or 16.
   - Example: A `1920 × 1080` image with Target Resolution `4K UHD` and `8× AI Enhancement` outputs `3840 × 2160` (never `15360 × 8640`).
2. **Genuine On-Device AI Inference (`OnnxSuperResolutionEngine`)**:
   - Integrates **ONNX Runtime Android (`1.31.0`)** with hardware acceleration (`NNAPI` with FP16 relaxation and automatic multi-threaded `CPU` fallback).
   - Supports **Real-ESRGAN (`RealESRGAN_x4plus.onnx` / `realesr-general-x4v3.onnx`)** under the permissive **BSD 3-Clause License**.
   - **Zero Fake AI Fallback**: `OnnxModelVerifier` inspects the ONNX graph signature (`[1, 3, H, W]` -> `[1, 3, 4H, 4W]`) and SHA-256 digest before execution. If no verified `.onnx` model file is present, the app explicitly reports `ModelAvailability.Unavailable` and blocks processing rather than silently falling back to `Bitmap.createScaledBitmap`.
3. **Memory-Safe Tile-Based Super-Resolution (`TileProcessor`)**:
   - Splits large source images into configurable tiles (`128px`–`512px`, default `256px`) with configurable overlap (`16px`–`48px`, default `32px`) and reflection padding (`REFLECT_101`) to model-compatible multiples of 4.
   - Blends overlapping output tiles with a **2D raised-cosine (Hann window)** feathering kernel (`w_A + w_B = 1.0`) to eliminate grid seams.
   - Checks `coroutineContext.ensureActive()` between every tile for responsive cancellation.
4. **Queue-Driven Batch Processing & WorkManager Foreground Execution**:
   - Persistent **Room** database (`upscale_jobs`) tracks `WAITING`, `PROCESSING`, `COMPLETED`, `FAILED`, and `CANCELLED` jobs.
   - `BatchUpscaleWorker` (`CoroutineWorker`) processes one large image at a time outside the UI thread, posts live foreground notifications (`"Processing images... X / Y completed"`), isolates single-job failures so remaining jobs continue, and safely resets interrupted `PROCESSING` jobs to `WAITING` on startup recovery.
5. **Privacy-First Metadata Engine & Scoped Storage**:
   - Zero network permissions (`android.permission.INTERNET` is completely omitted from `AndroidManifest.xml`).
   - Uses Android Photo Picker (`PickVisualMedia` / `PickMultipleVisualMedia`) and `MediaStore` (`Pictures/CN_Upscaler`).
   - Writes full AI provenance (`Software=CN Upscaler`, model name/version, original & output dimensions, target resolution, enhancement profile) while stripping sensitive GPS coordinates and camera serial numbers by default.

---

## How to Open, Supply ONNX Weights, and Build

1. **Open in Android Studio**:
   Open the `CN_Upscaler` directory in **Android Studio Ladybug (2024.2.1+) or newer** with **JDK 17** and **Android SDK 35**.
2. **Supply Legally Obtained ONNX Model Weights**:
   - **Build-Time Bundling**: Place `RealESRGAN_x4plus.onnx` (and optionally `realesr-general-x4v3.onnx`) inside `app/src/main/assets/models/`.
   - **Runtime On-Device Import**: Alternatively, build and install the APK first, then open **Settings → On-Device ONNX AI Model Management → Import RealESRGAN_x4plus.onnx** to import the `.onnx` file directly from device storage.
3. **Build & Run Unit Tests**:
   ```bash
   ./gradlew testDebugUnitTest
   ./gradlew assembleDebug
   ./gradlew bundleRelease
   ```
