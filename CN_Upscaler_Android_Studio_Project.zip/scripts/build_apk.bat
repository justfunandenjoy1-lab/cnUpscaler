@echo off
echo ============================================================
echo  CN Upscaler (com.cn.upscaler) - Automated Test and APK Build
echo ============================================================

where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set GRADLE_CMD=gradle
) else (
    set GRADLE_CMD=gradlew.bat
)

echo [1/3] Running automated unit test suite (testDebugUnitTest)...
call %GRADLE_CMD% testDebugUnitTest --stacktrace
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%

echo [2/3] Compiling Debug APK (assembleDebug)...
call %GRADLE_CMD% assembleDebug --stacktrace
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%

if not exist dist mkdir dist
if exist "app\build\outputs\apk\debug\app-debug.apk" (
    copy /Y "app\build\outputs\apk\debug\app-debug.apk" "dist\CN-Upscaler-debug.apk"
    echo [3/3] SUCCESS: APK created at dist\CN-Upscaler-debug.apk
)
