#!/usr/bin/env bash
# ==============================================================================
# CN Upscaler — GitHub Upload & Automated APK Build Trigger Script
# Usage: ./scripts/push_to_github.sh https://github.com/<USERNAME>/<REPO>.git
# ==============================================================================
set -euo pipefail

REPO_URL="${1:-}"
if [ -z "$REPO_URL" ]; then
    echo "Usage: ./scripts/push_to_github.sh https://github.com/<YOUR_USERNAME>/CN-Upscaler.git"
    exit 1
fi

git init
git branch -M main
git add .
git commit -m "Initial commit: CN Upscaler Android project with GitHub Actions APK builder"
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO_URL"
git push -u origin main --force

echo "============================================================"
echo " SUCCESS! Project pushed to: $REPO_URL"
echo " Open the 'Actions' tab on your GitHub repository to watch"
echo " the build and download CN-Upscaler-debug-apk!"
echo "============================================================"
