# CN Upscaler — Phase 0 Technical Plan & Architecture Specification

## 1. Executive Summary & Environment Disclosure
**CN Upscaler** (`com.cn.upscaler`) is a production-oriented, offline-first Android application engineered in Kotlin with Jetpack Compose and Material 3 for genuine on-device AI image super-resolution, tile-based high-resolution reconstruction, queue-driven batch processing, EXIF metadata management, and privacy-preserving storage.

### Build & Execution Environment Disclosure
In accordance with the Mandatory Operating Rules (*"Never fake AI functionality. Never report an unverified build as successful. Never claim that an unsupported feature works. If the environment lacks a dependency, model, network access, Android SDK, or build tool, state the exact limitation and implement the closest technically correct solution"*):
- **Sandbox VM Environment Status**: The generation environment provides OpenJDK 17 (`17.0.20.1`), Python 3.11, NumPy, OpenCV, Pillow, SciPy, and ONNX Runtime (`1.30.0`), but has **no outbound internet access**, **no pre-installed Android SDK (`sdkmanager` / `aapt2`)**, **no standalone `kotlinc` or `gradle` binary**, and **no pre-bundled Real-ESRGAN `.onnx` weight files**.
- **Verification Strategy**:
  1. The Android Studio project is generated with a 100% standard, portable Gradle configuration (`gradle/libs.versions.toml`, `build.gradle.kts`, `settings.gradle.kts`) ready to open and build in Android Studio or via `./gradlew assembleDebug bundleRelease testDebugUnitTest` on any developer workstation with Android SDK 35+ and internet access to Google Maven / Maven Central.
  2. All core mathematical, resolution, tiling, overlap-blending, tensor preprocessing, batch queue state-machine, and metadata algorithms are mirrored and executed against a deterministic automated verification test suite (`tests/verify_all_phases.py`) in the sandbox VM, alongside complete JUnit 4 unit test classes in `app/src/test/java/com/cn/upscaler/`.
  3. Rather than inventing a fake or dummy model binary, the app implements a strict cryptographic and structural ONNX model verifier (`OnnxModelVerifier` and `OnnxSuperResolutionEngine`) that inspects both `app/src/main/assets/models/` and user-imported models in `context.filesDir/models/` (via an in-app Storage Access Framework `.onnx` model importer in Settings). When no verified ONNX model file is present, the app explicitly reports `ModelAvailability.Unavailable` and blocks fake execution rather than silently falling back to `Bitmap.createScaledBitmap`.

---

## 2. Project Architecture & Package Structure
CN Upscaler follows **MVVM with Clean Architecture principles** and unidirectional data flow (`StateFlow` + immutable `UiState` + single-shot `SharedFlow` events).

### Package Layout (`com.cn.upscaler`)
- `app`: `CnUpscalerApplication`, `MainActivity`, `CnUpscalerApp` root navigation host, manual Dependency Injection container (`AppContainer`).
- `core.common`: `AppResult`, `DispatcherProvider`, `MemoryBudgetMonitor`, formatting and file utilities.
- `core.designsystem`: Material 3 color schemes (dark/light + dynamic color support), typography, shapes, reusable components (`StatusBadge`, `ResolutionChip`, `MetricCard`, `WarningBanner`).
- `core.image`: `ImageInspector` (`inJustDecodeBounds = true` header inspection), `ImageValidationResult`, `ExifOrientationHelper`, `SafeBitmapDecoder`, `ImageEncoder` (JPEG 80–100 default 95, PNG lossless with alpha preservation, WebP lossless/lossy).
- `core.ai`:
  - `SuperResolutionModel`, `ModelCapabilities`, `ModelMetadata`, `ModelAvailability`.
  - `EnhancementLevel` (`LEVEL_4X`, `LEVEL_8X`, `LEVEL_16X` — strictly decoupled from geometric target dimensions).
  - `EnhancementProfile` & `EnhancementStrategy` (`SinglePassEnhancementStrategy`, `MultiPassEnhancementStrategy`, `UnsupportedEnhancementStrategy`).
  - `OnnxModelRegistry`, `OnnxModelVerifier`, `OnnxSuperResolutionEngine` (`com.microsoft.onnxruntime:onnxruntime-android`), `TensorPreprocessor` (`NHWC` ARGB_8888 to `NCHW` float32 RGB `[0.0, 1.0]`, mirror padding, and output tensor reconstruction), `HardwareAcceleratorManager` (NNAPI, FP16/GPU options, CPU fallback).
- `core.processing`:
  - `TargetResolution` (`UHD_2K` 2560×1440, `UHD_4K` 3840×2160, `UHD_8K` 7680×4320, `UHD_16K` 15360×8640).
  - `ResolutionCalculator` (aspect-ratio-preserving bounding-box fit policy, pixel/memory/storage estimation, safe memory warnings).
  - `TileProcessor` (configurable tile dimensions 128–512px, configurable overlap 16–64px, 2D raised-cosine / Hann window feathering to eliminate tile boundary seams, disk-backed strip/region assembly for 8K/16K outputs, per-tile cancellation).
  - `PostProcessor` (optional, explicitly labeled conventional post-processing: edge-preserving bilateral noise reduction and unsharp mask, disabled by default and never mislabeled as AI face enhancement).
  - `ImageProcessingPipeline` (end-to-end coroutine pipeline from input URI to MediaStore output).
- `core.metadata`: `MetadataEngine` (`androidx.exifinterface:exifinterface`) writing software/processing tags, dimensions, target resolution, enhancement profile, actual AI model name/version, and optional user metadata (`Title`, `Author`, `Description`, `Keywords`, `Copyright`), with privacy-first GPS/location stripping enabled by default.
- `core.storage`: `PhotoPickerContractHelper`, `SafUriPermissionManager`, `MediaStoreSaver` (scoped storage `REL_PATH = Pictures/CN_Upscaler` with `IS_PENDING` atomic publishing).
- `core.database`: Room database (`CnUpscalerDatabase`), `ProcessingJobEntity`, `ProcessingHistoryEntity`, `JobDao`, `HistoryDao`.
- `domain`: Domain models (`SelectedImage`, `UpscaleJob`, `JobStatus`, `ProcessingConfig`, `UserMetadata`, `AppSettings`) and repositories (`JobRepository`, `SettingsRepository`, `ModelRepository`).
- `data`: Repository implementations (`OfflineJobRepository`, `DataStoreSettingsRepository`, `LocalModelRepository`).
- `worker`: `BatchUpscaleWorker` (`CoroutineWorker` with foreground service notification `FOREGROUND_SERVICE_TYPE_DATA_SYNC` / media processing, progress reporting `completed / total`, and cooperative cancellation).
- `feature.home`, `feature.selection`, `feature.settings`, `feature.processing`, `feature.results`, `feature.history`, `feature.about`: Jetpack Compose screens and ViewModels.

---

## 3. Supported Android Versions & Toolchain
- **`minSdk`**: `26` (Android 8.0 Oreo — required for `Bitmap.Config.RGBA_F16`, modern `MediaStore`, `java.time`, and ONNX Runtime Android compatibility).
- **`targetSdk` / `compileSdk`**: `35` (Android 15 — full compliance with Android 14/15 foreground service types, Edge-to-Edge Compose, and Android Photo Picker).
- **Kotlin**: `2.0.21` with Official Compose Compiler plugin (`org.jetbrains.kotlin.plugin.compose`).
- **Android Gradle Plugin (AGP)**: `8.7.2` (compatible with Gradle `8.10.2` and JDK 17).
- **Dependency Injection**: Clean, zero-reflection manual DI container (`AppContainer` initialized in `CnUpscalerApplication`) to avoid KSP/Hilt annotation-processor build fragility while maintaining 100% constructor-injected testability across ViewModels, Repositories, and Workers.

---

## 4. AI Inference Framework & Model Specification
- **Inference Runtime**: **ONNX Runtime Android** (`com.microsoft.onnxruntime:onnxruntime-android:1.31.0`).
- **Primary Supported Model Architecture**: **Real-ESRGAN (`RealESRGAN_x4plus`)** (`RRDBNet`, 23 Residual-in-Residual Dense Blocks, native scale `4×`) and **Real-ESRGAN Compact (`realesr-general-x4v3`)** (`SRVGGNetCompact`, native scale `4×`).
- **Model Source**: Official upstream weights by Xintao Wang et al. (Tencent ARC Lab) at `https://github.com/xinntao/Real-ESRGAN`.
- **Model License & Redistribution**: **BSD 3-Clause "New" or "Revised" License** (`https://github.com/xinntao/Real-ESRGAN/blob/master/LICENSE`). Permits commercial and non-commercial redistribution provided copyright notice, conditions, and disclaimer are retained (included verbatim in `app/src/main/assets/models/LICENSE_REAL_ESRGAN.txt` and displayed in the About & Privacy screen).
- **Input Tensor Specification**:
  - Name: `input` (or dynamically queried first input node via `OrtSession.inputNames`).
  - Shape: `[1, 3, H, W]` (`NCHW` layout, batch size 1, 3 channels).
  - Channel Order: **RGB** (converted from Android `ARGB_8888` integers).
  - Data Type & Normalization: `FLOAT32` normalized to **`[0.0f, 1.0f]`** via `pixel_channel / 255.0f` (zero mean shift, unit scale, matching `xinntao/Real-ESRGAN` `inference_realesrgan.py`).
  - Spatial Alignment: Input tile dimensions `(H, W)` are padded via reflection padding (`BorderMode.REFLECT_101`) to a multiple of `4` (plus configurable tile overlap) prior to inference.
- **Output Tensor Specification**:
  - Shape: `[1, 3, H * 4, W * 4]` (`NCHW` layout, native `4×` spatial upsampling).
  - Value Range: `FLOAT32` in `[0.0f, 1.0f]`, clamped via `value.coerceIn(0.0f, 1.0f)` and quantized to 8-bit `[0, 255]` (`(value * 255.0f + 0.5f).toInt()`).

---

## 5. Independence of Target Resolution & AI Enhancement Level
### A. Target Resolution (`ResolutionCalculator`)
Controls **only** the desired final output pixel dimensions:
- `2K UHD`: `2560 × 1440` (16:9 reference)
- `4K UHD`: `3840 × 2160` (16:9 reference)
- `8K UHD`: `7680 × 4320` (16:9 reference)
- `16K UHD`: `15360 × 8640` (16:9 reference)
- **Non-16:9 Aspect Ratio Preservation Policy (Bounding-Box Fit with Orientation Normalization)**:
  For any input `(srcW, srcH)`, the reference bounding box is normalized to match the input's orientation (landscape/square uses `(refLong, refShort)`; portrait uses `(refShort, refLong)` so a 9:16 portrait image targeting 4K UHD resolves to `2160 × 3840` rather than being constrained to 1215 × 2160). Within that oriented bounding box `(maxW, maxH)`, the scale factor is `scale = min(maxW.toDouble() / srcW, maxH.toDouble() / srcH)`, producing `outW = max(1, round(srcW * scale))` and `outH = max(1, round(srcH * scale))`. Aspect ratio is preserved with zero stretching or distortion.

### B. AI Enhancement Level (`EnhancementProfile`)
Controls **only** the verified AI processing strategy, never multiplying input dimensions by 4, 8, or 16:
- **`4× AI Enhancement` (`SinglePassEnhancementStrategy`)**: Runs 1 pass of the verified native 4× super-resolution model (`RealESRGAN_x4plus.onnx` or `realesr-general-x4v3.onnx`), followed by high-quality Lanczos-3 / Mitchell-Netravali resampling (`Bitmap.createScaledBitmap` / bicubic accumulator) to fit the exact Target Resolution.
- **`8× AI Enhancement` (`MultiPassEnhancementStrategy` or Dual-Model Cascade)**: Requires either a dedicated secondary detail-refinement model (`realesr-general-x4v3.onnx` + `RealESRGAN_x4plus.onnx`) or a verified 2-stage tiled inference pass with intermediate downsampling to prevent memory explosion. If only a single model is installed and multi-pass is disabled or unsupported by device memory budget, this profile explicitly reports its availability status and refuses to fake a distinct quality level.
- **`16× AI Enhancement` (`UnsupportedEnhancementStrategy` / Extreme Multi-Pass Verification)**: Because no single mobile ONNX super-resolution model genuinely reconstructs 16× authentic high-frequency detail without hallucination or severe compounding artifacts, CN Upscaler marks `16× AI Enhancement` as **Unavailable (`UnsupportedByInstalledModel`)** unless an explicit 16× multi-stage model pack is registered and verified. The UI transparently explains why `16× AI Enhancement` is disabled rather than fabricating quality differences.
