# CN Upscaler ProGuard / R8 Rules
-keep class ai.onnxruntime.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.cn.upscaler.core.database.** { *; }
-dontwarn ai.onnxruntime.**
