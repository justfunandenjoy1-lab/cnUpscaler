package com.cn.upscaler.core.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EnhancementProfileTest {

    private val resolver = EnhancementProfileResolver()

    @Test
    fun `when no model is installed all profiles are marked unsupported honestly`() {
        val caps = ModelCapabilities(
            primaryModelAvailable = false,
            primaryModelId = "realesrgan_x4plus",
            primaryModelName = "Real-ESRGAN x4plus",
            primaryModelVersion = "v0.1.0",
            primaryNativeScale = 4,
            secondaryRefinementModelAvailable = false,
            secondaryModelId = null,
            supportsMultiPass8xProfile = false,
            supportsExtreme16xProfile = false
        )
        val profiles = resolver.resolveProfiles(caps)
        assertTrue(profiles.all { !it.isAvailable })
    }

    @Test
    fun `with verified 4x model 4x and 8x are resolved while 16x is honestly reported unsupported`() {
        val caps = ModelCapabilities(
            primaryModelAvailable = true,
            primaryModelId = "realesrgan_x4plus",
            primaryModelName = "Real-ESRGAN x4plus",
            primaryModelVersion = "v0.1.0",
            primaryNativeScale = 4,
            secondaryRefinementModelAvailable = false,
            secondaryModelId = "realesrgan_x4plus",
            supportsMultiPass8xProfile = true,
            supportsExtreme16xProfile = false
        )
        val p4x = resolver.resolveProfile(EnhancementLevel.LEVEL_4X, caps)
        val p8x = resolver.resolveProfile(EnhancementLevel.LEVEL_8X, caps)
        val p16x = resolver.resolveProfile(EnhancementLevel.LEVEL_16X, caps)

        assertTrue(p4x.isAvailable)
        assertTrue(p4x.strategy is EnhancementStrategy.SinglePassEnhancementStrategy)

        assertTrue(p8x.isAvailable)
        assertTrue(p8x.strategy is EnhancementStrategy.MultiPassEnhancementStrategy)

        assertFalse(p16x.isAvailable)
        assertTrue(p16x.strategy is EnhancementStrategy.UnsupportedEnhancementStrategy)
    }
}
