package com.cn.upscaler.feature.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cn.upscaler.core.image.SafeBitmapDecoder
import com.cn.upscaler.domain.model.JobStatus
import com.cn.upscaler.domain.model.UpscaleJob
import com.cn.upscaler.feature.processing.BatchJobCard

@Composable
fun HistoryScreen(
    historyJobs: List<UpscaleJob>,
    bitmapDecoder: SafeBitmapDecoder,
    onOpenResult: (String) -> Unit,
    onRetryJob: (String) -> Unit,
    onDeleteJob: (String) -> Unit,
    onClearHistory: () -> Unit
) {
    var filterStatus by remember { mutableStateOf<JobStatus?>(null) }
    val filtered = remember(historyJobs, filterStatus) {
        if (filterStatus == null) historyJobs else historyJobs.filter { it.status == filterStatus }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Local Processing History (${historyJobs.size})", style = MaterialTheme.typography.titleLarge)
            if (historyJobs.isNotEmpty()) {
                OutlinedButton(onClick = onClearHistory) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear")
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = filterStatus == null,
                onClick = { filterStatus = null },
                label = { Text("All") }
            )
            listOf(JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED).forEach { status ->
                FilterChip(
                    selected = filterStatus == status,
                    onClick = { filterStatus = status },
                    label = { Text(status.name) }
                )
            }
        }

        if (filtered.isEmpty()) {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "No history entries match the selected filter.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.id }) { job ->
                    BatchJobCard(
                        job = job,
                        bitmapDecoder = bitmapDecoder,
                        onCancel = { onDeleteJob(job.id) },
                        onRetry = { onRetryJob(job.id) },
                        onClick = { onOpenResult(job.id) }
                    )
                }
            }
        }
    }
}
