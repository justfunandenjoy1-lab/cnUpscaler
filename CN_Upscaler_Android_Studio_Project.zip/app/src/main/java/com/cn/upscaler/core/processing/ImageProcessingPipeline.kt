package com.cn.upscaler.core.processing

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.ai.EnhancementProfileResolver
import com.cn.upscaler.core.ai.EnhancementStrategy
import com.cn.upscaler.core.ai.ExecutionProviderPreference
import com.cn.upscaler.core.ai.OnnxModelVerifier
import com.cn.upscaler.core.ai.OnnxSuperResolutionEngine
import com.cn.upscaler.core.common.AppResult
import com.cn.upscaler.core.common.DispatcherProvider
import com.cn.upscaler.core.common.ErrorCode
import com.cn.upscaler.core.common.MemoryBudgetMonitor
import com.cn.upscaler.core.image.EncodingConfig
import com.cn.upscaler.core.image.ImageEncoder
import com.cn.upscaler.core.image.ImageInspectionReport
import com.cn.upscaler.core.image.ImageInspector
import com.cn.upscaler.core.image.ImageValidationResult
import com.cn.upscaler.core.image.SafeBitmapDecoder
import com.cn.upscaler.core.metadata.MetadataEngine
import com.cn.upscaler.core.metadata.MetadataWriteReport
import com.cn.upscaler.core.metadata.ProcessingProvenanceMetadata
import com.cn.upscaler.core.metadata.UserMetadataConfig
import com.cn.upscaler.core.storage.MediaStoreSaver
import com.cn.upscaler.core.storage.SavedMediaOutput
import java.io.File
import kotlin.coroutines.coroutineContext
import kotlin.math.roundToInt
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

enum class PipelineStage(val displayName: String, val baseProgress: Float) {
    INSPECTING("Inspecting image header & bounds", 0.03f),
    VALIDATING_MODEL("Verifying AI model & enhancement profile", 0.06f),
    DECODING("Decoding source image & normalizing orientation", 0.10f),
    AI_INFERENCE_PASS_1("Running tiled AI super-resolution inference", 0.15f),
    AI_INFERENCE_PASS_2("Running secondary AI refinement pass", 0.55f),
    RESOLUTION_FITTING("Fitting output to target resolution", 0.82f),
    POST_PROCESSING("Applying optional post-processing", 0.88f),
    ENCODING("Encoding output image", 0.92f),
    WRITING_METADATA("Writing provenance & EXIF metadata", 0.96f),
    SAVING_MEDIASTORE("Publishing to device gallery", 0.98f),
    COMPLETED("Completed", 1.00f)
}

data class PipelineProgressUpdate(
    val stage: PipelineStage,
    val overallProgress: Float, // 0.0f..1.0f
    val completedTiles: Int = 0,
    val totalTiles: Int = 0,
    val detailMessage: String = stage.displayName
)

data class PipelineJobRequest(
    val jobId: String,
    val inputUri: Uri,
    val targetResolution: TargetResolution,
    val enhancementLevel: EnhancementLevel,
    val preferredModelId: String,
    val executionProvider: ExecutionProviderPreference,
    val tileConfig: TileConfig,
    val encodingConfig: EncodingConfig,
    val postProcessingConfig: PostProcessingConfig,
    val userMetadataConfig: UserMetadataConfig,
    val enableMultiPass8x: Boolean = true
)

data class PipelineExecutionSummary(
    val jobId: String,
    val inspectionReport: ImageInspectionReport,
    val resolutionPlan: ResolutionPlan,
    val appliedStrategy: EnhancementStrategy,
    val activeExecutionProvider: String,
    val savedMedia: SavedMediaOutput,
    val metadataReport: MetadataWriteReport,
    val durationMillis: Long,
    val warnings: List<String>
)

/**
 * Implements the 14-step conceptual processing pipeline completely decoupled from
 * Activities, ViewModels, and Composable functions.
 */
class ImageProcessingPipeline(
    private val context: Context,
    private val dispatchers: DispatcherProvider,
    private val memoryMonitor: MemoryBudgetMonitor,
    private val imageInspector: ImageInspector,
    private val bitmapDecoder: SafeBitmapDecoder,
    private val modelVerifier: OnnxModelVerifier,
    private val onnxEngine: OnnxSuperResolutionEngine,
    private val profileResolver: EnhancementProfileResolver,
    private val metadataEngine: MetadataEngine,
    private val mediaStoreSaver: MediaStoreSaver
) {
    suspend fun execute(
        request: PipelineJobRequest,
        onProgress: suspend (PipelineProgressUpdate) -> Unit
    ): AppResult<PipelineExecutionSummary> = withContext(dispatchers.default) {
        val startTime = System.currentTimeMillis()
        val accumulatedWarnings = mutableListOf<String>()

        try {
            // Stage 1: Image inspection & validation
            coroutineContext.ensureActive()
            onProgress(PipelineProgressUpdate(PipelineStage.INSPECTING, PipelineStage.INSPECTING.baseProgress))
            val validation = withContext(dispatchers.io) {
                imageInspector.inspect(request.inputUri)
            }
            if (validation is ImageValidationResult.Invalid) {
                return@withContext AppResult.Error(
                    message = validation.reason,
                    errorCode = validation.errorCode
                )
            }
            val report = (validation as ImageValidationResult.Valid).report
            accumulatedWarnings += validation.warnings

            // Stage 2: Verify AI model availability and EnhancementProfile
            coroutineContext.ensureActive()
            onProgress(PipelineProgressUpdate(PipelineStage.VALIDATING_MODEL, PipelineStage.VALIDATING_MODEL.baseProgress))
            val availability = withContext(dispatchers.io) {
                modelVerifier.verifyInstalledModels(request.preferredModelId)
            }
            val capabilities = modelVerifier.resolveCapabilities(
                availability = availability,
                enableMultiPass8x = request.enableMultiPass8x
            )
            if (!capabilities.primaryModelAvailable) {
                val unavailableReason = (availability as? com.cn.upscaler.core.ai.ModelAvailability.Unavailable)?.reason
                    ?: "AI Super-Resolution model is unavailable."
                return@withContext AppResult.Error(
                    message = unavailableReason,
                    errorCode = ErrorCode.MODEL_UNAVAILABLE
                )
            }

            val profile = profileResolver.resolveProfile(request.enhancementLevel, capabilities)
            if (!profile.isAvailable) {
                return@withContext AppResult.Error(
                    message = profile.strategy.limitationNotice ?: "Selected AI Enhancement Level is not supported by the installed model.",
                    errorCode = ErrorCode.UNSUPPORTED_ENHANCEMENT_PROFILE
                )
            }
            profile.strategy.limitationNotice?.let { accumulatedWarnings += it }

            // Calculate Target Resolution plan (strictly independent of EnhancementLevel)
            val resolutionPlan = ResolutionCalculator.calculate(
                sourceWidth = report.orientedWidth,
                sourceHeight = report.orientedHeight,
                target = request.targetResolution,
                outputFormat = request.encodingConfig.format,
                nativeModelScale = capabilities.primaryNativeScale,
                tileSize = request.tileConfig.tileSize,
                availableHeapBytes = memoryMonitor.getMaxHeapBytes()
            )
            accumulatedWarnings += resolutionPlan.warnings

            if (resolutionPlan.exceedsMaximumSupportedOutput) {
                val altNames = resolutionPlan.supportedAlternatives.joinToString(", ") { it.shortLabel }
                return@withContext AppResult.Error(
                    message = "Requested target resolution (${request.targetResolution.shortLabel}: ${resolutionPlan.outputWidth}×${resolutionPlan.outputHeight}) exceeds safe device memory limits. Supported alternatives: ${altNames.ifEmpty { "2K UHD" }}.",
                    errorCode = ErrorCode.DIMENSION_LIMIT_EXCEEDED
                )
            }

            // Stage 3: Safe decoding & EXIF orientation normalization
            coroutineContext.ensureActive()
            onProgress(PipelineProgressUpdate(PipelineStage.DECODING, PipelineStage.DECODING.baseProgress))
            val decodedResult = withContext(dispatchers.io) {
                bitmapDecoder.decodeForProcessing(request.inputUri, report)
            }
            if (decodedResult is AppResult.Error) {
                return@withContext decodedResult
            }
            val sourceBitmap = (decodedResult as AppResult.Success).data
            val srcW = sourceBitmap.width
            val srcH = sourceBitmap.height
            val srcArgb = IntArray(srcW * srcH)
            sourceBitmap.getPixels(srcArgb, 0, srcW, 0, 0, srcW, srcH)
            sourceBitmap.recycle()

            val preserveAlpha = report.hasAlpha && request.encodingConfig.format.supportsTransparency

            // Stage 4: Genuine ONNX AI Super-Resolution (Tiled)
            coroutineContext.ensureActive()
            var currentArgb: IntArray
            var currentW: Int
            var currentH: Int
            var activeProviderName = "CPUExecutionProvider"

            when (val strategy = profile.strategy) {
                is EnhancementStrategy.SinglePassEnhancementStrategy -> {
                    onnxEngine.openSession(
                        preferredModelId = strategy.modelId,
                        executionPreference = request.executionProvider
                    ).use { session ->
                        activeProviderName = session.activeProviderReport.activeProviderName
                        if (session.activeProviderReport.fellBackToCpu && session.activeProviderReport.fallbackReason != null) {
                            accumulatedWarnings += session.activeProviderReport.fallbackReason
                        }
                        val scale = session.modelSpec.nativeScale
                        currentArgb = TileProcessor.processTiledImage(
                            srcArgb = srcArgb,
                            srcWidth = srcW,
                            srcHeight = srcH,
                            preserveAlpha = preserveAlpha,
                            config = request.tileConfig,
                            session = session,
                            onTileProgress = { done, total ->
                                val frac = done.toFloat() / total.coerceAtLeast(1)
                                onProgress(
                                    PipelineProgressUpdate(
                                        stage = PipelineStage.AI_INFERENCE_PASS_1,
                                        overallProgress = 0.15f + frac * 0.65f,
                                        completedTiles = done,
                                        totalTiles = total,
                                        detailMessage = "AI Super-Resolution tile $done of $total"
                                    )
                                )
                            }
                        )
                        currentW = srcW * scale
                        currentH = srcH * scale
                    }
                }

                is EnhancementStrategy.MultiPassEnhancementStrategy -> {
                    // Pass 1
                    val pass1W: Int
                    val pass1H: Int
                    val pass1Pixels: IntArray
                    onnxEngine.openSession(
                        preferredModelId = strategy.firstPassModelId,
                        executionPreference = request.executionProvider
                    ).use { session1 ->
                        activeProviderName = session1.activeProviderReport.activeProviderName
                        val scale1 = session1.modelSpec.nativeScale
                        pass1Pixels = TileProcessor.processTiledImage(
                            srcArgb = srcArgb,
                            srcWidth = srcW,
                            srcHeight = srcH,
                            preserveAlpha = preserveAlpha,
                            config = request.tileConfig,
                            session = session1,
                            onTileProgress = { done, total ->
                                val frac = done.toFloat() / total.coerceAtLeast(1)
                                onProgress(
                                    PipelineProgressUpdate(
                                        stage = PipelineStage.AI_INFERENCE_PASS_1,
                                        overallProgress = 0.15f + frac * 0.35f,
                                        completedTiles = done,
                                        totalTiles = total,
                                        detailMessage = "Pass 1/2: AI Super-Resolution tile $done of $total"
                                    )
                                )
                            }
                        )
                        pass1W = srcW * scale1
                        pass1H = srcH * scale1
                    }

                    // Intermediate anti-aliased conditioning before Pass 2 to stay within memory limits
                    val condW = (pass1W * strategy.intermediateDownsampleFactor).roundToInt().coerceAtLeast(16)
                    val condH = (pass1H * strategy.intermediateDownsampleFactor).roundToInt().coerceAtLeast(16)
                    val condPixels = resizeArgbBilinear(pass1Pixels, pass1W, pass1H, condW, condH)

                    // Pass 2
                    onnxEngine.openSession(
                        preferredModelId = strategy.secondPassModelId,
                        executionPreference = request.executionProvider
                    ).use { session2 ->
                        val scale2 = session2.modelSpec.nativeScale
                        currentArgb = TileProcessor.processTiledImage(
                            srcArgb = condPixels,
                            srcWidth = condW,
                            srcHeight = condH,
                            preserveAlpha = preserveAlpha,
                            config = request.tileConfig,
                            session = session2,
                            onTileProgress = { done, total ->
                                val frac = done.toFloat() / total.coerceAtLeast(1)
                                onProgress(
                                    PipelineProgressUpdate(
                                        stage = PipelineStage.AI_INFERENCE_PASS_2,
                                        overallProgress = 0.50f + frac * 0.30f,
                                        completedTiles = done,
                                        totalTiles = total,
                                        detailMessage = "Pass 2/2: AI Detail Refinement tile $done of $total"
                                    )
                                )
                            }
                        )
                        currentW = condW * scale2
                        currentH = condH * scale2
                    }
                }

                is EnhancementStrategy.UnsupportedEnhancementStrategy -> {
                    return@withContext AppResult.Error(
                        message = strategy.reason,
                        errorCode = ErrorCode.UNSUPPORTED_ENHANCEMENT_PROFILE
                    )
                }
            }

            // Stage 5: Final Target Resolution Fitting
            coroutineContext.ensureActive()
            onProgress(PipelineProgressUpdate(PipelineStage.RESOLUTION_FITTING, PipelineStage.RESOLUTION_FITTING.baseProgress))
            val targetW = resolutionPlan.outputWidth
            val targetH = resolutionPlan.outputHeight
            if (currentW != targetW || currentH != targetH) {
                currentArgb = resizeArgbBilinear(currentArgb, currentW, currentH, targetW, targetH)
                currentW = targetW
                currentH = targetH
            }

            // Stage 6: Optional Post-Processing (only when explicitly enabled by user)
            coroutineContext.ensureActive()
            if (request.postProcessingConfig.isActive) {
                onProgress(PipelineProgressUpdate(PipelineStage.POST_PROCESSING, PipelineStage.POST_PROCESSING.baseProgress))
                currentArgb = PostProcessor.apply(currentArgb, currentW, currentH, request.postProcessingConfig)
            }

            // Stage 7: Output Encoding to temporary file
            coroutineContext.ensureActive()
            onProgress(PipelineProgressUpdate(PipelineStage.ENCODING, PipelineStage.ENCODING.baseProgress))
            val outputBitmap = Bitmap.createBitmap(currentW, currentH, Bitmap.Config.ARGB_8888)
            outputBitmap.setPixels(currentArgb, 0, currentW, 0, 0, currentW, currentH)

            val tempDir = File(context.cacheDir, "encoded_outputs").apply { mkdirs() }
            val ext = request.encodingConfig.format.fileExtension
            val tempFile = File(tempDir, "cn_upscaled_${request.jobId}.$ext")

            val encodeResult = withContext(dispatchers.io) {
                try {
                    ImageEncoder.encodeToFile(
                        bitmap = outputBitmap,
                        destFile = tempFile,
                        config = request.encodingConfig,
                        sourceHasAlpha = report.hasAlpha
                    )
                } finally {
                    outputBitmap.recycle()
                }
            }
            if (encodeResult is AppResult.Error) {
                tempFile.delete()
                return@withContext encodeResult
            }
            val encodedVerification = (encodeResult as AppResult.Success).data
            encodedVerification.transparencyDiscardedWarning?.let { accumulatedWarnings += it }

            // Stage 8: Metadata Engine
            coroutineContext.ensureActive()
            onProgress(PipelineProgressUpdate(PipelineStage.WRITING_METADATA, PipelineStage.WRITING_METADATA.baseProgress))
            val provenance = ProcessingProvenanceMetadata(
                originalWidth = report.orientedWidth,
                originalHeight = report.orientedHeight,
                outputWidth = encodedVerification.verifiedWidth,
                outputHeight = encodedVerification.verifiedHeight,
                targetResolution = request.targetResolution,
                enhancementLevel = request.enhancementLevel,
                actualModelName = capabilities.primaryModelName,
                actualModelVersion = capabilities.primaryModelVersion,
                actualProcessingStages = buildString {
                    append(profile.strategy.stagesDescription)
                    if (request.postProcessingConfig.isActive) {
                        append(" -> Post: ").append(request.postProcessingConfig.describeActiveOperations())
                    }
                }
            )
            val metadataReport = withContext(dispatchers.io) {
                metadataEngine.writeMetadata(
                    sourceUri = request.inputUri,
                    outputFile = tempFile,
                    outputFormat = request.encodingConfig.format,
                    provenance = provenance,
                    userMetadata = request.userMetadataConfig
                )
            }

            // Stage 9: Publish to MediaStore Gallery
            coroutineContext.ensureActive()
            onProgress(PipelineProgressUpdate(PipelineStage.SAVING_MEDIASTORE, PipelineStage.SAVING_MEDIASTORE.baseProgress))
            val baseName = report.filename.substringBeforeLast('.').ifBlank { "image" }
            val desiredOutputName = "${baseName}_CN_${request.targetResolution.id}_${request.enhancementLevel.id}.$ext"
            val saveResult = withContext(dispatchers.io) {
                mediaStoreSaver.saveToGallery(
                    sourceFile = tempFile,
                    displayName = desiredOutputName,
                    format = request.encodingConfig.format
                )
            }
            tempFile.delete()

            if (saveResult is AppResult.Error) {
                return@withContext saveResult
            }
            val savedMedia = (saveResult as AppResult.Success).data

            onProgress(PipelineProgressUpdate(PipelineStage.COMPLETED, 1.0f))
            val durationMillis = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)

            AppResult.Success(
                PipelineExecutionSummary(
                    jobId = request.jobId,
                    inspectionReport = report,
                    resolutionPlan = resolutionPlan,
                    appliedStrategy = profile.strategy,
                    activeExecutionProvider = activeProviderName,
                    savedMedia = savedMedia,
                    metadataReport = metadataReport,
                    durationMillis = durationMillis,
                    warnings = accumulatedWarnings.distinct()
                )
            )
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (oom: OutOfMemoryError) {
            System.gc()
            AppResult.Error(
                message = "Out of memory during high-resolution processing. Reduce tile size in Settings or choose a lower Target Resolution.",
                cause = oom,
                errorCode = ErrorCode.INSUFFICIENT_MEMORY
            )
        } catch (t: Throwable) {
            AppResult.Error(
                message = "Processing failed: ${t.message}",
                cause = t,
                errorCode = ErrorCode.INFERENCE_FAILED
            )
        }
    }

    companion object {
        /**
         * Pure JVM/Kotlin bilinear ARGB_8888 resampler used for exact TargetResolution fitting
         * after neural super-resolution.
         */
        fun resizeArgbBilinear(
            src: IntArray,
            srcW: Int,
            srcH: Int,
            dstW: Int,
            dstH: Int
        ): IntArray {
            if (srcW == dstW && srcH == dstH) return src
            val dst = IntArray(dstW * dstH)
            val xRatio = if (dstW > 1) (srcW - 1).toFloat() / (dstW - 1).toFloat() else 0f
            val yRatio = if (dstH > 1) (srcH - 1).toFloat() / (dstH - 1).toFloat() else 0f

            for (y in 0 until dstH) {
                val gy = y * yRatio
                val y0 = gy.toInt().coerceIn(0, srcH - 1)
                val y1 = (y0 + 1).coerceIn(0, srcH - 1)
                val wy = gy - y0
                val oneMinusWy = 1f - wy

                val row0 = y0 * srcW
                val row1 = y1 * srcW
                val dstRow = y * dstW

                for (x in 0 until dstW) {
                    val gx = x * xRatio
                    val x0 = gx.toInt().coerceIn(0, srcW - 1)
                    val x1 = (x0 + 1).coerceIn(0, srcW - 1)
                    val wx = gx - x0
                    val oneMinusWx = 1f - wx

                    val p00 = src[row0 + x0]
                    val p01 = src[row0 + x1]
                    val p10 = src[row1 + x0]
                    val p11 = src[row1 + x1]

                    val w00 = oneMinusWx * oneMinusWy
                    val w01 = wx * oneMinusWy
                    val w10 = oneMinusWx * wy
                    val w11 = wx * wy

                    val a = (((p00 ushr 24) and 0xFF) * w00 + ((p01 ushr 24) and 0xFF) * w01 +
                        ((p10 ushr 24) and 0xFF) * w10 + ((p11 ushr 24) and 0xFF) * w11).roundToInt().coerceIn(0, 255)
                    val r = (((p00 ushr 16) and 0xFF) * w00 + ((p01 ushr 16) and 0xFF) * w01 +
                        ((p10 ushr 16) and 0xFF) * w10 + ((p11 ushr 16) and 0xFF) * w11).roundToInt().coerceIn(0, 255)
                    val g = (((p00 ushr 8) and 0xFF) * w00 + ((p01 ushr 8) and 0xFF) * w01 +
                        ((p10 ushr 8) and 0xFF) * w10 + ((p11 ushr 8) and 0xFF) * w11).roundToInt().coerceIn(0, 255)
                    val b = ((p00 and 0xFF) * w00 + (p01 and 0xFF) * w01 +
                        (p10 and 0xFF) * w10 + (p11 and 0xFF) * w11).roundToInt().coerceIn(0, 255)

                    dst[dstRow + x] = (a shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
            return dst
        }
    }
}
