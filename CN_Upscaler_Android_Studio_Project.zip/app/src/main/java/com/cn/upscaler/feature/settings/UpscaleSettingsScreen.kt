package com.cn.upscaler.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cn.upscaler.app.MainUiState
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.common.MemoryBudgetMonitor
import com.cn.upscaler.core.designsystem.MetricPill
import com.cn.upscaler.core.designsystem.WarningBanner
import com.cn.upscaler.core.designsystem.formatBytes
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.metadata.UserMetadataConfig
import com.cn.upscaler.core.processing.ResolutionCalculator
import com.cn.upscaler.core.processing.TargetResolution
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UpscaleSettingsScreen(
    uiState: MainUiState,
    memoryMonitor: MemoryBudgetMonitor,
    onSelectTargetResolution: (TargetResolution) -> Unit,
    onSelectEnhancementLevel: (EnhancementLevel) -> Unit,
    onUpdateOutputFormat: (ImageFormat, Int) -> Unit,
    onUpdateUserMetadata: (UserMetadataConfig) -> Unit,
    onStartBatchProcessing: () -> Unit
) {
    val validCandidates = uiState.selectedCandidates.filter { it.isValid }
    val primaryReport = validCandidates.firstOrNull()?.inspectionReport
    val currentSettings = uiState.settings

    val samplePlan = remember(
        primaryReport,
        currentSettings.defaultTargetResolution,
        currentSettings.defaultOutputFormat,
        currentSettings.tileSize
    ) {
        if (primaryReport != null) {
            ResolutionCalculator.calculate(
                sourceWidth = primaryReport.orientedWidth,
                sourceHeight = primaryReport.orientedHeight,
                target = currentSettings.defaultTargetResolution,
                outputFormat = currentSettings.defaultOutputFormat,
                nativeModelScale = uiState.modelCapabilities.primaryNativeScale,
                tileSize = currentSettings.tileSize,
                availableHeapBytes = memoryMonitor.getMaxHeapBytes()
            )
        } else {
            ResolutionCalculator.calculate(
                sourceWidth = 1920,
                sourceHeight = 1080,
                target = currentSettings.defaultTargetResolution,
                outputFormat = currentSettings.defaultOutputFormat,
                nativeModelScale = 4,
                tileSize = currentSettings.tileSize,
                availableHeapBytes = memoryMonitor.getMaxHeapBytes()
            )
        }
    }

    val activeProfile = uiState.enhancementProfiles.find {
        it.level == currentSettings.defaultEnhancementLevel
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Upscale & AI Profile Configuration",
            style = MaterialTheme.typography.titleLarge
        )

        // Section A: Target Resolution
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "1. Target Output Resolution (Final Dimensions)",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Determines exact final output pixel dimensions while preserving the original aspect ratio without stretching.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TargetResolution.entries.forEach { target ->
                        FilterChip(
                            selected = currentSettings.defaultTargetResolution == target,
                            onClick = { onSelectTargetResolution(target) },
                            label = { Text(target.label) }
                        )
                    }
                }
            }
        }

        // Section B: AI Enhancement Level (Independent of Target Resolution)
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "2. AI Enhancement Level (Neural Processing Profile)",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Selects the AI inference strategy. Does NOT multiply output dimensions by 4, 8, or 16.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EnhancementLevel.entries.forEach { level ->
                        val profile = uiState.enhancementProfiles.find { it.level == level }
                        val supported = profile?.isAvailable ?: false
                        FilterChip(
                            selected = currentSettings.defaultEnhancementLevel == level,
                            onClick = { onSelectEnhancementLevel(level) },
                            enabled = supported,
                            label = { Text(level.displayName) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                if (activeProfile != null) {
                    Text(
                        text = "Active Pipeline Strategy: ${activeProfile.strategy.stagesDescription}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    activeProfile.strategy.limitationNotice?.let { notice ->
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = notice,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                val unavailable16x = uiState.enhancementProfiles.find { it.level == EnhancementLevel.LEVEL_16X }
                if (unavailable16x != null && !unavailable16x.isAvailable) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Why 16× is disabled: ${unavailable16x.strategy.limitationNotice}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Section C: Live Resolution & Memory Calculation Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (primaryReport != null) {
                        "Calculated Output Preview (${primaryReport.filename})"
                    } else {
                        "Calculated Output Preview (1920 × 1080 Reference)"
                    },
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricPill("Original", "${samplePlan.sourceWidth} × ${samplePlan.sourceHeight}")
                    MetricPill("Target", samplePlan.targetResolution.shortLabel)
                    MetricPill("Final Output", "${samplePlan.outputWidth} × ${samplePlan.outputHeight}")
                    MetricPill(
                        "Pixel Count",
                        String.format("%.2f MP", samplePlan.estimatedOutputPixels / 1_000_000.0)
                    )
                    MetricPill("Est. File Size", formatBytes(samplePlan.estimatedStorageBytes))
                    MetricPill("Est. Peak RAM", formatBytes(samplePlan.estimatedPeakMemoryBytes))
                }
                if (samplePlan.warnings.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    WarningBanner(
                        title = "Resolution & Memory Advisories",
                        messages = samplePlan.warnings
                    )
                }
            }
        }

        // Section D: Output Encoding Format & Quality
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("3. Output Encoding Format", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ImageFormat.JPEG, ImageFormat.PNG, ImageFormat.WEBP).forEach { fmt ->
                        FilterChip(
                            selected = currentSettings.defaultOutputFormat == fmt,
                            onClick = { onUpdateOutputFormat(fmt, currentSettings.jpegQuality) },
                            label = { Text(fmt.displayName) }
                        )
                    }
                }
                if (currentSettings.defaultOutputFormat == ImageFormat.JPEG) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "JPEG Quality: ${currentSettings.jpegQuality} (Default: 95, Range: 80–100. Higher quality reduces compression artifacts but does not create additional image detail.)",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Slider(
                        value = currentSettings.jpegQuality.toFloat(),
                        onValueChange = {
                            onUpdateOutputFormat(ImageFormat.JPEG, it.roundToInt().coerceIn(80, 100))
                        },
                        valueRange = 80f..100f,
                        steps = 19
                    )
                }
                if (validCandidates.any { it.inspectionReport?.hasAlpha == true } &&
                    !currentSettings.defaultOutputFormat.supportsTransparency
                ) {
                    WarningBanner(
                        title = "Transparency Flattening Warning",
                        messages = listOf(
                            "One or more selected images contain alpha transparency. JPEG does not support transparency; select PNG or WebP to preserve alpha channels."
                        )
                    )
                }
            }
        }

        // Section E: Metadata & Privacy Controls
        MetadataEditorCard(
            config = currentSettings.userMetadataConfig,
            onUpdate = onUpdateUserMetadata
        )

        Button(
            onClick = onStartBatchProcessing,
            enabled = validCandidates.isNotEmpty() &&
                uiState.modelCapabilities.primaryModelAvailable &&
                !samplePlan.exceedsMaximumSupportedOutput &&
                (activeProfile?.isAvailable == true),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Start AI Super-Resolution (${validCandidates.size} image${if (validCandidates.size == 1) "" else "s"})",
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun MetadataEditorCard(
    config: UserMetadataConfig,
    onUpdate: (UserMetadataConfig) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("4. Metadata & Privacy Engine", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "Writes Software=CN Upscaler, AI model provenance, and dimensions. Strips GPS location by default.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = config.stripSensitiveLocationMetadata,
                    onCheckedChange = {
                        onUpdate(config.copy(stripSensitiveLocationMetadata = it))
                    }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            FilterChip(
                selected = expanded,
                onClick = { expanded = !expanded },
                label = { Text(if (expanded) "Hide Optional User Metadata Fields" else "Edit Optional Title / Author / Copyright") }
            )
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = config.title,
                    onValueChange = { onUpdate(config.copy(title = it)) },
                    label = { Text("Title") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = config.author,
                    onValueChange = { onUpdate(config.copy(author = it)) },
                    label = { Text("Author / Artist") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = config.description,
                    onValueChange = { onUpdate(config.copy(description = it)) },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = config.keywords,
                    onValueChange = { onUpdate(config.copy(keywords = it)) },
                    label = { Text("Keywords (comma-separated)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = config.copyright,
                    onValueChange = { onUpdate(config.copy(copyright = it)) },
                    label = { Text("Copyright") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
