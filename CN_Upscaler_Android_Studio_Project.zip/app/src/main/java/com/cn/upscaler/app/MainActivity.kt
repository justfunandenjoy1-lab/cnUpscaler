package com.cn.upscaler.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.cn.upscaler.core.ai.SupportedModelCatalog
import com.cn.upscaler.core.designsystem.CnUpscalerTheme
import com.cn.upscaler.feature.about.AboutPrivacyScreen
import com.cn.upscaler.feature.history.HistoryScreen
import com.cn.upscaler.feature.home.HomeScreen
import com.cn.upscaler.feature.processing.ProcessingScreen
import com.cn.upscaler.feature.results.ResultsScreen
import com.cn.upscaler.feature.selection.ImageSelectionScreen
import com.cn.upscaler.feature.settings.AppSettingsScreen
import com.cn.upscaler.feature.settings.UpscaleSettingsScreen

object CnRoutes {
    const val HOME = "home"
    const val SELECTION = "selection"
    const val UPSCALE_SETTINGS = "upscale_settings"
    const val PROCESSING = "processing"
    const val RESULTS = "results"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        MainViewModel.provideFactory(application as CnUpscalerApplication)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as CnUpscalerApplication).container

        setContent {
            val uiState by viewModel.uiState.collectAsState()
            CnUpscalerTheme(themeMode = uiState.settings.themeMode) {
                CnUpscalerRootScreen(
                    uiState = uiState,
                    viewModel = viewModel,
                    container = container
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CnUpscalerRootScreen(
    uiState: MainUiState,
    viewModel: MainViewModel,
    container: AppContainer
) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    var pendingModelTargetId by remember { mutableStateOf(SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.id) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    val singlePhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.onImagesPicked(listOf(uri))
            navController.navigate(CnRoutes.SELECTION) { launchSingleTop = true }
        }
    }

    val multiPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.onImagesPicked(uris)
            navController.navigate(CnRoutes.SELECTION) { launchSingleTop = true }
        }
    }

    val onnxModelFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importOnnxModel(uri, pendingModelTargetId)
        }
    }

    LaunchedEffect(uiState.statusBannerMessage) {
        val msg = uiState.statusBannerMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBannerMessage()
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: CnRoutes.HOME

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("CN Upscaler") },
                actions = {
                    IconButton(onClick = { navController.navigate(CnRoutes.ABOUT) }) {
                        Icon(Icons.Default.Info, contentDescription = "About & Privacy")
                    }
                    IconButton(onClick = { navController.navigate(CnRoutes.SETTINGS) }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                val navItems = listOf(
                    Triple(CnRoutes.HOME, "Home", Icons.Default.Home),
                    Triple(CnRoutes.SELECTION, "Select", Icons.Default.Collections),
                    Triple(CnRoutes.PROCESSING, "Queue", Icons.Default.Memory),
                    Triple(CnRoutes.HISTORY, "History", Icons.Default.History),
                    Triple(CnRoutes.SETTINGS, "Settings", Icons.Default.Settings)
                )
                navItems.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = currentRoute == route,
                        onClick = {
                            navController.navigate(route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = CnRoutes.HOME,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(CnRoutes.HOME) {
                HomeScreen(
                    uiState = uiState,
                    bitmapDecoder = container.bitmapDecoder,
                    onAddImagesClick = {
                        multiPhotoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onSelectTargetResolution = viewModel::updateTargetResolution,
                    onSelectEnhancementLevel = viewModel::updateEnhancementLevel,
                    onOpenProcessingQueue = { navController.navigate(CnRoutes.PROCESSING) },
                    onOpenResult = { jobId ->
                        viewModel.focusResultJob(jobId)
                        navController.navigate(CnRoutes.RESULTS)
                    },
                    onOpenHistory = { navController.navigate(CnRoutes.HISTORY) },
                    onOpenSettings = { navController.navigate(CnRoutes.SETTINGS) },
                    onOpenAbout = { navController.navigate(CnRoutes.ABOUT) }
                )
            }

            composable(CnRoutes.SELECTION) {
                ImageSelectionScreen(
                    candidates = uiState.selectedCandidates,
                    bitmapDecoder = container.bitmapDecoder,
                    onPickSingleImage = {
                        singlePhotoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickMultipleImages = {
                        multiPhotoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onRemoveCandidate = viewModel::removeCandidate,
                    onClearSelection = viewModel::clearSelection,
                    onProceedToSettings = { navController.navigate(CnRoutes.UPSCALE_SETTINGS) }
                )
            }

            composable(CnRoutes.UPSCALE_SETTINGS) {
                UpscaleSettingsScreen(
                    uiState = uiState,
                    memoryMonitor = container.memoryMonitor,
                    onSelectTargetResolution = viewModel::updateTargetResolution,
                    onSelectEnhancementLevel = viewModel::updateEnhancementLevel,
                    onUpdateOutputFormat = viewModel::updateOutputFormat,
                    onUpdateUserMetadata = viewModel::updateUserMetadata,
                    onStartBatchProcessing = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        viewModel.enqueueSelectedBatch {
                            navController.navigate(CnRoutes.PROCESSING)
                        }
                    }
                )
            }

            composable(CnRoutes.PROCESSING) {
                ProcessingScreen(
                    uiState = uiState,
                    bitmapDecoder = container.bitmapDecoder,
                    onCancelJob = viewModel::cancelJob,
                    onCancelAll = viewModel::cancelAllJobs,
                    onRetryJob = viewModel::retryJob,
                    onOpenResult = { jobId ->
                        viewModel.focusResultJob(jobId)
                        navController.navigate(CnRoutes.RESULTS)
                    }
                )
            }

            composable(CnRoutes.RESULTS) {
                val job = uiState.historyJobs.find { it.id == uiState.focusedResultJobId }
                    ?: uiState.historyJobs.firstOrNull()
                ResultsScreen(
                    job = job,
                    bitmapDecoder = container.bitmapDecoder,
                    onShare = viewModel::shareOutput,
                    onOpenExternal = viewModel::openOutput
                )
            }

            composable(CnRoutes.HISTORY) {
                HistoryScreen(
                    historyJobs = uiState.historyJobs,
                    bitmapDecoder = container.bitmapDecoder,
                    onOpenResult = { jobId ->
                        viewModel.focusResultJob(jobId)
                        navController.navigate(CnRoutes.RESULTS)
                    },
                    onRetryJob = viewModel::retryJob,
                    onDeleteJob = viewModel::deleteHistoryJob,
                    onClearHistory = viewModel::clearHistory
                )
            }

            composable(CnRoutes.SETTINGS) {
                AppSettingsScreen(
                    uiState = uiState,
                    onImportModelClick = { modelId ->
                        pendingModelTargetId = modelId
                        onnxModelFilePicker.launch(arrayOf("*/*"))
                    },
                    onRefreshModels = viewModel::refreshModelStatus,
                    onUpdateExecutionProvider = viewModel::updateExecutionProvider,
                    onUpdateTileSettings = viewModel::updateTileSettings,
                    onUpdatePostProcessing = viewModel::updatePostProcessing,
                    onUpdateThemeMode = viewModel::updateThemeMode
                )
            }

            composable(CnRoutes.ABOUT) {
                AboutPrivacyScreen()
            }
        }
    }
}
