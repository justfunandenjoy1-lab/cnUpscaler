package com.cn.upscaler.app

import android.content.Context
import com.cn.upscaler.core.ai.EnhancementProfileResolver
import com.cn.upscaler.core.ai.OnnxModelVerifier
import com.cn.upscaler.core.ai.OnnxSuperResolutionEngine
import com.cn.upscaler.core.common.DispatcherProvider
import com.cn.upscaler.core.common.MemoryBudgetMonitor
import com.cn.upscaler.core.common.StandardDispatcherProvider
import com.cn.upscaler.core.database.CnUpscalerDatabase
import com.cn.upscaler.core.image.ImageInspector
import com.cn.upscaler.core.image.SafeBitmapDecoder
import com.cn.upscaler.core.metadata.MetadataEngine
import com.cn.upscaler.core.processing.ImageProcessingPipeline
import com.cn.upscaler.core.storage.MediaStoreSaver
import com.cn.upscaler.core.storage.SafUriPermissionManager
import com.cn.upscaler.data.repository.JobRepository
import com.cn.upscaler.data.repository.SettingsRepository

/**
 * Clean, constructor-injected Application Dependency Container.
 */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val dispatchers: DispatcherProvider = StandardDispatcherProvider()
    val memoryMonitor = MemoryBudgetMonitor()

    val safUriPermissionManager = SafUriPermissionManager(appContext)
    val imageInspector = ImageInspector(appContext, memoryMonitor)
    val bitmapDecoder = SafeBitmapDecoder(appContext, memoryMonitor)
    val mediaStoreSaver = MediaStoreSaver(appContext)
    val metadataEngine = MetadataEngine(appContext)

    val modelVerifier = OnnxModelVerifier(appContext)
    val profileResolver = EnhancementProfileResolver()
    val onnxEngine = OnnxSuperResolutionEngine(modelVerifier)

    val database = CnUpscalerDatabase.create(appContext)
    val jobRepository = JobRepository(database.jobDao())
    val settingsRepository = SettingsRepository(appContext)

    val imageProcessingPipeline = ImageProcessingPipeline(
        context = appContext,
        dispatchers = dispatchers,
        memoryMonitor = memoryMonitor,
        imageInspector = imageInspector,
        bitmapDecoder = bitmapDecoder,
        modelVerifier = modelVerifier,
        onnxEngine = onnxEngine,
        profileResolver = profileResolver,
        metadataEngine = metadataEngine,
        mediaStoreSaver = mediaStoreSaver
    )
}
