package com.cn.upscaler.core.ai

/**
 * Complete technical documentation and runtime specification for supported
 * on-device ONNX super-resolution models.
 */
enum class ColorChannelOrder {
    RGB,
    BGR
}

enum class TensorLayout {
    NCHW,
    NHWC
}

data class SuperResolutionModelSpec(
    val id: String,
    val displayName: String,
    val filename: String,
    val version: String,
    val architecture: String,
    val sourceUrl: String,
    val licenseName: String,
    val redistributionConditions: String,
    val inferenceFramework: String = "ONNX Runtime Android (com.microsoft.onnxruntime:onnxruntime-android)",
    val nativeScale: Int = 4,
    val inputLayout: TensorLayout = TensorLayout.NCHW,
    val channelOrder: ColorChannelOrder = ColorChannelOrder.RGB,
    val inputChannels: Int = 3,
    val normalizationMin: Float = 0.0f,
    val normalizationMax: Float = 1.0f,
    val outputMin: Float = 0.0f,
    val outputMax: Float = 1.0f,
    val spatialAlignmentMultiple: Int = 4,
    val defaultTileSize: Int = 256,
    val defaultTileOverlap: Int = 32,
    val limitations: List<String>
)

object SupportedModelCatalog {

    val REAL_ESRGAN_X4_PLUS = SuperResolutionModelSpec(
        id = "realesrgan_x4plus",
        displayName = "Real-ESRGAN x4plus (RRDBNet)",
        filename = "RealESRGAN_x4plus.onnx",
        version = "v0.1.0",
        architecture = "RRDBNet (23 Residual-in-Residual Dense Blocks, nf=64, gc=32)",
        sourceUrl = "https://github.com/xinntao/Real-ESRGAN",
        licenseName = "BSD 3-Clause "New" or "Revised" License",
        redistributionConditions = "Permits source and binary redistribution (including commercial use) provided copyright notice, BSD-3-Clause conditions, and disclaimer are retained in documentation.",
        nativeScale = 4,
        inputLayout = TensorLayout.NCHW,
        channelOrder = ColorChannelOrder.RGB,
        inputChannels = 3,
        normalizationMin = 0.0f,
        normalizationMax = 1.0f,
        outputMin = 0.0f,
        outputMax = 1.0f,
        spatialAlignmentMultiple = 4,
        defaultTileSize = 256,
        defaultTileOverlap = 32,
        limitations = listOf(
            "Native spatial upsampling factor is strictly 4x; non-4x target resolutions require post-inference bicubic/Lanczos resampling.",
            "High compute intensity (23 RRDB blocks); large images must be processed sequentially in overlapping tiles to prevent OutOfMemoryError.",
            "Does not include a dedicated facial landmark restoration network (such as GFPGAN); extreme low-resolution faces are reconstructed as general textures.",
            "Does not natively process an alpha channel; transparency is separated prior to RGB inference, upscaled via bicubic interpolation, and recombined."
        )
    )

    val REAL_ESR_GENERAL_X4_V3 = SuperResolutionModelSpec(
        id = "realesr_general_x4v3",
        displayName = "Real-ESRGAN General x4v3 (Compact SRVGGNet)",
        filename = "realesr-general-x4v3.onnx",
        version = "v0.2.5.0",
        architecture = "SRVGGNetCompact (32 Conv + PReLU layers + PixelShuffle 4x)",
        sourceUrl = "https://github.com/xinntao/Real-ESRGAN",
        licenseName = "BSD 3-Clause "New" or "Revised" License",
        redistributionConditions = "Permits source and binary redistribution provided copyright notice, BSD-3-Clause conditions, and disclaimer are retained.",
        nativeScale = 4,
        inputLayout = TensorLayout.NCHW,
        channelOrder = ColorChannelOrder.RGB,
        inputChannels = 3,
        normalizationMin = 0.0f,
        normalizationMax = 1.0f,
        outputMin = 0.0f,
        outputMax = 1.0f,
        spatialAlignmentMultiple = 4,
        defaultTileSize = 256,
        defaultTileOverlap = 32,
        limitations = listOf(
            "Compact VGG-style architecture trades peak micro-texture synthesis for 3-5x faster mobile inference speed.",
            "Native spatial scale is 4x; outputs larger than 4x source dimensions do not gain additional neural detail from final resizing."
        )
    )

    val ALL_SPECS: List<SuperResolutionModelSpec> = listOf(
        REAL_ESRGAN_X4_PLUS,
        REAL_ESR_GENERAL_X4_V3
    )

    fun findById(id: String): SuperResolutionModelSpec =
        ALL_SPECS.find { it.id == id } ?: REAL_ESRGAN_X4_PLUS
}
