package com.cn.upscaler.feature.selection

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cn.upscaler.core.designsystem.AsyncUriThumbnail
import com.cn.upscaler.core.designsystem.MetricPill
import com.cn.upscaler.core.designsystem.formatBytes
import com.cn.upscaler.core.image.SafeBitmapDecoder
import com.cn.upscaler.domain.model.SelectedImageCandidate

@Composable
fun ImageSelectionScreen(
    candidates: List<SelectedImageCandidate>,
    bitmapDecoder: SafeBitmapDecoder,
    onPickSingleImage: () -> Unit,
    onPickMultipleImages: () -> Unit,
    onRemoveCandidate: (String) -> Unit,
    onClearSelection: () -> Unit,
    onProceedToSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Image Selection (${candidates.size} selected)",
            style = MaterialTheme.typography.titleLarge
        )
        Text(
            text = "Select JPEG, PNG, or WebP images via Android Photo Picker. Bounds, EXIF orientation, transparency, and memory footprint are validated without full-resolution heap allocation.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onPickSingleImage,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Single")
            }
            Button(
                onClick = onPickMultipleImages,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Batch")
            }
        }

        if (candidates.isEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "No images selected yet",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Tap "Add Single" or "Add Batch" to pick images from your device.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(candidates, key = { it.id }) { item ->
                    CandidateInspectionCard(
                        item = item,
                        bitmapDecoder = bitmapDecoder,
                        onRemove = { onRemoveCandidate(item.id) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onClearSelection,
                    modifier = Modifier.weight(0.4f)
                ) {
                    Icon(Icons.Default.ClearAll, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear")
                }
                Button(
                    onClick = onProceedToSettings,
                    enabled = candidates.any { it.isValid },
                    modifier = Modifier.weight(0.6f)
                ) {
                    Text("Configure Upscale (${candidates.count { it.isValid }})")
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(Icons.Default.ArrowForward, contentDescription = null)
                }
            }
        }
    }
}

@Composable
private fun CandidateInspectionCard(
    item: SelectedImageCandidate,
    bitmapDecoder: SafeBitmapDecoder,
    onRemove: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncUriThumbnail(
                    uriString = item.uriString,
                    decoder = bitmapDecoder,
                    modifier = Modifier.size(72.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    val report = item.inspectionReport
                    Text(
                        text = report?.filename ?: "Unreadable Image URI",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (report != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            MetricPill("Dimensions", "${report.orientedWidth} × ${report.orientedHeight}")
                            MetricPill("Format", report.format.displayName)
                            MetricPill("Size", formatBytes(report.fileSizeBytes))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Ratio: ${report.aspectRatioLabel} • Alpha: ${if (report.hasAlpha) "Yes" else "No"} • Decoded RAM: ${formatBytes(report.decodedMemoryBytes)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else if (item.validationError != null) {
                        Text(
                            text = item.validationError,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                IconButton(onClick = onRemove) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Remove image")
                }
            }
            if (item.validationWarnings.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                item.validationWarnings.forEach { w ->
                    Text(
                        text = "Note: $w",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}
