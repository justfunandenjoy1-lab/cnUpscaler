package com.cn.upscaler.core.ai

import ai.onnxruntime.NodeInfo
import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

sealed interface ModelAvailability {
    data class Available(
        val spec: SuperResolutionModelSpec,
        val modelFile: File,
        val sha256Digest: String,
        val fileSizeBytes: Long,
        val inputTensorName: String,
        val outputTensorName: String,
        val inputShapeDescription: String,
        val outputShapeDescription: String,
        val secondaryModelAvailable: Boolean
    ) : ModelAvailability

    data class Unavailable(
        val expectedSpecs: List<SuperResolutionModelSpec>,
        val checkedLocations: List<String>,
        val reason: String
    ) : ModelAvailability
}

/**
 * Verifies whether a genuine, usable ONNX super-resolution model is present on-device.
 * Never fabricates model availability and never allows silent fallback to Bitmap resizing.
 */
class OnnxModelVerifier(
    private val context: Context
) {
    private val modelsDir: File
        get() = File(context.filesDir, "models").apply { mkdirs() }

    /**
     * Checks app-private storage (`filesDir/models/`) and APK `assets/models/` for a genuine
     * ONNX model matching `SupportedModelCatalog`, and validates its ONNX graph signature.
     */
    fun verifyInstalledModels(preferredModelId: String = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.id): ModelAvailability {
        val checkedPaths = mutableListOf<String>()
        val orderedSpecs = SupportedModelCatalog.ALL_SPECS.sortedByDescending { it.id == preferredModelId }

        // First sync any bundled asset models to filesDir/models/ if present in assets
        syncAssetsIfBundled()

        val verifiedModels = mutableListOf<Pair<SuperResolutionModelSpec, File>>()
        for (spec in orderedSpecs) {
            val candidate = File(modelsDir, spec.filename)
            checkedPaths += candidate.absolutePath
            checkedPaths += "assets://models/${spec.filename}"
            if (candidate.exists() && candidate.isFile && candidate.length() > 16_384L) {
                verifiedModels += spec to candidate
            }
        }

        if (verifiedModels.isEmpty()) {
            return ModelAvailability.Unavailable(
                expectedSpecs = SupportedModelCatalog.ALL_SPECS,
                checkedLocations = checkedPaths,
                reason = "No genuine ONNX super-resolution model file found in app storage or bundled assets. " +
                    "Place RealESRGAN_x4plus.onnx or realesr-general-x4v3.onnx in app/src/main/assets/models/ " +
                    "or import a legally obtained .onnx model via Settings -> AI Model Management."
            )
        }

        val (primarySpec, primaryFile) = verifiedModels.first()
        return inspectOnnxGraphSignature(
            spec = primarySpec,
            modelFile = primaryFile,
            hasSecondaryModel = verifiedModels.size > 1
        )
    }

    /**
     * Imports a user-selected `.onnx` model file via Storage Access Framework and verifies its
     * ONNX graph input/output tensor signature before accepting it.
     */
    fun importModelFromUri(uri: Uri, targetSpec: SuperResolutionModelSpec): ModelAvailability {
        val tempFile = File(modelsDir, "${targetSpec.filename}.tmp")
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                }
            } ?: return ModelAvailability.Unavailable(
                expectedSpecs = listOf(targetSpec),
                checkedLocations = listOf(uri.toString()),
                reason = "Unable to open selected model URI."
            )

            if (tempFile.length() < 16_384L) {
                tempFile.delete()
                return ModelAvailability.Unavailable(
                    expectedSpecs = listOf(targetSpec),
                    checkedLocations = listOf(uri.toString()),
                    reason = "Selected file is too small (${tempFile.length()} bytes) to be a genuine ONNX super-resolution model."
                )
            }

            val destFile = File(modelsDir, targetSpec.filename)
            if (destFile.exists()) destFile.delete()
            if (!tempFile.renameTo(destFile)) {
                tempFile.copyTo(destFile, overwrite = true)
                tempFile.delete()
            }

            val verification = inspectOnnxGraphSignature(
                spec = targetSpec,
                modelFile = destFile,
                hasSecondaryModel = false
            )
            if (verification is ModelAvailability.Unavailable) {
                destFile.delete()
            }
            return verification
        } catch (t: Throwable) {
            tempFile.delete()
            return ModelAvailability.Unavailable(
                expectedSpecs = listOf(targetSpec),
                checkedLocations = listOf(uri.toString()),
                reason = "Failed to import ONNX model: ${t.message}"
            )
        }
    }

    fun resolveCapabilities(
        availability: ModelAvailability,
        enableMultiPass8x: Boolean = true
    ): ModelCapabilities {
        return when (availability) {
            is ModelAvailability.Available -> ModelCapabilities(
                primaryModelAvailable = true,
                primaryModelId = availability.spec.id,
                primaryModelName = availability.spec.displayName,
                primaryModelVersion = availability.spec.version,
                primaryNativeScale = availability.spec.nativeScale,
                secondaryRefinementModelAvailable = availability.secondaryModelAvailable,
                secondaryModelId = if (availability.secondaryModelAvailable) {
                    SupportedModelCatalog.ALL_SPECS.firstOrNull { it.id != availability.spec.id }?.id
                } else {
                    availability.spec.id
                },
                supportsMultiPass8xProfile = enableMultiPass8x,
                supportsExtreme16xProfile = false // Strictly false: no single 4x RRDBNet model supports authentic 16x synthesis
            )
            is ModelAvailability.Unavailable -> ModelCapabilities(
                primaryModelAvailable = false,
                primaryModelId = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.id,
                primaryModelName = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.displayName,
                primaryModelVersion = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.version,
                primaryNativeScale = 4,
                secondaryRefinementModelAvailable = false,
                secondaryModelId = null,
                supportsMultiPass8xProfile = false,
                supportsExtreme16xProfile = false
            )
        }
    }

    private fun syncAssetsIfBundled() {
        try {
            val assetFiles = context.assets.list("models")?.toSet().orEmpty()
            for (spec in SupportedModelCatalog.ALL_SPECS) {
                val targetFile = File(modelsDir, spec.filename)
                if (!targetFile.exists() && spec.filename in assetFiles) {
                    context.assets.open("models/${spec.filename}").use { input ->
                        FileOutputStream(targetFile).use { output ->
                            input.copyTo(output, bufferSize = 64 * 1024)
                        }
                    }
                }
            }
        } catch (_: Throwable) {
            // Asset folder may not contain bundled binary weights yet
        }
    }

    private fun inspectOnnxGraphSignature(
        spec: SuperResolutionModelSpec,
        modelFile: File,
        hasSecondaryModel: Boolean
    ): ModelAvailability {
        return try {
            val env = OrtEnvironment.getEnvironment()
            val sessionOptions = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(1)
            }
            env.createSession(modelFile.absolutePath, sessionOptions).use { session ->
                val inputEntry: Map.Entry<String, NodeInfo> = session.inputInfo.entries.firstOrNull()
                    ?: return ModelAvailability.Unavailable(
                        expectedSpecs = listOf(spec),
                        checkedLocations = listOf(modelFile.absolutePath),
                        reason = "ONNX model has no input nodes."
                    )
                val outputEntry: Map.Entry<String, NodeInfo> = session.outputInfo.entries.firstOrNull()
                    ?: return ModelAvailability.Unavailable(
                        expectedSpecs = listOf(spec),
                        checkedLocations = listOf(modelFile.absolutePath),
                        reason = "ONNX model has no output nodes."
                    )

                val inputInfo = inputEntry.value.info as? TensorInfo
                    ?: return ModelAvailability.Unavailable(
                        expectedSpecs = listOf(spec),
                        checkedLocations = listOf(modelFile.absolutePath),
                        reason = "ONNX model primary input is not a Tensor."
                    )
                val outputInfo = outputEntry.value.info as? TensorInfo
                    ?: return ModelAvailability.Unavailable(
                        expectedSpecs = listOf(spec),
                        checkedLocations = listOf(modelFile.absolutePath),
                        reason = "ONNX model primary output is not a Tensor."
                    )

                if (inputInfo.type != OnnxJavaType.FLOAT && inputInfo.type != OnnxJavaType.FLOAT16) {
                    return ModelAvailability.Unavailable(
                        expectedSpecs = listOf(spec),
                        checkedLocations = listOf(modelFile.absolutePath),
                        reason = "Unsupported input tensor element type: ${inputInfo.type} (expected FLOAT)."
                    )
                }

                if (inputInfo.shape.size != 4 || outputInfo.shape.size != 4) {
                    return ModelAvailability.Unavailable(
                        expectedSpecs = listOf(spec),
                        checkedLocations = listOf(modelFile.absolutePath),
                        reason = "Invalid tensor rank: input rank=${inputInfo.shape.size}, output rank=${outputInfo.shape.size} (expected 4D NCHW [1, 3, H, W])."
                    )
                }

                val sha256 = computeSha256Prefix(modelFile)
                ModelAvailability.Available(
                    spec = spec,
                    modelFile = modelFile,
                    sha256Digest = sha256,
                    fileSizeBytes = modelFile.length(),
                    inputTensorName = inputEntry.key,
                    outputTensorName = outputEntry.key,
                    inputShapeDescription = inputInfo.shape.joinToString(prefix = "[", postfix = "]"),
                    outputShapeDescription = outputInfo.shape.joinToString(prefix = "[", postfix = "]"),
                    secondaryModelAvailable = hasSecondaryModel
                )
            }
        } catch (t: Throwable) {
            ModelAvailability.Unavailable(
                expectedSpecs = listOf(spec),
                checkedLocations = listOf(modelFile.absolutePath),
                reason = "ONNX Runtime failed to verify model graph (${modelFile.name}): ${t.message}"
            )
        }
    }

    private fun computeSha256Prefix(file: File): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { stream ->
                val buffer = ByteArray(64 * 1024)
                var read = stream.read(buffer)
                var totalRead = 0L
                // Hash up to first 4 MB for fast UI responsiveness while identifying weights uniquely
                while (read > 0 && totalRead < 4L * 1024L * 1024L) {
                    digest.update(buffer, 0, read)
                    totalRead += read
                    read = stream.read(buffer)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }.take(16)
        } catch (_: Throwable) {
            "unknown"
        }
    }
}
