package com.cn.upscaler.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface JobDao {

    @Query("SELECT * FROM upscale_jobs ORDER BY createdAtMillis DESC")
    fun observeAllJobs(): Flow<List<JobEntity>>

    @Query("SELECT * FROM upscale_jobs WHERE statusName IN ('WAITING', 'PROCESSING') ORDER BY createdAtMillis ASC")
    fun observeActiveQueue(): Flow<List<JobEntity>>

    @Query("SELECT * FROM upscale_jobs WHERE statusName IN ('COMPLETED', 'FAILED', 'CANCELLED') ORDER BY COALESCE(completionTimeMillis, createdAtMillis) DESC")
    fun observeHistory(): Flow<List<JobEntity>>

    @Query("SELECT * FROM upscale_jobs WHERE id = :jobId LIMIT 1")
    suspend fun getJobById(jobId: String): JobEntity?

    @Query("SELECT * FROM upscale_jobs WHERE statusName = 'WAITING' ORDER BY createdAtMillis ASC LIMIT 1")
    suspend fun getNextWaitingJob(): JobEntity?

    @Query("SELECT COUNT(*) FROM upscale_jobs WHERE statusName = 'WAITING'")
    suspend fun countWaitingJobs(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJobs(jobs: List<JobEntity>)

    @Update
    suspend fun updateJob(job: JobEntity)

    @Query("UPDATE upscale_jobs SET statusName = 'CANCELLED', currentStageText = 'Cancelled by user', completionTimeMillis = :nowMillis WHERE id = :jobId AND statusName IN ('WAITING', 'PROCESSING')")
    suspend fun cancelJobById(jobId: String, nowMillis: Long)

    @Query("UPDATE upscale_jobs SET statusName = 'CANCELLED', currentStageText = 'Batch cancelled by user', completionTimeMillis = :nowMillis WHERE statusName IN ('WAITING', 'PROCESSING')")
    suspend fun cancelAllPendingAndActive(nowMillis: Long)

    /**
     * Phase 14 requirement: If a partially processed image cannot be resumed safely after
     * process death, restart the affected job rather than reporting false progress.
     */
    @Query("UPDATE upscale_jobs SET statusName = 'WAITING', progress = 0.0, currentStageText = 'Queued (restarted after interruption)', startTimeMillis = NULL WHERE statusName = 'PROCESSING'")
    suspend fun resetInterruptedProcessingJobsToWaiting(): Int

    @Query("DELETE FROM upscale_jobs WHERE id = :jobId")
    suspend fun deleteJobById(jobId: String)

    @Query("DELETE FROM upscale_jobs WHERE statusName IN ('COMPLETED', 'FAILED', 'CANCELLED')")
    suspend fun clearFinishedHistory()
}
