package com.cn.upscaler.core.processing

import com.cn.upscaler.domain.model.JobStatus
import com.cn.upscaler.domain.model.UpscaleJob

/**
 * Pure, deterministic Batch Queue Engine (Phase 13) used both by unit tests and runtime coordination.
 *
 * Guarantees:
 * 1. Strict FIFO queue ordering for WAITING jobs.
 * 2. Maximum of 1 active PROCESSING job at a time to protect device RAM during high-res inference.
 * 3. Fault isolation: when an active job transitions to FAILED, all previously COMPLETED outputs
 *    are preserved and subsequent WAITING jobs remain eligible for processing.
 * 4. Individual job cancellation (both WAITING and PROCESSING jobs) and safe retry transitions.
 */
class BatchQueueStateMachine(
    initialJobs: List<UpscaleJob> = emptyList()
) {
    private val jobs = LinkedHashMap<String, UpscaleJob>()

    init {
        for (job in initialJobs) {
            jobs[job.id] = job
        }
    }

    @Synchronized
    fun snapshot(): List<UpscaleJob> = jobs.values.toList()

    @Synchronized
    fun enqueue(newJobs: List<UpscaleJob>) {
        for (job in newJobs) {
            jobs[job.id] = job.copy(
                status = JobStatus.WAITING,
                progress = 0f,
                currentStageText = "Waiting in queue",
                errorDetails = null
            )
        }
    }

    @Synchronized
    fun pollNextWaitingJob(nowMillis: Long): UpscaleJob? {
        // Enforce single active job concurrency limit
        val currentlyProcessing = jobs.values.any { it.status == JobStatus.PROCESSING }
        if (currentlyProcessing) return null

        val next = jobs.values
            .filter { it.status == JobStatus.WAITING }
            .minByOrNull { it.createdAtMillis }
            ?: return null

        val started = next.copy(
            status = JobStatus.PROCESSING,
            progress = 0.01f,
            currentStageText = "Starting AI super-resolution...",
            startTimeMillis = nowMillis,
            completionTimeMillis = null,
            errorDetails = null
        )
        jobs[started.id] = started
        return started
    }

    @Synchronized
    fun updateProgress(jobId: String, progress: Float, stageText: String): UpscaleJob? {
        val existing = jobs[jobId] ?: return null
        if (existing.status != JobStatus.PROCESSING) return existing
        val updated = existing.copy(
            progress = progress.coerceIn(0f, 1f),
            currentStageText = stageText
        )
        jobs[jobId] = updated
        return updated
    }

    @Synchronized
    fun markCompleted(
        jobId: String,
        outputUriString: String,
        outputWidth: Int,
        outputHeight: Int,
        outputFileSizeBytes: Long,
        actualModelName: String,
        actualModelVersion: String,
        actualStages: String,
        activeProvider: String,
        warningsSummary: String?,
        nowMillis: Long
    ): UpscaleJob? {
        val existing = jobs[jobId] ?: return null
        val completed = existing.copy(
            status = JobStatus.COMPLETED,
            progress = 1.0f,
            currentStageText = "Completed",
            outputUriString = outputUriString,
            outputWidth = outputWidth,
            outputHeight = outputHeight,
            outputFileSizeBytes = outputFileSizeBytes,
            actualModelName = actualModelName,
            actualModelVersion = actualModelVersion,
            actualProcessingStages = actualStages,
            activeExecutionProvider = activeProvider,
            warningsSummary = warningsSummary,
            completionTimeMillis = nowMillis,
            errorDetails = null
        )
        jobs[jobId] = completed
        return completed
    }

    @Synchronized
    fun markFailed(jobId: String, errorMessage: String, nowMillis: Long): UpscaleJob? {
        val existing = jobs[jobId] ?: return null
        val failed = existing.copy(
            status = JobStatus.FAILED,
            currentStageText = "Failed",
            errorDetails = errorMessage,
            completionTimeMillis = nowMillis
        )
        jobs[jobId] = failed
        return failed
    }

    @Synchronized
    fun cancelJob(jobId: String, nowMillis: Long): UpscaleJob? {
        val existing = jobs[jobId] ?: return null
        if (existing.status != JobStatus.WAITING && existing.status != JobStatus.PROCESSING) {
            return existing
        }
        val cancelled = existing.copy(
            status = JobStatus.CANCELLED,
            currentStageText = "Cancelled",
            completionTimeMillis = nowMillis
        )
        jobs[jobId] = cancelled
        return cancelled
    }

    @Synchronized
    fun retryJob(jobId: String): UpscaleJob? {
        val existing = jobs[jobId] ?: return null
        if (existing.status != JobStatus.FAILED && existing.status != JobStatus.CANCELLED) {
            return existing
        }
        val retried = existing.copy(
            status = JobStatus.WAITING,
            progress = 0f,
            currentStageText = "Waiting in queue (retry)",
            startTimeMillis = null,
            completionTimeMillis = null,
            errorDetails = null
        )
        jobs[jobId] = retried
        return retried
    }

    @Synchronized
    fun recoverInterruptedJobs(): Int {
        var count = 0
        for ((id, job) in jobs.entries) {
            if (job.status == JobStatus.PROCESSING) {
                jobs[id] = job.copy(
                    status = JobStatus.WAITING,
                    progress = 0f,
                    currentStageText = "Waiting in queue (restarted after interruption)",
                    startTimeMillis = null,
                    completionTimeMillis = null
                )
                count++
            }
        }
        return count
    }
}
