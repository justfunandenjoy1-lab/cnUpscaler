package com.cn.upscaler.feature.about

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cn.upscaler.core.ai.SupportedModelCatalog

@Composable
fun AboutPrivacyScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("About CN Upscaler & Privacy", style = MaterialTheme.typography.titleLarge)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("100% Offline-First Privacy Architecture", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Zero Cloud Uploads: CN Upscaler does not request android.permission.INTERNET in AndroidManifest.xml. Your photos never leave your device.
" +
                        "• Scoped Storage & Photo Picker: Uses Android Photo Picker and MediaStore without requesting broad all-files access.
" +
                        "• GPS & Serial Privacy Stripping: Automatically removes GPS latitude/longitude, altitude, timestamps, and camera serial numbers from exported files by default.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Target Resolution vs. AI Enhancement Level", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Target Resolution (2K, 4K, 8K, 16K UHD) controls final output pixel dimensions using an orientation-aware bounding-box fit that preserves your original aspect ratio without stretching.
" +
                        "• AI Enhancement Level (4×, 8×, 16×) selects the neural processing profile, NOT a geometric dimension multiplier. For example, a 1920×1080 image with Target Resolution 4K UHD and 8× AI Enhancement outputs exactly 3840×2160.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        SupportedModelCatalog.ALL_SPECS.forEach { spec ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(spec.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Version: ${spec.version} • Architecture: ${spec.architecture}", style = MaterialTheme.typography.bodyMedium)
                    Text("Source: ${spec.sourceUrl}", style = MaterialTheme.typography.labelMedium)
                    Text("License: ${spec.licenseName}", style = MaterialTheme.typography.labelMedium)
                    Text("Redistribution: ${spec.redistributionConditions}", style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Model Limitations:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                    spec.limitations.forEach { lim ->
                        Text("• $lim", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
