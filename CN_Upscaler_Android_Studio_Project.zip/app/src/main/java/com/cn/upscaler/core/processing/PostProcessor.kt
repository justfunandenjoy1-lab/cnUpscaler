package com.cn.upscaler.core.processing

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Optional, validated conventional post-processing parameters.
 *
 * CRITICAL COMPLIANCE:
 * - Never labels conventional sharpening or denoising as "AI Face Enhancement".
 * - Face Enhancement is explicitly omitted/unavailable because no dedicated facial restoration
 *   model (e.g., GFPGAN / CodeFormer) is bundled.
 * - All post-processing is OFF by default so the neural network's natural output is preserved
 *   without artificial haloing or skin-tone shifts.
 */
data class PostProcessingConfig(
    val enableSubtleDenoise: Boolean = false,
    val denoiseStrength: Float = 0.25f, // Validated range: 0.0f..1.0f
    val enableUnsharpMask: Boolean = false,
    val sharpenAmount: Float = 0.20f    // Validated range: 0.0f..0.50f (capped to prevent haloing)
) {
    init {
        require(denoiseStrength in 0.0f..1.0f) {
            "denoiseStrength ($denoiseStrength) must be within 0.0..1.0"
        }
        require(sharpenAmount in 0.0f..0.50f) {
            "sharpenAmount ($sharpenAmount) must be within 0.0..0.50 to prevent aggressive sharpening artifacts"
        }
    }

    val isActive: Boolean get() = (enableSubtleDenoise && denoiseStrength > 0f) || (enableUnsharpMask && sharpenAmount > 0f)

    fun describeActiveOperations(): String {
        val ops = mutableListOf<String>()
        if (enableSubtleDenoise && denoiseStrength > 0f) {
            ops += "Conventional Edge-Preserving Luminance Denoise (strength=${String.format("%.2f", denoiseStrength)})"
        }
        if (enableUnsharpMask && sharpenAmount > 0f) {
            ops += "Conventional Subtle Unsharp Mask (amount=${String.format("%.2f", sharpenAmount)})"
        }
        return if (ops.isEmpty()) "None (Pure AI Model Output)" else ops.joinToString(" + ")
    }
}

object PostProcessor {

    /**
     * Applies optional edge-preserving luminance denoising and/or subtle unsharp masking
     * while preserving chroma (skin tones and colors) and alpha transparency.
     */
    fun apply(
        argbPixels: IntArray,
        width: Int,
        height: Int,
        config: PostProcessingConfig
    ): IntArray {
        if (!config.isActive || width < 3 || height < 3) return argbPixels

        var current = argbPixels
        if (config.enableSubtleDenoise && config.denoiseStrength > 0f) {
            current = applyEdgePreservingDenoise(current, width, height, config.denoiseStrength)
        }
        if (config.enableUnsharpMask && config.sharpenAmount > 0f) {
            current = applySubtleUnsharpMask(current, width, height, config.sharpenAmount)
        }
        return current
    }

    private fun applyEdgePreservingDenoise(
        src: IntArray,
        width: Int,
        height: Int,
        strength: Float
    ): IntArray {
        val out = src.copyOf()
        val threshold = (12 + (strength * 28).roundToInt()).coerceIn(8, 40)
        val blend = (strength * 0.6f).coerceIn(0f, 0.6f)

        for (y in 1 until height - 1) {
            val rowOffset = y * width
            for (x in 1 until width - 1) {
                val idx = rowOffset + x
                val center = src[idx]
                val a = (center ushr 24) and 0xFF
                val cr = (center ushr 16) and 0xFF
                val cg = (center ushr 8) and 0xFF
                val cb = center and 0xFF

                var sumR = cr
                var sumG = cg
                var sumB = cb
                var count = 1

                val neighbors = intArrayOf(
                    src[idx - 1],
                    src[idx + 1],
                    src[idx - width],
                    src[idx + width]
                )
                for (n in neighbors) {
                    val nr = (n ushr 16) and 0xFF
                    val ng = (n ushr 8) and 0xFF
                    val nb = n and 0xFF
                    val lumaDiff = abs((cr + cg * 2 + cb) - (nr + ng * 2 + nb)) shr 2
                    if (lumaDiff <= threshold) {
                        sumR += nr
                        sumG += ng
                        sumB += nb
                        count++
                    }
                }

                if (count > 1) {
                    val avgR = sumR.toFloat() / count
                    val avgG = sumG.toFloat() / count
                    val avgB = sumB.toFloat() / count
                    val r = (cr * (1f - blend) + avgR * blend).roundToInt().coerceIn(0, 255)
                    val g = (cg * (1f - blend) + avgG * blend).roundToInt().coerceIn(0, 255)
                    val b = (cb * (1f - blend) + avgB * blend).roundToInt().coerceIn(0, 255)
                    out[idx] = (a shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
        }
        return out
    }

    private fun applySubtleUnsharpMask(
        src: IntArray,
        width: Int,
        height: Int,
        amount: Float
    ): IntArray {
        val out = src.copyOf()
        val effectiveAmount = amount.coerceIn(0.0f, 0.50f)
        val coringThreshold = 4 // Avoid amplifying flat sensor noise

        for (y in 1 until height - 1) {
            val rowOffset = y * width
            for (x in 1 until width - 1) {
                val idx = rowOffset + x
                val c = src[idx]
                val a = (c ushr 24) and 0xFF
                val cr = (c ushr 16) and 0xFF
                val cg = (c ushr 8) and 0xFF
                val cb = c and 0xFF

                val l = src[idx - 1]
                val r = src[idx + 1]
                val u = src[idx - width]
                val d = src[idx + width]

                val blurR = (((l ushr 16) and 0xFF) + ((r ushr 16) and 0xFF) + ((u ushr 16) and 0xFF) + ((d ushr 16) and 0xFF)) * 0.25f
                val blurG = (((l ushr 8) and 0xFF) + ((r ushr 8) and 0xFF) + ((u ushr 8) and 0xFF) + ((d ushr 8) and 0xFF)) * 0.25f
                val blurB = ((l and 0xFF) + (r and 0xFF) + (u and 0xFF) + (d and 0xFF)) * 0.25f

                val diffR = cr - blurR
                val diffG = cg - blurG
                val diffB = cb - blurB

                val nr = if (abs(diffR) >= coringThreshold) (cr + diffR * effectiveAmount).roundToInt().coerceIn(0, 255) else cr
                val ng = if (abs(diffG) >= coringThreshold) (cg + diffG * effectiveAmount).roundToInt().coerceIn(0, 255) else cg
                val nb = if (abs(diffB) >= coringThreshold) (cb + diffB * effectiveAmount).roundToInt().coerceIn(0, 255) else cb

                out[idx] = (a shl 24) or (nr shl 16) or (ng shl 8) or nb
            }
        }
        return out
    }
}
