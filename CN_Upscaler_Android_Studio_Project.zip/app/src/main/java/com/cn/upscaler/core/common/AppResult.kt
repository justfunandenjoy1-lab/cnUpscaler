package com.cn.upscaler.core.common

/**
 * Strongly-typed result wrapper for domain, storage, and AI inference operations.
 */
sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Error(
        val message: String,
        val cause: Throwable? = null,
        val errorCode: ErrorCode = ErrorCode.UNKNOWN
    ) : AppResult<Nothing>
}

enum class ErrorCode {
    INVALID_URI,
    PERMISSION_REVOKED,
    FILE_NOT_FOUND,
    CORRUPTED_IMAGE,
    UNSUPPORTED_FORMAT,
    INVALID_DIMENSIONS,
    DIMENSION_LIMIT_EXCEEDED,
    INSUFFICIENT_MEMORY,
    INSUFFICIENT_STORAGE,
    MODEL_UNAVAILABLE,
    UNSUPPORTED_ENHANCEMENT_PROFILE,
    INFERENCE_FAILED,
    ENCODING_FAILED,
    CANCELLED,
    UNKNOWN
}
