package com.cn.upscaler.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.cn.upscaler.R
import com.cn.upscaler.app.CnUpscalerApplication
import com.cn.upscaler.core.common.AppResult
import com.cn.upscaler.core.image.EncodingConfig
import com.cn.upscaler.core.processing.PipelineJobRequest
import com.cn.upscaler.core.processing.TileConfig
import com.cn.upscaler.domain.model.JobStatus
import kotlinx.coroutines.CancellationException

/**
 * Background CoroutineWorker that sequentially executes queued super-resolution jobs
 * outside the UI thread, updates Foreground Service notifications ("23 / 50 completed"),
 * supports cooperative cancellation, and isolates single-job failures so remaining batch
 * items continue processing.
 */
class BatchUpscaleWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        const val UNIQUE_WORK_NAME = "cn_upscaler_batch_queue_worker"
        const val NOTIFICATION_CHANNEL_ID = "cn_upscaler_processing_channel"
        const val NOTIFICATION_ID = 4102

        const val KEY_COMPLETED_COUNT = "completed_count"
        const val KEY_TOTAL_COUNT = "total_count"
        const val KEY_ACTIVE_JOB_ID = "active_job_id"
        const val KEY_ACTIVE_FILENAME = "active_filename"
        const val KEY_ACTIVE_PROGRESS = "active_progress"

        fun enqueueOrContinueBatch(context: Context) {
            val request = OneTimeWorkRequestBuilder<BatchUpscaleWorker>()
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .addTag(UNIQUE_WORK_NAME)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                UNIQUE_WORK_NAME,
                ExistingWorkPolicy.KEEP,
                request
            )
        }

        fun cancelBatchWork(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        }
    }

    override suspend fun doWork(): Result {
        val app = applicationContext as? CnUpscalerApplication
            ?: return Result.failure()
        val container = app.container
        val jobRepository = container.jobRepository
        val settingsRepository = container.settingsRepository
        val pipeline = container.imageProcessingPipeline

        ensureNotificationChannel()

        // Recover any jobs left in PROCESSING state from a prior process kill
        jobRepository.recoverInterruptedJobsOnStartup()

        val initialWaiting = jobRepository.countWaitingJobs()
        if (initialWaiting == 0) {
            return Result.success()
        }

        var completedOrHandledInSession = 0
        var totalInSession = initialWaiting

        try {
            setForeground(
                createForegroundInfo(
                    completedCount = 0,
                    totalCount = totalInSession,
                    currentFilename = "Preparing AI Super-Resolution..."
                )
            )
        } catch (_: Throwable) {
            // In case background foreground-start restrictions apply on certain OEM builds
        }

        while (!isStopped) {
            val nextJob = jobRepository.getNextWaitingJob() ?: break
            val remainingWaiting = jobRepository.countWaitingJobs()
            totalInSession = maxOf(totalInSession, completedOrHandledInSession + remainingWaiting)

            val settings = settingsRepository.getCurrentSettings()
            val processingStartJob = nextJob.copy(
                status = JobStatus.PROCESSING,
                progress = 0.02f,
                currentStageText = "Initializing pipeline...",
                startTimeMillis = System.currentTimeMillis(),
                errorDetails = null
            )
            jobRepository.updateJob(processingStartJob)

            updateNotificationSafe(
                completedCount = completedOrHandledInSession,
                totalCount = totalInSession,
                currentFilename = nextJob.originalFilename
            )

            val request = PipelineJobRequest(
                jobId = nextJob.id,
                inputUri = Uri.parse(nextJob.inputUriString),
                targetResolution = nextJob.targetResolution,
                enhancementLevel = nextJob.enhancementLevel,
                preferredModelId = settings.preferredModelId,
                executionProvider = settings.executionProvider,
                tileConfig = TileConfig(
                    tileSize = settings.tileSize,
                    overlap = settings.tileOverlap
                ),
                encodingConfig = EncodingConfig(
                    format = nextJob.outputFormat,
                    jpegQuality = nextJob.jpegQuality
                ),
                postProcessingConfig = settings.postProcessingConfig,
                userMetadataConfig = settings.userMetadataConfig,
                enableMultiPass8x = settings.enableMultiPass8x
            )

            try {
                val result = pipeline.execute(request) { progressUpdate ->
                    // Check if user cancelled this individual job in Room while tiles are running
                    val latestState = jobRepository.getJobById(nextJob.id)
                    if (latestState?.status == JobStatus.CANCELLED || isStopped) {
                        throw CancellationException("Job ${nextJob.id} cancelled by user.")
                    }

                    jobRepository.updateJob(
                        processingStartJob.copy(
                            progress = progressUpdate.overallProgress,
                            currentStageText = progressUpdate.detailMessage
                        )
                    )
                    setProgress(
                        workDataOf(
                            KEY_COMPLETED_COUNT to completedOrHandledInSession,
                            KEY_TOTAL_COUNT to totalInSession,
                            KEY_ACTIVE_JOB_ID to nextJob.id,
                            KEY_ACTIVE_FILENAME to nextJob.originalFilename,
                            KEY_ACTIVE_PROGRESS to progressUpdate.overallProgress
                        )
                    )
                }

                when (result) {
                    is AppResult.Success -> {
                        val summary = result.data
                        jobRepository.updateJob(
                            processingStartJob.copy(
                                status = JobStatus.COMPLETED,
                                progress = 1.0f,
                                currentStageText = "Saved to ${summary.savedMedia.relativePath}",
                                outputUriString = summary.savedMedia.contentUri.toString(),
                                outputWidth = summary.resolutionPlan.outputWidth,
                                outputHeight = summary.resolutionPlan.outputHeight,
                                outputFileSizeBytes = summary.savedMedia.fileSizeBytes,
                                actualModelName = summary.appliedStrategy.let {
                                    when (it) {
                                        is com.cn.upscaler.core.ai.EnhancementStrategy.SinglePassEnhancementStrategy -> it.modelName
                                        is com.cn.upscaler.core.ai.EnhancementStrategy.MultiPassEnhancementStrategy -> it.modelName
                                        is com.cn.upscaler.core.ai.EnhancementStrategy.UnsupportedEnhancementStrategy -> "Unavailable"
                                    }
                                },
                                actualModelVersion = summary.appliedStrategy.let {
                                    when (it) {
                                        is com.cn.upscaler.core.ai.EnhancementStrategy.SinglePassEnhancementStrategy -> it.modelVersion
                                        is com.cn.upscaler.core.ai.EnhancementStrategy.MultiPassEnhancementStrategy -> it.modelVersion
                                        is com.cn.upscaler.core.ai.EnhancementStrategy.UnsupportedEnhancementStrategy -> "-"
                                    }
                                },
                                actualProcessingStages = summary.appliedStrategy.stagesDescription,
                                activeExecutionProvider = summary.activeExecutionProvider,
                                completionTimeMillis = System.currentTimeMillis(),
                                warningsSummary = summary.warnings.joinToString(" | ").ifBlank { null },
                                errorDetails = null
                            )
                        )
                    }

                    is AppResult.Error -> {
                        // Phase 13 requirement: If one job fails, record error and continue processing subsequent jobs
                        jobRepository.updateJob(
                            processingStartJob.copy(
                                status = JobStatus.FAILED,
                                currentStageText = "Failed: ${result.errorCode.name}",
                                completionTimeMillis = System.currentTimeMillis(),
                                errorDetails = result.message
                            )
                        )
                    }
                }
            } catch (ce: CancellationException) {
                val latest = jobRepository.getJobById(nextJob.id)
                if (latest?.status != JobStatus.CANCELLED) {
                    jobRepository.cancelJob(nextJob.id)
                }
                if (isStopped) {
                    break
                }
            } catch (t: Throwable) {
                jobRepository.updateJob(
                    processingStartJob.copy(
                        status = JobStatus.FAILED,
                        currentStageText = "Unexpected error",
                        completionTimeMillis = System.currentTimeMillis(),
                        errorDetails = t.message ?: "Unexpected failure"
                    )
                )
            }

            completedOrHandledInSession++
            updateNotificationSafe(
                completedCount = completedOrHandledInSession,
                totalCount = totalInSession,
                currentFilename = nextJob.originalFilename
            )
        }

        return Result.success()
    }

    private suspend fun updateNotificationSafe(
        completedCount: Int,
        totalCount: Int,
        currentFilename: String
    ) {
        try {
            setForeground(createForegroundInfo(completedCount, totalCount, currentFilename))
        } catch (_: Throwable) {
        }
    }

    private fun createForegroundInfo(
        completedCount: Int,
        totalCount: Int,
        currentFilename: String
    ): ForegroundInfo {
        val cancelIntent = WorkManager.getInstance(applicationContext)
            .createCancelPendingIntent(id)

        val contentText = buildString {
            append("Processing images... ")
            append(completedCount).append(" / ").append(totalCount.coerceAtLeast(1)).append(" completed")
            if (currentFilename.isNotBlank()) {
                append(" • ").append(currentFilename)
            }
        }

        val notification = NotificationCompat.Builder(applicationContext, NOTIFICATION_CHANNEL_ID)
            .setContentTitle(applicationContext.getString(R.string.app_name))
            .setTicker(applicationContext.getString(R.string.app_name))
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(totalCount.coerceAtLeast(1), completedCount.coerceAtMost(totalCount), false)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Cancel",
                cancelIntent
            )
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                applicationContext.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = applicationContext.getString(R.string.notification_channel_desc)
            }
            manager.createNotificationChannel(channel)
        }
    }
}
