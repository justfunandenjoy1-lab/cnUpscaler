package com.cn.upscaler.core.storage

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.cn.upscaler.core.common.AppResult
import com.cn.upscaler.core.common.ErrorCode
import com.cn.upscaler.core.image.ImageFormat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

data class SavedMediaOutput(
    val contentUri: Uri,
    val displayName: String,
    val relativePath: String,
    val mimeType: String,
    val fileSizeBytes: Long
)

/*
 * Publishes completed super-resolution images to the device gallery (`Pictures/CN_Upscaler`)
 * using Scoped Storage (`MediaStore.Images.Media`) and provides Intent helpers for sharing
 * and opening outputs.
 */
class MediaStoreSaver(
    private val context: Context
) {
    companion object {
        const val GALLERY_SUBFOLDER = "Pictures/CN_Upscaler"
    }

    fun saveToGallery(
        sourceFile: File,
        displayName: String,
        format: ImageFormat
    ): AppResult<SavedMediaOutput> {
        if (!sourceFile.exists() || sourceFile.length() <= 0L) {
            return AppResult.Error(
                message = "Encoded temporary file is missing or empty.",
                errorCode = ErrorCode.ENCODING_FAILED
            )
        }

        val resolver = context.contentResolver
        val nowSeconds = System.currentTimeMillis() / 1000L

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Images.Media.MIME_TYPE, format.mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, GALLERY_SUBFOLDER)
                put(MediaStore.Images.Media.DATE_ADDED, nowSeconds)
                put(MediaStore.Images.Media.DATE_MODIFIED, nowSeconds)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }

            val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, values)
                ?: return AppResult.Error(
                    message = "Failed to create MediaStore gallery entry.",
                    errorCode = ErrorCode.INSUFFICIENT_STORAGE
                )

            try {
                resolver.openOutputStream(itemUri, "w")?.use { outStream ->
                    FileInputStream(sourceFile).use { inStream ->
                        inStream.copyTo(outStream, bufferSize = 64 * 1024)
                    }
                } ?: run {
                    resolver.delete(itemUri, null, null)
                    return AppResult.Error(
                        message = "Failed to open MediaStore output stream.",
                        errorCode = ErrorCode.INSUFFICIENT_STORAGE
                    )
                }

                val publishValues = ContentValues().apply {
                    put(MediaStore.Images.Media.IS_PENDING, 0)
                    put(MediaStore.Images.Media.SIZE, sourceFile.length())
                }
                resolver.update(itemUri, publishValues, null, null)

                AppResult.Success(
                    SavedMediaOutput(
                        contentUri = itemUri,
                        displayName = displayName,
                        relativePath = "$GALLERY_SUBFOLDER/$displayName",
                        mimeType = format.mimeType,
                        fileSizeBytes = sourceFile.length()
                    )
                )
            } catch (t: Throwable) {
                resolver.delete(itemUri, null, null)
                AppResult.Error(
                    message = "Failed to write image to MediaStore: ${t.message}",
                    cause = t,
                    errorCode = ErrorCode.INSUFFICIENT_STORAGE
                )
            }
        } else {
            // Android 8.0 - 9.0 (API 26 - 28) legacy external pictures directory
            try {
                @Suppress("DEPRECATION")
                val picturesDir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "CN_Upscaler"
                ).apply { mkdirs() }
                val targetFile = File(picturesDir, displayName)
                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output, bufferSize = 64 * 1024)
                    }
                }

                @Suppress("DEPRECATION")
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Images.Media.MIME_TYPE, format.mimeType)
                    put(MediaStore.Images.Media.DATA, targetFile.absolutePath)
                    put(MediaStore.Images.Media.SIZE, targetFile.length())
                    put(MediaStore.Images.Media.DATE_ADDED, nowSeconds)
                }
                val insertedUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: Uri.fromFile(targetFile)

                AppResult.Success(
                    SavedMediaOutput(
                        contentUri = insertedUri,
                        displayName = displayName,
                        relativePath = targetFile.absolutePath,
                        mimeType = format.mimeType,
                        fileSizeBytes = targetFile.length()
                    )
                )
            } catch (t: Throwable) {
                AppResult.Error(
                    message = "Failed to save image to gallery: ${t.message}",
                    cause = t,
                    errorCode = ErrorCode.INSUFFICIENT_STORAGE
                )
            }
        }
    }

    fun createShareImageIntent(contentUri: Uri, mimeType: String): Intent {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, contentUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(shareIntent, "Share Enhanced Image").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun createOpenImageIntent(contentUri: Uri, mimeType: String): Intent {
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(contentUri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
}
