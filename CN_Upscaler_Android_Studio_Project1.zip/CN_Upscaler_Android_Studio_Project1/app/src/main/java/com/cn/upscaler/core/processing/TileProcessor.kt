package com.cn.upscaler.core.processing

import com.cn.upscaler.core.ai.TileSuperResolutionInferenceSession
import kotlin.coroutines.coroutineContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.ensureActive

data class TileConfig(
    val tileSize: Int = 256,
    val overlap: Int = 32
) {
    init {
        require(tileSize in 64..1024) { "tileSize must be between 64 and 1024 ($tileSize)" }
        require(overlap in 0..(tileSize / 3)) { "overlap ($overlap) must be between 0 and tileSize/3" }
    }
}

data class TileWindow(
    val tileIndex: Int,
    val gridX: Int,
    val gridY: Int,
    val srcX: Int,
    val srcY: Int,
    val srcWidth: Int,
    val srcHeight: Int,
    val dstX: Int,
    val dstY: Int,
    val dstWidth: Int,
    val dstHeight: Int,
    val hasLeftOverlap: Boolean,
    val hasRightOverlap: Boolean,
    val hasTopOverlap: Boolean,
    val hasBottomOverlap: Boolean
)

/*
 * Memory-safe Tile-Based Super-Resolution Processor.
 *
 * Uses a single packed ARGB_8888 IntArray output buffer (4 bytes/pixel, zero FloatArray accumulators)
 * with in-place 2D raised-cosine (Hann window ramp) overlap blending so mobile JVM heap limits
 * are never exceeded.
 */
object TileProcessor {

    fun computeTileGrid(
        srcWidth: Int,
        srcHeight: Int,
        scale: Int,
        config: TileConfig
    ): List<TileWindow> {
        require(srcWidth > 0 && srcHeight > 0) { "Source dimensions must be positive" }
        require(scale > 0) { "Scale must be positive" }

        val step = config.tileSize - config.overlap
        val xStarts = computeAxisStarts(srcWidth, config.tileSize, step)
        val yStarts = computeAxisStarts(srcHeight, config.tileSize, step)

        val windows = ArrayList<TileWindow>(xStarts.size * yStarts.size)
        var index = 0
        for ((gy, y0) in yStarts.withIndex()) {
            val th = min(config.tileSize, srcHeight - y0)
            for ((gx, x0) in xStarts.withIndex()) {
                val tw = min(config.tileSize, srcWidth - x0)
                windows += TileWindow(
                    tileIndex = index++,
                    gridX = gx,
                    gridY = gy,
                    srcX = x0,
                    srcY = y0,
                    srcWidth = tw,
                    srcHeight = th,
                    dstX = x0 * scale,
                    dstY = y0 * scale,
                    dstWidth = tw * scale,
                    dstHeight = th * scale,
                    hasLeftOverlap = gx > 0 && config.overlap > 0,
                    hasRightOverlap = gx < xStarts.lastIndex && config.overlap > 0,
                    hasTopOverlap = gy > 0 && config.overlap > 0,
                    hasBottomOverlap = gy < yStarts.lastIndex && config.overlap > 0
                )
            }
        }
        return windows
    }

    private fun computeAxisStarts(length: Int, tileSize: Int, step: Int): List<Int> {
        if (length <= tileSize) return listOf(0)
        val starts = mutableListOf<Int>()
        var pos = 0
        while (pos + tileSize < length) {
            starts += pos
            pos += step
        }
        val lastStart = max(0, length - tileSize)
        if (starts.isEmpty() || starts.last() != lastStart) {
            starts += lastStart
        }
        return starts
    }

    fun computeAxisFeatherWeights(
        tileLengthPx: Int,
        overlapPx: Int,
        rampStart: Boolean,
        rampEnd: Boolean
    ): FloatArray {
        val weights = FloatArray(tileLengthPx) { 1.0f }
        if (overlapPx <= 0 || tileLengthPx <= overlapPx * 2) return weights

        if (rampStart) {
            for (i in 0 until overlapPx) {
                val t = (i + 0.5) / overlapPx.toDouble()
                weights[i] = (0.5 * (1.0 - cos(PI * t))).toFloat().coerceIn(1e-4f, 1.0f)
            }
        }
        if (rampEnd) {
            for (i in 0 until overlapPx) {
                val t = (i + 0.5) / overlapPx.toDouble()
                val w = (0.5 * (1.0 - cos(PI * t))).toFloat().coerceIn(1e-4f, 1.0f)
                weights[tileLengthPx - 1 - i] = min(weights[tileLengthPx - 1 - i], w)
            }
        }
        return weights
    }

    suspend fun processTiledImage(
        srcArgb: IntArray,
        srcWidth: Int,
        srcHeight: Int,
        preserveAlpha: Boolean,
        config: TileConfig,
        session: TileSuperResolutionInferenceSession,
        onTileProgress: suspend (completedTiles: Int, totalTiles: Int) -> Unit = { _, _ -> }
    ): IntArray {
        val scale = session.modelSpec.nativeScale
        val outWidth = srcWidth * scale
        val outHeight = srcHeight * scale
        val outSize = outWidth * outHeight

        val windows = computeTileGrid(srcWidth, srcHeight, scale, config)
        val totalTiles = windows.size

        if (totalTiles == 1) {
            coroutineContext.ensureActive()
            val single = windows.first()
            val outTile = session.inferTile(srcArgb, single.srcWidth, single.srcHeight, preserveAlpha)
            onTileProgress(1, 1)
            return outTile
        }

        // Single packed ARGB_8888 output array (80% less memory than 4 FloatArrays)
        val resultArgb = IntArray(outSize)
        val scaledOverlap = config.overlap * scale
        val rampLut = FloatArray(scaledOverlap.coerceAtLeast(1)) { i ->
            if (scaledOverlap <= 0) 1.0f
            else (0.5 * (1.0 - cos(PI * (i + 0.5) / scaledOverlap.toDouble()))).toFloat().coerceIn(0f, 1f)
        }

        for ((idx, win) in windows.withIndex()) {
            coroutineContext.ensureActive()

            val tilePixels = IntArray(win.srcWidth * win.srcHeight)
            for (ty in 0 until win.srcHeight) {
                val srcRowStart = (win.srcY + ty) * srcWidth + win.srcX
                System.arraycopy(srcArgb, srcRowStart, tilePixels, ty * win.srcWidth, win.srcWidth)
            }

            val upscaledTile = session.inferTile(
                argbPixels = tilePixels,
                tileWidth = win.srcWidth,
                tileHeight = win.srcHeight,
                preserveAlpha = preserveAlpha
            )

            for (ty in 0 until win.dstHeight) {
                val dstRowOffset = (win.dstY + ty) * outWidth + win.dstX
                val tileRowOffset = ty * win.dstWidth
                val inTopOverlap = win.hasTopOverlap && ty < scaledOverlap
                val wy = if (inTopOverlap) rampLut[ty] else 1.0f

                for (tx in 0 until win.dstWidth) {
                    val outIdx = dstRowOffset + tx
                    val newPx = upscaledTile[tileRowOffset + tx]
                    val inLeftOverlap = win.hasLeftOverlap && tx < scaledOverlap
                    val wx = if (inLeftOverlap) rampLut[tx] else 1.0f

                    if (!inLeftOverlap && !inTopOverlap) {
                        resultArgb[outIdx] = newPx
                    } else {
                        val wNew = wx * wy
                        val oldPx = resultArgb[outIdx]
                        resultArgb[outIdx] = blendArgbPixels(oldPx, newPx, wNew, preserveAlpha)
                    }
                }
            }

            onTileProgress(idx + 1, totalTiles)
        }

        coroutineContext.ensureActive()
        return resultArgb
    }

    private fun blendArgbPixels(oldPx: Int, newPx: Int, wNew: Float, preserveAlpha: Boolean): Int {
        val wOld = 1.0f - wNew
        val oldR = (oldPx ushr 16) and 0xFF
        val oldG = (oldPx ushr 8) and 0xFF
        val oldB = oldPx and 0xFF

        val newR = (newPx ushr 16) and 0xFF
        val newG = (newPx ushr 8) and 0xFF
        val newB = newPx and 0xFF

        val r = (oldR * wOld + newR * wNew).roundToInt().coerceIn(0, 255)
        val g = (oldG * wOld + newG * wNew).roundToInt().coerceIn(0, 255)
        val b = (oldB * wOld + newB * wNew).roundToInt().coerceIn(0, 255)
        val a = if (preserveAlpha) {
            val oldA = (oldPx ushr 24) and 0xFF
            val newA = (newPx ushr 24) and 0xFF
            (oldA * wOld + newA * wNew).roundToInt().coerceIn(0, 255)
        } else {
            0xFF
        }
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }
}
