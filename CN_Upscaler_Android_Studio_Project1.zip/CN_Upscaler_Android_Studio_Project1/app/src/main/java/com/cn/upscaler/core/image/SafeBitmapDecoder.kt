package com.cn.upscaler.core.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.cn.upscaler.core.common.AppResult
import com.cn.upscaler.core.common.ErrorCode
import com.cn.upscaler.core.common.MemoryBudgetMonitor

/*
 * Memory-safe Bitmap decoder with EXIF orientation normalization.
 */
class SafeBitmapDecoder(
    private val context: Context,
    private val memoryMonitor: MemoryBudgetMonitor
) {
    fun decodeForProcessing(
        uri: Uri,
        report: ImageInspectionReport
    ): AppResult<Bitmap> {
        return try {
            val sampleSize = calculateInSampleSize(
                rawWidth = report.rawWidth,
                rawHeight = report.rawHeight,
                reqWidth = 2560,
                reqHeight = 2560
            )
            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inMutable = false
                inSampleSize = sampleSize
            }
            val rawBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            } ?: return AppResult.Error(
                message = "Unable to decode bitmap stream for ${report.filename}.",
                errorCode = ErrorCode.DECODE_FAILED
            )

            val oriented = ExifOrientationHelper.applyExifOrientation(rawBitmap, report.exifOrientation)
            AppResult.Success(oriented)
        } catch (oom: OutOfMemoryError) {
            System.gc()
            AppResult.Error(
                message = "Out of memory while decoding ${report.filename}.",
                cause = oom,
                errorCode = ErrorCode.INSUFFICIENT_MEMORY
            )
        } catch (t: Throwable) {
            AppResult.Error(
                message = "Failed to decode ${report.filename}: ${t.message}",
                cause = t,
                errorCode = ErrorCode.DECODE_FAILED
            )
        }
    }

    fun decodeSubsampledPreview(
        uri: Uri,
        maxDimensionPx: Int = 1024
    ): Bitmap? {
        return try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOpts)
            }
            if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) return null

            val sampleSize = calculateInSampleSize(
                rawWidth = boundsOpts.outWidth,
                rawHeight = boundsOpts.outHeight,
                reqWidth = maxDimensionPx,
                reqHeight = maxDimensionPx
            )
            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val raw = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: return null

            val exif = context.contentResolver.openInputStream(uri)?.use { stream ->
                ExifOrientationHelper.readOrientation(stream)
            } ?: androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL

            ExifOrientationHelper.applyExifOrientation(raw, exif)
        } catch (_: Throwable) {
            null
        }
    }

    companion object {
        fun calculateInSampleSize(
            rawWidth: Int,
            rawHeight: Int,
            reqWidth: Int,
            reqHeight: Int
        ): Int {
            var inSampleSize = 1
            if (rawHeight > reqHeight || rawWidth > reqWidth) {
                val halfHeight = rawHeight / 2
                val halfWidth = rawWidth / 2
                while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                    inSampleSize *= 2
                }
            }
            return inSampleSize.coerceAtLeast(1)
        }
    }
}
