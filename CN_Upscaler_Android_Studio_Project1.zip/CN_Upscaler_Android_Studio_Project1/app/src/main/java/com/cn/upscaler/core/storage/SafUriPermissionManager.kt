package com.cn.upscaler.core.storage

import android.content.Context
import android.content.Intent
import android.net.Uri

/*
 * Manages Content URI permissions for images selected via Android Photo Picker
 * or Storage Access Framework (SAF).
 */
class SafUriPermissionManager(
    private val context: Context
) {
    /*
     * Attempts to persist read permission for SAF Document URIs so queued background
     * WorkManager jobs can read the input stream even after activity recreation.
     * Note: Android Photo Picker temporary grants may throw SecurityException on
     * takePersistableUriPermission, which is safely caught and ignored because the platform
     * grant remains active for the app session.
     */
    fun takePersistableReadPermissionIfSupported(uri: Uri): Boolean {
        return try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            true
        } catch (_: SecurityException) {
            false
        } catch (_: Throwable) {
            false
        }
    }

    fun isUriReadable(uri: Uri): Boolean {
        return try {
            context.contentResolver.openInputStream(uri)?.use { true } ?: false
        } catch (_: Throwable) {
            false
        }
    }
}
