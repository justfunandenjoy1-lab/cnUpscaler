package com.cn.upscaler.core.processing

import com.cn.upscaler.core.image.ImageFormat
import kotlin.math.min
import kotlin.math.roundToInt

/*
 * Supported Target Output Resolutions.
 * CRITICAL RULE: Target Resolution determines final pixel dimensions (independent of AI Enhancement Level).
 * Reference dimensions are defined for 16:9 images; non-16:9 images preserve their exact original aspect
 * ratio using the documented orientation-aware bounding-box fit policy.
 */
enum class TargetResolution(
    val id: String,
    val label: String,
    val shortLabel: String,
    val referenceWidth: Int,
    val referenceHeight: Int
) {
    UHD_2K("2K", "2K UHD (2560 × 1440)", "2K UHD", 2560, 1440),
    UHD_4K("4K", "4K UHD (3840 × 2160)", "4K UHD", 3840, 2160),
    UHD_8K("8K", "8K UHD (7680 × 4320)", "8K UHD", 7680, 4320),
    UHD_16K("16K", "16K UHD (15360 × 8640)", "16K UHD", 15360, 8640);

    companion object {
        fun fromId(id: String): TargetResolution = entries.find { it.id == id } ?: UHD_4K
    }
}

data class ResolutionPlan(
    val sourceWidth: Int,
    val sourceHeight: Int,
    val targetResolution: TargetResolution,
    val outputWidth: Int,
    val outputHeight: Int,
    val geometricScaleRatio: Double,
    val isDownscalingFromSource: Boolean,
    val requiresPostInferenceResize: Boolean,
    val requiresPostInferenceUpscaleBeyondNative4x: Boolean,
    val estimatedOutputPixels: Long,
    val estimatedStorageBytes: Long,
    val estimatedPeakMemoryBytes: Long,
    val exceedsSafeSingleBitmapLimit: Boolean,
    val exceedsMaximumSupportedOutput: Boolean,
    val warnings: List<String>,
    val supportedAlternatives: List<TargetResolution>
)

/*
 * Reusable Target Resolution calculator implementing an explicit, orientation-aware
 * bounding-box fit policy that preserves original aspect ratios without distortion.
 *
 * Documented Fitting Policy for Non-16:9 Images:
 * 1. For landscape or square images (srcWidth >= srcHeight), the bounding box is
 *    (referenceWidth x referenceHeight), e.g., 3840 x 2160 for 4K UHD.
 * 2. For portrait images (srcHeight > srcWidth), the reference bounding box is oriented to
 *    portrait (referenceHeight x referenceWidth), e.g., 2160 x 3840 for 4K UHD, so portrait
 *    photos receive the same pixel budget as landscape photos.
 * 3. Inside the oriented bounding box (maxW, maxH), the uniform scale factor is:
 *    scale = min(maxW.toDouble() / srcWidth, maxH.toDouble() / srcHeight)
 *    outputWidth = max(1, round(srcWidth * scale))
 *    outputHeight = max(1, round(srcHeight * scale))
 */
object ResolutionCalculator {

    const val MAX_ABSOLUTE_DIMENSION_PX = 15360
    const val MAX_SAFE_SINGLE_BITMAP_PIXELS = 40_000_000L // ~40 MP (~160 MB ARGB_8888)
    const val MAX_SUPPORTED_OUTPUT_PIXELS = 132_710_400L // 16K UHD (15360 * 8640)

    fun calculate(
        sourceWidth: Int,
        sourceHeight: Int,
        target: TargetResolution,
        outputFormat: ImageFormat = ImageFormat.JPEG,
        nativeModelScale: Int = 4,
        tileSize: Int = 256,
        availableHeapBytes: Long = 512L * 1024L * 1024L
    ): ResolutionPlan {
        require(sourceWidth > 0 && sourceHeight > 0) {
            "Source dimensions must be strictly positive (got ${sourceWidth}x${sourceHeight})."
        }

        val isPortrait = sourceHeight > sourceWidth
        val boxWidth = if (isPortrait) target.referenceHeight else target.referenceWidth
        val boxHeight = if (isPortrait) target.referenceWidth else target.referenceHeight

        val scale = min(
            boxWidth.toDouble() / sourceWidth.toDouble(),
            boxHeight.toDouble() / sourceHeight.toDouble()
        )

        val outW = (sourceWidth * scale).roundToInt().coerceAtLeast(1)
        val outH = (sourceHeight * scale).roundToInt().coerceAtLeast(1)

        val outputPixels = outW.toLong() * outH.toLong()
        val nativeOutW = sourceWidth.toLong() * nativeModelScale
        val nativeOutH = sourceHeight.toLong() * nativeModelScale

        val requiresResizeAfterInference = (outW.toLong() != nativeOutW) || (outH.toLong() != nativeOutH)
        val exceedsNative4x = outW.toLong() > nativeOutW || outH.toLong() > nativeOutH
        val isDownscaleFromSource = outW < sourceWidth || outH < sourceHeight

        // Estimate storage footprint based on format compression ratio
        val bytesPerPixelStorage = when (outputFormat) {
            ImageFormat.JPEG -> 0.45 // High quality (95) JPEG average
            ImageFormat.PNG -> 1.85  // Lossless Deflate PNG average
            ImageFormat.WEBP -> 0.35 // High quality WebP average
            ImageFormat.UNKNOWN -> 1.0
        }
        val estimatedStorageBytes = (outputPixels * bytesPerPixelStorage).toLong().coerceAtLeast(4096L)

        // Estimate peak memory requirement during tiled inference & output assembly
        val outTileSide = tileSize * nativeModelScale
        val tileTensorsBytes = (1L * 3L * tileSize * tileSize * 4L) + (1L * 3L * outTileSide * outTileSide * 4L)
        val outputBufferBytes = outputPixels * 4L
        val sourceBufferBytes = minOf(sourceWidth.toLong() * sourceHeight.toLong() * 4L, 64L * 1024L * 1024L)
        val estimatedPeakMemoryBytes = sourceBufferBytes + tileTensorsBytes + outputBufferBytes

        val exceedsSingleBitmap = outputPixels > MAX_SAFE_SINGLE_BITMAP_PIXELS ||
            estimatedPeakMemoryBytes > (availableHeapBytes * 0.80).toLong()

        val exceedsMaxOutput = outW > MAX_ABSOLUTE_DIMENSION_PX ||
            outH > MAX_ABSOLUTE_DIMENSION_PX ||
            outputPixels > MAX_SUPPORTED_OUTPUT_PIXELS ||
            estimatedPeakMemoryBytes > availableHeapBytes * 2

        val warnings = mutableListOf<String>()
        if (isDownscaleFromSource) {
            warnings += "Selected target (${outW}×${outH}) is smaller than original dimensions (${sourceWidth}×${sourceHeight}). Output will be downsampled after AI enhancement."
        }
        if (requiresResizeAfterInference && !exceedsNative4x) {
            warnings += "AI model natively outputs ${nativeOutW}×${nativeOutH} (${nativeModelScale}×); final output is resampled to ${outW}×${outH} to match ${target.shortLabel}."
        }
        if (exceedsNative4x) {
            warnings += "Requested target (${outW}×${outH}) exceeds the model's native ${nativeModelScale}× output (${nativeOutW}×${nativeOutH}). Final resizing beyond ${nativeModelScale}× changes pixel dimensions but does not independently generate additional authentic detail."
        }
        if (exceedsSingleBitmap) {
            warnings += "High-resolution output (${String.format("%.1f", outputPixels / 1_000_000.0)} MP, ~${estimatedPeakMemoryBytes / (1024 * 1024)} MB peak RAM) exceeds standard heap limits. Strip/disk-backed tiled processing is required and may fail on low-RAM devices."
        }
        if (exceedsMaxOutput) {
            warnings += "Target ${target.shortLabel} exceeds safe device memory capacity. Please select a lower supported target resolution."
        }

        val alternatives = TargetResolution.entries.filter { candidate ->
            if (candidate == target) return@filter false
            val candW = (sourceWidth * min(
                (if (isPortrait) candidate.referenceHeight else candidate.referenceWidth).toDouble() / sourceWidth,
                (if (isPortrait) candidate.referenceWidth else candidate.referenceHeight).toDouble() / sourceHeight
            )).roundToInt()
            val candH = (sourceHeight * min(
                (if (isPortrait) candidate.referenceHeight else candidate.referenceWidth).toDouble() / sourceWidth,
                (if (isPortrait) candidate.referenceWidth else candidate.referenceHeight).toDouble() / sourceHeight
            )).roundToInt()
            val candMem = sourceBufferBytes + tileTensorsBytes + (candW.toLong() * candH.toLong() * 4L)
            candMem <= (availableHeapBytes * 0.80).toLong()
        }

        return ResolutionPlan(
            sourceWidth = sourceWidth,
            sourceHeight = sourceHeight,
            targetResolution = target,
            outputWidth = outW,
            outputHeight = outH,
            geometricScaleRatio = scale,
            isDownscalingFromSource = isDownscaleFromSource,
            requiresPostInferenceResize = requiresResizeAfterInference,
            requiresPostInferenceUpscaleBeyondNative4x = exceedsNative4x,
            estimatedOutputPixels = outputPixels,
            estimatedStorageBytes = estimatedStorageBytes,
            estimatedPeakMemoryBytes = estimatedPeakMemoryBytes,
            exceedsSafeSingleBitmapLimit = exceedsSingleBitmap,
            exceedsMaximumSupportedOutput = exceedsMaxOutput,
            warnings = warnings,
            supportedAlternatives = alternatives
        )
    }
}
