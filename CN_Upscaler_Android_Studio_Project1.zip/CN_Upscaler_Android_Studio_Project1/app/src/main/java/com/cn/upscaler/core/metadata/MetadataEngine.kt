package com.cn.upscaler.core.metadata

import android.content.Context
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.processing.TargetResolution
import java.io.File
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

/*
 * Optional user-configurable metadata fields.
 */
data class UserMetadataConfig(
    val title: String = "",
    val author: String = "",
    val description: String = "",
    val keywords: String = "",
    val copyright: String = "",
    val preserveSafeOriginalExif: Boolean = true,
    val stripSensitiveLocationMetadata: Boolean = true
)

/*
 * Complete provenance record written into output image metadata where supported by the format.
 */
data class ProcessingProvenanceMetadata(
    val software: String = "CN Upscaler",
    val processingType: String = "AI Super Resolution",
    val originalWidth: Int,
    val originalHeight: Int,
    val outputWidth: Int,
    val outputHeight: Int,
    val targetResolution: TargetResolution,
    val enhancementLevel: EnhancementLevel,
    val actualModelName: String,
    val actualModelVersion: String,
    val actualProcessingStages: String,
    val processingTimestampUtc: String = DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss")
        .withZone(ZoneOffset.UTC)
        .format(Instant.now())
) {
    fun toStructuredUserComment(): String {
        return buildString {
            append("Software=").append(software)
            append("; Processing=").append(processingType)
            append("; OriginalDimensions=").append(originalWidth).append("x").append(originalHeight)
            append("; OutputDimensions=").append(outputWidth).append("x").append(outputHeight)
            append("; TargetResolution=").append(targetResolution.id)
            append("; EnhancementLevel=").append(enhancementLevel.displayName)
            append("; AIModel=").append(actualModelName)
            append("; AIModelVersion=").append(actualModelVersion)
            append("; Stages=").append(actualProcessingStages)
            append("; ProcessedAtUTC=").append(processingTimestampUtc)
        }
    }
}

data class MetadataWriteReport(
    val formatSupportsExifWrite: Boolean,
    val writtenFields: Map<String, String>,
    val strippedSensitiveTags: List<String>,
    val note: String
)

/*
 * Reusable Metadata Engine using AndroidX ExifInterface.
 *
 * Format Support Honesty:
 * - AndroidX ExifInterface supports writing EXIF tags to JPEG, PNG (via eXIf chunk in ExifInterface 1.3+),
 *   and WebP files. However, third-party gallery viewers may not display all EXIF tags on PNG/WebP.
 * - Sensitive GPS/location tags are stripped by default (`stripSensitiveLocationMetadata = true`).
 */
class MetadataEngine(
    private val context: Context
) {
    companion object {
        private val SAFE_ORIGINAL_TAGS = listOf(
            ExifInterface.TAG_DATETIME_ORIGINAL,
            ExifInterface.TAG_MAKE,
            ExifInterface.TAG_MODEL,
            ExifInterface.TAG_F_NUMBER,
            ExifInterface.TAG_EXPOSURE_TIME,
            ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY,
            ExifInterface.TAG_FOCAL_LENGTH,
            ExifInterface.TAG_WHITE_BALANCE,
            ExifInterface.TAG_FLASH
        )

        private val SENSITIVE_GPS_TAGS = listOf(
            ExifInterface.TAG_GPS_LATITUDE,
            ExifInterface.TAG_GPS_LATITUDE_REF,
            ExifInterface.TAG_GPS_LONGITUDE,
            ExifInterface.TAG_GPS_LONGITUDE_REF,
            ExifInterface.TAG_GPS_ALTITUDE,
            ExifInterface.TAG_GPS_ALTITUDE_REF,
            ExifInterface.TAG_GPS_TIMESTAMP,
            ExifInterface.TAG_GPS_DATESTAMP,
            ExifInterface.TAG_GPS_PROCESSING_METHOD,
            ExifInterface.TAG_GPS_AREA_INFORMATION,
            ExifInterface.TAG_GPS_DEST_LATITUDE,
            ExifInterface.TAG_GPS_DEST_LONGITUDE,
            ExifInterface.TAG_CAMERA_OWNER_NAME,
            ExifInterface.TAG_BODY_SERIAL_NUMBER,
            ExifInterface.TAG_LENS_SERIAL_NUMBER
        )
    }

    fun writeMetadata(
        sourceUri: Uri?,
        outputFile: File,
        outputFormat: ImageFormat,
        provenance: ProcessingProvenanceMetadata,
        userMetadata: UserMetadataConfig
    ): MetadataWriteReport {
        val written = linkedMapOf<String, String>()
        val stripped = mutableListOf<String>()

        return try {
            val targetExif = ExifInterface(outputFile)

            // 1. Copy safe original capture metadata if enabled
            if (userMetadata.preserveSafeOriginalExif && sourceUri != null) {
                try {
                    context.contentResolver.openInputStream(sourceUri)?.use { input ->
                        val srcExif = ExifInterface(input)
                        for (tag in SAFE_ORIGINAL_TAGS) {
                            val value = srcExif.getAttribute(tag)
                            if (!value.isNullOrBlank()) {
                                targetExif.setAttribute(tag, value)
                                written[tag] = value
                            }
                        }
                        if (!userMetadata.stripSensitiveLocationMetadata) {
                            for (gpsTag in SENSITIVE_GPS_TAGS) {
                                val value = srcExif.getAttribute(gpsTag)
                                if (!value.isNullOrBlank()) {
                                    targetExif.setAttribute(gpsTag, value)
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {
                    // Original image may not have EXIF headers
                }
            }

            // 2. Explicitly strip sensitive GPS & serial number tags when requested
            if (userMetadata.stripSensitiveLocationMetadata) {
                for (gpsTag in SENSITIVE_GPS_TAGS) {
                    targetExif.setAttribute(gpsTag, null)
                    stripped += gpsTag
                }
            }

            // 3. Orientation is already normalized during pixel decoding, so set NORMAL (1)
            targetExif.setAttribute(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL.toString()
            )
            targetExif.setAttribute(ExifInterface.TAG_IMAGE_WIDTH, provenance.outputWidth.toString())
            targetExif.setAttribute(ExifInterface.TAG_IMAGE_LENGTH, provenance.outputHeight.toString())
            targetExif.setAttribute(ExifInterface.TAG_PIXEL_X_DIMENSION, provenance.outputWidth.toString())
            targetExif.setAttribute(ExifInterface.TAG_PIXEL_Y_DIMENSION, provenance.outputHeight.toString())

            // 4. Write CN Upscaler software & AI provenance metadata
            targetExif.setAttribute(ExifInterface.TAG_SOFTWARE, provenance.software)
            targetExif.setAttribute(ExifInterface.TAG_DATETIME, provenance.processingTimestampUtc)
            targetExif.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, provenance.processingTimestampUtc)

            val structuredComment = provenance.toStructuredUserComment()
            val combinedComment = if (userMetadata.keywords.isNotBlank()) {
                "$structuredComment; Keywords=${userMetadata.keywords.trim()}"
            } else {
                structuredComment
            }
            targetExif.setAttribute(ExifInterface.TAG_USER_COMMENT, combinedComment)

            val descriptionText = buildString {
                if (userMetadata.title.isNotBlank()) {
                    append(userMetadata.title.trim()).append(" — ")
                }
                if (userMetadata.description.isNotBlank()) {
                    append(userMetadata.description.trim()).append(" | ")
                }
                append("${provenance.software} (${provenance.processingType}: ${provenance.actualModelName} ${provenance.actualModelVersion}, ")
                append("${provenance.originalWidth}x${provenance.originalHeight} -> ${provenance.outputWidth}x${provenance.outputHeight}, ")
                append("Target=${provenance.targetResolution.shortLabel}, Profile=${provenance.enhancementLevel.displayName})")
            }
            targetExif.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, descriptionText)

            if (userMetadata.author.isNotBlank()) {
                targetExif.setAttribute(ExifInterface.TAG_ARTIST, userMetadata.author.trim())
                written[ExifInterface.TAG_ARTIST] = userMetadata.author.trim()
            }
            if (userMetadata.copyright.isNotBlank()) {
                targetExif.setAttribute(ExifInterface.TAG_COPYRIGHT, userMetadata.copyright.trim())
                written[ExifInterface.TAG_COPYRIGHT] = userMetadata.copyright.trim()
            }

            targetExif.saveAttributes()

            written[ExifInterface.TAG_SOFTWARE] = provenance.software
            written[ExifInterface.TAG_USER_COMMENT] = combinedComment
            written[ExifInterface.TAG_IMAGE_DESCRIPTION] = descriptionText
            written[ExifInterface.TAG_DATETIME] = provenance.processingTimestampUtc

            MetadataWriteReport(
                formatSupportsExifWrite = true,
                writtenFields = written,
                strippedSensitiveTags = stripped,
                note = "EXIF provenance and user metadata written to ${outputFormat.displayName} container. Note: Not all external image viewers display full EXIF UserComment fields on PNG/WebP files."
            )
        } catch (t: Throwable) {
            MetadataWriteReport(
                formatSupportsExifWrite = false,
                writtenFields = emptyMap(),
                strippedSensitiveTags = stripped,
                note = "Metadata embedding skipped or partially unsupported by ${outputFormat.displayName} container (${t.message})."
            )
        }
    }
}
