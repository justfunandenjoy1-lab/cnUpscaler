package com.cn.upscaler.core.database

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.processing.TargetResolution
import com.cn.upscaler.domain.model.JobStatus
import com.cn.upscaler.domain.model.UpscaleJob

@Entity(
    tableName = "upscale_jobs",
    indices = [
        Index(value = ["statusName"]),
        Index(value = ["createdAtMillis"])
    ]
)
data class JobEntity(
    @PrimaryKey val id: String,
    val inputUriString: String,
    val outputUriString: String?,
    val originalFilename: String,
    val originalWidth: Int,
    val originalHeight: Int,
    val originalFormat: String,
    val originalFileSizeBytes: Long,
    val hasAlpha: Boolean,
    val targetResolutionId: String,
    val enhancementLevelId: String,
    val outputFormatName: String,
    val jpegQuality: Int,
    val statusName: String,
    val progress: Float,
    val currentStageText: String,
    val createdAtMillis: Long,
    val startTimeMillis: Long?,
    val completionTimeMillis: Long?,
    val outputWidth: Int?,
    val outputHeight: Int?,
    val outputFileSizeBytes: Long?,
    val actualModelName: String?,
    val actualModelVersion: String?,
    val actualProcessingStages: String?,
    val activeExecutionProvider: String?,
    val errorDetails: String?,
    val warningsSummary: String?
) {
    fun toDomain(): UpscaleJob = UpscaleJob(
        id = id,
        inputUriString = inputUriString,
        outputUriString = outputUriString,
        originalFilename = originalFilename,
        originalWidth = originalWidth,
        originalHeight = originalHeight,
        originalFormat = runCatching { ImageFormat.valueOf(originalFormat) }.getOrDefault(ImageFormat.JPEG),
        originalFileSizeBytes = originalFileSizeBytes,
        hasAlpha = hasAlpha,
        targetResolution = TargetResolution.fromId(targetResolutionId),
        enhancementLevel = EnhancementLevel.fromId(enhancementLevelId),
        outputFormat = runCatching { ImageFormat.valueOf(outputFormatName) }.getOrDefault(ImageFormat.JPEG),
        jpegQuality = jpegQuality,
        status = runCatching { JobStatus.valueOf(statusName) }.getOrDefault(JobStatus.WAITING),
        progress = progress,
        currentStageText = currentStageText,
        createdAtMillis = createdAtMillis,
        startTimeMillis = startTimeMillis,
        completionTimeMillis = completionTimeMillis,
        outputWidth = outputWidth,
        outputHeight = outputHeight,
        outputFileSizeBytes = outputFileSizeBytes,
        actualModelName = actualModelName,
        actualModelVersion = actualModelVersion,
        actualProcessingStages = actualProcessingStages,
        activeExecutionProvider = activeExecutionProvider,
        errorDetails = errorDetails,
        warningsSummary = warningsSummary
    )

    companion object {
        fun fromDomain(job: UpscaleJob): JobEntity = JobEntity(
            id = job.id,
            inputUriString = job.inputUriString,
            outputUriString = job.outputUriString,
            originalFilename = job.originalFilename,
            originalWidth = job.originalWidth,
            originalHeight = job.originalHeight,
            originalFormat = job.originalFormat.name,
            originalFileSizeBytes = job.originalFileSizeBytes,
            hasAlpha = job.hasAlpha,
            targetResolutionId = job.targetResolution.id,
            enhancementLevelId = job.enhancementLevel.id,
            outputFormatName = job.outputFormat.name,
            jpegQuality = job.jpegQuality,
            statusName = job.status.name,
            progress = job.progress,
            currentStageText = job.currentStageText,
            createdAtMillis = job.createdAtMillis,
            startTimeMillis = job.startTimeMillis,
            completionTimeMillis = job.completionTimeMillis,
            outputWidth = job.outputWidth,
            outputHeight = job.outputHeight,
            outputFileSizeBytes = job.outputFileSizeBytes,
            actualModelName = job.actualModelName,
            actualModelVersion = job.actualModelVersion,
            actualProcessingStages = job.actualProcessingStages,
            activeExecutionProvider = job.activeExecutionProvider,
            errorDetails = job.errorDetails,
            warningsSummary = job.warningsSummary
        )
    }
}
