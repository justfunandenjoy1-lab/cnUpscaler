package com.cn.upscaler.core.ai

import ai.onnxruntime.OrtException
import ai.onnxruntime.OrtSession
import ai.onnxruntime.providers.NNAPIFlags
import java.util.EnumSet

/*
 * Hardware execution provider preference exposed in Settings.
 */
enum class ExecutionProviderPreference(
    val id: String,
    val displayName: String,
    val description: String
) {
    AUTO(
        id = "AUTO",
        displayName = "Automatic (NNAPI with CPU Fallback)",
        description = "Attempts Android NNAPI hardware acceleration (NPU/GPU/DSP with FP16 relaxation) and falls back safely to multi-threaded CPU if initialization or graph partitioning fails."
    ),
    NNAPI(
        id = "NNAPI",
        displayName = "Android NNAPI (GPU / NPU / DSP)",
        description = "Requests Android Neural Networks API acceleration. Note: Not all RRDBNet operators are supported by every vendor NNAPI driver; falls back to CPU on driver rejection."
    ),
    CPU_ONLY(
        id = "CPU_ONLY",
        displayName = "CPU Only (Maximum Compatibility & Precision)",
        description = "Executes FP32 inference on multi-core ARM64 NEON / x86_64 CPU threads. Most consistent across devices and avoids GPU/NNAPI driver quirks."
    );

    companion object {
        fun fromId(id: String): ExecutionProviderPreference =
            entries.find { it.id == id } ?: AUTO
    }
}

data class ActiveExecutionProviderReport(
    val requestedPreference: ExecutionProviderPreference,
    val activeProviderName: String,
    val fellBackToCpu: Boolean,
    val fallbackReason: String?,
    val threadCount: Int
)

/*
 * Configures ONNX Runtime OrtSession.SessionOptions with safe hardware acceleration and automatic
 * CPU fallback so a faulty NNAPI/GPU delegate never crashes the application.
 */
object HardwareAcceleratorManager {

    fun configureSessionOptions(
        preference: ExecutionProviderPreference,
        cpuThreadCount: Int = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
    ): Pair<OrtSession.SessionOptions, ActiveExecutionProviderReport> {
        val options = OrtSession.SessionOptions()
        options.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        options.setIntraOpNumThreads(cpuThreadCount)
        options.setInterOpNumThreads(1)

        when (preference) {
            ExecutionProviderPreference.CPU_ONLY -> {
                return options to ActiveExecutionProviderReport(
                    requestedPreference = preference,
                    activeProviderName = "CPUExecutionProvider (${cpuThreadCount} threads)",
                    fellBackToCpu = false,
                    fallbackReason = null,
                    threadCount = cpuThreadCount
                )
            }

            ExecutionProviderPreference.AUTO,
            ExecutionProviderPreference.NNAPI -> {
                return try {
                    val flags = EnumSet.of(NNAPIFlags.USE_FP16)
                    options.addNnapi(flags)
                    options to ActiveExecutionProviderReport(
                        requestedPreference = preference,
                        activeProviderName = "NnapiExecutionProvider (FP16 enabled) + CPU Fallback",
                        fellBackToCpu = false,
                        fallbackReason = null,
                        threadCount = cpuThreadCount
                    )
                } catch (ortEx: OrtException) {
                    // Safe fallback to CPU
                    options to ActiveExecutionProviderReport(
                        requestedPreference = preference,
                        activeProviderName = "CPUExecutionProvider (${cpuThreadCount} threads)",
                        fellBackToCpu = true,
                        fallbackReason = "NNAPI initialization failed (${ortEx.message}); using CPU fallback.",
                        threadCount = cpuThreadCount
                    )
                } catch (t: Throwable) {
                    options to ActiveExecutionProviderReport(
                        requestedPreference = preference,
                        activeProviderName = "CPUExecutionProvider (${cpuThreadCount} threads)",
                        fellBackToCpu = true,
                        fallbackReason = "Hardware accelerator unavailable (${t.message}); using CPU fallback.",
                        threadCount = cpuThreadCount
                    )
                }
            }
        }
    }
}
