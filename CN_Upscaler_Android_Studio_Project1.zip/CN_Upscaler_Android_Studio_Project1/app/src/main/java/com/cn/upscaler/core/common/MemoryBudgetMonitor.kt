package com.cn.upscaler.core.common

/*
 * Inspects JVM/Android heap and native memory constraints to prevent OutOfMemoryError
 * during high-resolution tile reconstruction and decoding.
 */
class MemoryBudgetMonitor(
    private val maxHeapOverrideBytes: Long? = null
) {
    fun getMaxHeapBytes(): Long {
        return maxHeapOverrideBytes ?: Runtime.getRuntime().maxMemory()
    }

    fun getAvailableHeapBytes(): Long {
        val runtime = Runtime.getRuntime()
        val used = runtime.totalMemory() - runtime.freeMemory()
        return (getMaxHeapBytes() - used).coerceAtLeast(0L)
    }

    /*
     * Estimates ARGB_8888 (4 bytes/pixel) or RGBA_F16 (8 bytes/pixel) decoded Bitmap memory.
     */
    fun estimateBitmapBytes(width: Int, height: Int, bytesPerPixel: Int = 4): Long {
        if (width <= 0 || height <= 0 || bytesPerPixel <= 0) return 0L
        return width.toLong() * height.toLong() * bytesPerPixel.toLong()
    }

    /*
     * Estimates peak working memory for tiled inference:
     * - Source regional decode buffer or working bitmap
     * - Single input tile float32 tensor [1, 3, tileH, tileW]
     * - Single output tile float32 tensor [1, 3, tileH*4, tileW*4]
     * - Output accumulation buffer or regional strip
     */
    fun estimateTiledPipelineMemoryBytes(
        srcWidth: Int,
        srcHeight: Int,
        outWidth: Int,
        outHeight: Int,
        tileSize: Int,
        nativeScale: Int = 4
    ): Long {
        val inputTileTensorBytes = 1L * 3L * tileSize * tileSize * 4L
        val outTileSide = tileSize * nativeScale
        val outputTileTensorBytes = 1L * 3L * outTileSide * outTileSide * 4L
        val outputBitmapBytes = estimateBitmapBytes(outWidth, outHeight, bytesPerPixel = 4)
        val sourceDecodeBufferBytes = minOf(
            estimateBitmapBytes(srcWidth, srcHeight, bytesPerPixel = 4),
            64L * 1024L * 1024L // Region decoder caps source window in RAM
        )
        return sourceDecodeBufferBytes + inputTileTensorBytes + outputTileTensorBytes + outputBitmapBytes
    }

    fun isSafeSingleBitmapAllocation(width: Int, height: Int): Boolean {
        val required = estimateBitmapBytes(width, height, bytesPerPixel = 4)
        // Android Canvas/Bitmap allocation safety ceiling (~70% of max heap or 512 MB cap)
        val safeCeiling = (getMaxHeapBytes() * 0.70).toLong()
        return required in 1..safeCeiling
    }
}
