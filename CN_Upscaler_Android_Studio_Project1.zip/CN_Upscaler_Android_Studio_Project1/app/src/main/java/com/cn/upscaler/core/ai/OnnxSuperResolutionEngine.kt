package com.cn.upscaler.core.ai

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.Closeable
import java.nio.FloatBuffer
import java.util.Collections

/*
 * Abstraction for tile-level super-resolution inference so TileProcessor can be unit-tested
 * deterministically and backed by ONNX Runtime in production.
 */
interface TileSuperResolutionInferenceSession : Closeable {
    val modelSpec: SuperResolutionModelSpec
    val activeProviderReport: ActiveExecutionProviderReport

    /*
     * Runs genuine neural network super-resolution on a single RGB/ARGB tile of dimensions
     * `(tileWidth x tileHeight)` and returns an upscaled ARGB_8888 pixel array of dimensions
     * `(tileWidth * modelSpec.nativeScale) x (tileHeight * modelSpec.nativeScale)`.
     */
    fun inferTile(
        argbPixels: IntArray,
        tileWidth: Int,
        tileHeight: Int,
        preserveAlpha: Boolean
    ): IntArray
}

/*
 * Production ONNX Runtime Android inference engine.
 * Loads a verified `.onnx` model file into an `OrtSession` with configured hardware acceleration
 * (NNAPI / CPU fallback) and executes float32 NCHW tensor inference.
 */
class OnnxSuperResolutionEngine(
    private val verifier: OnnxModelVerifier
) {
    fun openSession(
        preferredModelId: String,
        executionPreference: ExecutionProviderPreference,
        cpuThreads: Int = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
    ): TileSuperResolutionInferenceSession {
        val availability = verifier.verifyInstalledModels(preferredModelId)
        if (availability !is ModelAvailability.Available) {
            val unavailable = availability as ModelAvailability.Unavailable
            throw IllegalStateException(unavailable.reason)
        }

        val env = OrtEnvironment.getEnvironment()
        val (options, providerReport) = HardwareAcceleratorManager.configureSessionOptions(
            preference = executionPreference,
            cpuThreadCount = cpuThreads
        )

        val session = try {
            env.createSession(availability.modelFile.absolutePath, options)
        } catch (accelError: Throwable) {
            options.close()
            val (cpuOptions, cpuReport) = HardwareAcceleratorManager.configureSessionOptions(
                preference = ExecutionProviderPreference.CPU_ONLY,
                cpuThreadCount = cpuThreads
            )
            val fallbackSession = env.createSession(availability.modelFile.absolutePath, cpuOptions)
            return OrtTileInferenceSession(
                env = env,
                initialSession = fallbackSession,
                initialOptions = cpuOptions,
                modelPath = availability.modelFile.absolutePath,
                cpuThreads = cpuThreads,
                modelSpec = availability.spec,
                inputName = availability.inputTensorName,
                initialProviderReport = cpuReport.copy(
                    requestedPreference = executionPreference,
                    fellBackToCpu = true,
                    fallbackReason = "Driver rejected accelerated graph (${accelError.message}); fell back to CPU."
                )
            )
        }

        return OrtTileInferenceSession(
            env = env,
            initialSession = session,
            initialOptions = options,
            modelPath = availability.modelFile.absolutePath,
            cpuThreads = cpuThreads,
            modelSpec = availability.spec,
            inputName = availability.inputTensorName,
            initialProviderReport = providerReport
        )
    }

    private class OrtTileInferenceSession(
        private val env: OrtEnvironment,
        initialSession: OrtSession,
        initialOptions: OrtSession.SessionOptions,
        private val modelPath: String,
        private val cpuThreads: Int,
        override val modelSpec: SuperResolutionModelSpec,
        private val inputName: String,
        initialProviderReport: ActiveExecutionProviderReport
    ) : TileSuperResolutionInferenceSession {

        private var session: OrtSession = initialSession
        private var options: OrtSession.SessionOptions = initialOptions
        override var activeProviderReport: ActiveExecutionProviderReport = initialProviderReport
            private set

        override fun inferTile(
            argbPixels: IntArray,
            tileWidth: Int,
            tileHeight: Int,
            preserveAlpha: Boolean
        ): IntArray {
            val prepared = TensorPreprocessor.preprocessTile(
                argbPixels = argbPixels,
                width = tileWidth,
                height = tileHeight,
                spec = modelSpec,
                preserveAlpha = preserveAlpha
            )

            val floatBuffer = FloatBuffer.wrap(prepared.floatData)
            OnnxTensor.createTensor(env, floatBuffer, prepared.tensorShape).use { inputTensor ->
                val outArray = try {
                    runTensorOnce(inputTensor)
                } catch (runError: Throwable) {
                    if (!activeProviderReport.fellBackToCpu &&
                        activeProviderReport.requestedPreference != ExecutionProviderPreference.CPU_ONLY
                    ) {
                        // NNAPI failed at runtime on dynamic shape; switch transparently to CPU_ONLY
                        try { session.close() } catch (_: Throwable) {}
                        try { options.close() } catch (_: Throwable) {}
                        val (cpuOpts, cpuRep) = HardwareAcceleratorManager.configureSessionOptions(
                            preference = ExecutionProviderPreference.CPU_ONLY,
                            cpuThreadCount = cpuThreads
                        )
                        options = cpuOpts
                        session = env.createSession(modelPath, cpuOpts)
                        activeProviderReport = cpuRep.copy(
                            requestedPreference = activeProviderReport.requestedPreference,
                            fellBackToCpu = true,
                            fallbackReason = "NNAPI runtime fallback to CPU (${runError.message})"
                        )
                        runTensorOnce(inputTensor)
                    } else {
                        throw runError
                    }
                }

                return TensorPreprocessor.postprocessTile(
                    outputTensorData = outArray,
                    prepared = prepared,
                    spec = modelSpec
                )
            }
        }

        private fun runTensorOnce(inputTensor: OnnxTensor): FloatArray {
            session.run(Collections.singletonMap(inputName, inputTensor)).use { result ->
                val outputValue = result.get(0) as? OnnxTensor
                    ?: throw IllegalStateException("ONNX session did not return an OnnxTensor output.")
                val outFloatBuffer = outputValue.floatBuffer
                val outArray = FloatArray(outFloatBuffer.remaining())
                outFloatBuffer.get(outArray)
                return outArray
            }
        }

        override fun close() {
            try {
                session.close()
            } catch (_: Throwable) {
            }
            try {
                options.close()
            } catch (_: Throwable) {
            }
        }
    }
}
