package com.cn.upscaler.core.image

import kotlin.math.abs

/*
 * Pure domain representation of inspected image bounds and properties prior to full decoding.
 */
data class ImageInspectionReport(
    val uriString: String,
    val filename: String,
    val rawWidth: Int,
    val rawHeight: Int,
    val exifOrientation: Int,
    val orientedWidth: Int,
    val orientedHeight: Int,
    val format: ImageFormat,
    val hasAlpha: Boolean,
    val fileSizeBytes: Long,
    val decodedMemoryBytes: Long,
    val aspectRatio: Double,
    val aspectRatioLabel: String,
    val supportedOutputFormats: List<ImageFormat>
)

sealed interface ImageValidationResult {
    data class Valid(
        val report: ImageInspectionReport,
        val warnings: List<String> = emptyList()
    ) : ImageValidationResult

    data class Invalid(
        val uriString: String,
        val reason: String,
        val errorCode: com.cn.upscaler.core.common.ErrorCode
    ) : ImageValidationResult
}

object ImageValidationRules {
    const val MIN_DIMENSION_PX = 16
    const val MAX_SOURCE_DIMENSION_PX = 16384
    const val MAX_SOURCE_PIXELS = 100_000_000L // 100 MP source guard

    fun validateBounds(
        uriString: String,
        filename: String,
        rawWidth: Int,
        rawHeight: Int,
        exifOrientation: Int,
        format: ImageFormat,
        hasAlpha: Boolean,
        fileSizeBytes: Long,
        availableHeapBytes: Long
    ): ImageValidationResult {
        if (fileSizeBytes <= 0L) {
            return ImageValidationResult.Invalid(
                uriString = uriString,
                reason = "File is empty or inaccessible (0 bytes).",
                errorCode = com.cn.upscaler.core.common.ErrorCode.FILE_NOT_FOUND
            )
        }
        if (format == ImageFormat.UNKNOWN) {
            return ImageValidationResult.Invalid(
                uriString = uriString,
                reason = "Unsupported image format. Supported formats are JPEG, PNG, and WebP.",
                errorCode = com.cn.upscaler.core.common.ErrorCode.UNSUPPORTED_FORMAT
            )
        }
        if (rawWidth <= 0 || rawHeight <= 0) {
            return ImageValidationResult.Invalid(
                uriString = uriString,
                reason = "Corrupted image header or unreadable dimensions (${rawWidth}×${rawHeight}).",
                errorCode = com.cn.upscaler.core.common.ErrorCode.CORRUPTED_IMAGE
            )
        }
        val swapsAxes = ExifOrientationHelper.swapsDimensions(exifOrientation)
        val orientedW = if (swapsAxes) rawHeight else rawWidth
        val orientedH = if (swapsAxes) rawWidth else rawHeight

        if (orientedW < MIN_DIMENSION_PX || orientedH < MIN_DIMENSION_PX) {
            return ImageValidationResult.Invalid(
                uriString = uriString,
                reason = "Image dimensions (${orientedW}×${orientedH}) are smaller than minimum ${MIN_DIMENSION_PX}×${MIN_DIMENSION_PX} px.",
                errorCode = com.cn.upscaler.core.common.ErrorCode.INVALID_DIMENSIONS
            )
        }
        val totalPixels = orientedW.toLong() * orientedH.toLong()
        if (orientedW > MAX_SOURCE_DIMENSION_PX || orientedH > MAX_SOURCE_DIMENSION_PX || totalPixels > MAX_SOURCE_PIXELS) {
            return ImageValidationResult.Invalid(
                uriString = uriString,
                reason = "Source image (${orientedW}×${orientedH}, ${totalPixels / 1_000_000} MP) exceeds safe on-device source limit (${MAX_SOURCE_DIMENSION_PX}px / 100 MP).",
                errorCode = com.cn.upscaler.core.common.ErrorCode.DIMENSION_LIMIT_EXCEEDED
            )
        }

        val decodedBytes = totalPixels * 4L
        val warnings = mutableListOf<String>()
        if (decodedBytes > availableHeapBytes / 2) {
            warnings += "Large source image requires tiled regional decoding (${decodedBytes / (1024 * 1024)} MB uncompressed)."
        }
        if (hasAlpha && format != ImageFormat.JPEG) {
            warnings += "Image contains alpha transparency. Select PNG or WebP output to preserve transparency."
        }

        val ratio = orientedW.toDouble() / orientedH.toDouble()
        val report = ImageInspectionReport(
            uriString = uriString,
            filename = filename,
            rawWidth = rawWidth,
            rawHeight = rawHeight,
            exifOrientation = exifOrientation,
            orientedWidth = orientedW,
            orientedHeight = orientedH,
            format = format,
            hasAlpha = hasAlpha,
            fileSizeBytes = fileSizeBytes,
            decodedMemoryBytes = decodedBytes,
            aspectRatio = ratio,
            aspectRatioLabel = classifyAspectRatio(orientedW, orientedH),
            supportedOutputFormats = listOf(ImageFormat.JPEG, ImageFormat.PNG, ImageFormat.WEBP)
        )
        return ImageValidationResult.Valid(report = report, warnings = warnings)
    }

    fun classifyAspectRatio(width: Int, height: Int): String {
        if (width <= 0 || height <= 0) return "Invalid"
        val r = width.toDouble() / height.toDouble()
        val candidates = listOf(
            (16.0 / 9.0) to "16:9",
            (9.0 / 16.0) to "9:16",
            (4.0 / 3.0) to "4:3",
            (3.0 / 4.0) to "3:4",
            (1.0 / 1.0) to "1:1",
            (3.0 / 2.0) to "3:2",
            (2.0 / 3.0) to "2:3",
            (21.0 / 9.0) to "21:9"
        )
        for ((target, label) in candidates) {
            if (abs(r - target) < 0.025) return label
        }
        val gcdVal = gcd(width, height)
        val rw = width / gcdVal
        val rh = height / gcdVal
        return if (rw <= 32 && rh <= 32) "$rw:$rh" else String.format("%.2f:1", r)
    }

    private tailrec fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)
}
