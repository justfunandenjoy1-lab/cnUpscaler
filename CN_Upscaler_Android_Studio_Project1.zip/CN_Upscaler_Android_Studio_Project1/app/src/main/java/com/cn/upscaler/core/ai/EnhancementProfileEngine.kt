package com.cn.upscaler.core.ai

/*
 * CRITICAL DEFINITION:
 * The 4x, 8x, and 16x options are AI Enhancement Levels (processing profiles),
 * NOT geometric width/height multipliers.
 * They never multiply original width or height by 4, 8, or 16; final dimensions are
 * strictly governed by TargetResolution.
 */
enum class EnhancementLevel(
    val id: String,
    val displayName: String,
    val shortBadge: String,
    val technicalSummary: String
) {
    LEVEL_4X(
        id = "ENHANCE_4X",
        displayName = "4× AI Enhancement",
        shortBadge = "4× AI Profile",
        technicalSummary = "Single-pass native 4× RRDBNet/SRVGGNet super-resolution inference followed by exact target resolution fitting."
    ),
    LEVEL_8X(
        id = "ENHANCE_8X",
        displayName = "8× AI Enhancement",
        shortBadge = "8× AI Profile",
        technicalSummary = "Dual-stage cascaded AI inference (primary structural reconstruction + secondary detail refinement pass with intermediate anti-aliased rescaling)."
    ),
    LEVEL_16X(
        id = "ENHANCE_16X",
        displayName = "16× AI Enhancement",
        shortBadge = "16× AI Profile",
        technicalSummary = "Extreme multi-stage generative super-resolution profile (requires dedicated multi-stage model pack; disabled when unverified)."
    );

    companion object {
        fun fromId(id: String): EnhancementLevel = entries.find { it.id == id } ?: LEVEL_4X
    }
}

/*
 * Describes verified capabilities of an installed on-device super-resolution model set.
 */
data class ModelCapabilities(
    val primaryModelAvailable: Boolean,
    val primaryModelId: String,
    val primaryModelName: String,
    val primaryModelVersion: String,
    val primaryNativeScale: Int,
    val secondaryRefinementModelAvailable: Boolean,
    val secondaryModelId: String?,
    val supportsMultiPass8xProfile: Boolean,
    val supportsExtreme16xProfile: Boolean
)

/*
 * Strategy pattern representing the actual verified execution plan for an EnhancementLevel.
 */
sealed interface EnhancementStrategy {
    val level: EnhancementLevel
    val isSupported: Boolean
    val stagesDescription: String
    val limitationNotice: String?

    data class SinglePassEnhancementStrategy(
        override val level: EnhancementLevel = EnhancementLevel.LEVEL_4X,
        val modelId: String,
        val modelName: String,
        val modelVersion: String,
        val nativeScale: Int = 4
    ) : EnhancementStrategy {
        override val isSupported: Boolean = true
        override val stagesDescription: String =
            "Stage 1: $modelName ($modelVersion, native ${nativeScale}× ONNX inference) -> Stage 2: Exact Target Resolution Bicubic/Lanczos Fit"
        override val limitationNotice: String? = null
    }

    data class MultiPassEnhancementStrategy(
        override val level: EnhancementLevel = EnhancementLevel.LEVEL_8X,
        val firstPassModelId: String,
        val secondPassModelId: String,
        val modelName: String,
        val modelVersion: String,
        val intermediateDownsampleFactor: Float = 0.5f
    ) : EnhancementStrategy {
        override val isSupported: Boolean = true
        override val stagesDescription: String =
            "Stage 1: Primary 4× AI Pass ($firstPassModelId) -> Stage 2: 0.5× Anti-Aliased Intermediate Conditioning -> Stage 3: Secondary 4× AI Texture Pass ($secondPassModelId) -> Stage 4: Exact Target Resolution Fit"
        override val limitationNotice: String =
            "Two-pass cascaded inference doubles inference time and reconstructs finer high-frequency edges, while final pixel dimensions remain strictly governed by your selected Target Resolution."
    }

    data class UnsupportedEnhancementStrategy(
        override val level: EnhancementLevel,
        val reason: String
    ) : EnhancementStrategy {
        override val isSupported: Boolean = false
        override val stagesDescription: String = "Unavailable ($reason)"
        override val limitationNotice: String = reason
    }
}

data class EnhancementProfile(
    val level: EnhancementLevel,
    val strategy: EnhancementStrategy
) {
    val isAvailable: Boolean get() = strategy.isSupported
}

/*
 * Resolves the honest, verified EnhancementProfile for each EnhancementLevel based on
 * the currently installed and verified on-device ONNX models.
 * Never fabricates quality levels or substitutes ordinary sharpening for AI inference.
 */
class EnhancementProfileResolver {

    fun resolveProfiles(capabilities: ModelCapabilities): List<EnhancementProfile> {
        return EnhancementLevel.entries.map { level ->
            resolveProfile(level, capabilities)
        }
    }

    fun resolveProfile(
        level: EnhancementLevel,
        capabilities: ModelCapabilities
    ): EnhancementProfile {
        if (!capabilities.primaryModelAvailable) {
            return EnhancementProfile(
                level = level,
                strategy = EnhancementStrategy.UnsupportedEnhancementStrategy(
                    level = level,
                    reason = "No verified ONNX super-resolution model is installed on this device. Import RealESRGAN_x4plus.onnx in Settings to enable AI processing."
                )
            )
        }

        return when (level) {
            EnhancementLevel.LEVEL_4X -> EnhancementProfile(
                level = level,
                strategy = EnhancementStrategy.SinglePassEnhancementStrategy(
                    level = level,
                    modelId = capabilities.primaryModelId,
                    modelName = capabilities.primaryModelName,
                    modelVersion = capabilities.primaryModelVersion,
                    nativeScale = capabilities.primaryNativeScale
                )
            )

            EnhancementLevel.LEVEL_8X -> {
                if (capabilities.supportsMultiPass8xProfile) {
                    val secondModel = capabilities.secondaryModelId ?: capabilities.primaryModelId
                    EnhancementProfile(
                        level = level,
                        strategy = EnhancementStrategy.MultiPassEnhancementStrategy(
                            level = level,
                            firstPassModelId = capabilities.primaryModelId,
                            secondPassModelId = secondModel,
                            modelName = capabilities.primaryModelName,
                            modelVersion = capabilities.primaryModelVersion
                        )
                    )
                } else {
                    EnhancementProfile(
                        level = level,
                        strategy = EnhancementStrategy.UnsupportedEnhancementStrategy(
                            level = level,
                            reason = "8× AI Enhancement requires multi-pass cascaded inference support, which is currently disabled for the active model/memory configuration."
                        )
                    )
                }
            }

            EnhancementLevel.LEVEL_16X -> {
                if (capabilities.supportsExtreme16xProfile) {
                    // Only enabled if a verified 16x multi-stage model pack is explicitly present
                    EnhancementProfile(
                        level = level,
                        strategy = EnhancementStrategy.MultiPassEnhancementStrategy(
                            level = level,
                            firstPassModelId = capabilities.primaryModelId,
                            secondPassModelId = capabilities.secondaryModelId ?: capabilities.primaryModelId,
                            modelName = capabilities.primaryModelName,
                            modelVersion = capabilities.primaryModelVersion,
                            intermediateDownsampleFactor = 1.0f
                        )
                    )
                } else {
                    EnhancementProfile(
                        level = level,
                        strategy = EnhancementStrategy.UnsupportedEnhancementStrategy(
                            level = level,
                            reason = "16× AI Enhancement is unavailable: the installed ${capabilities.primaryModelName} (${capabilities.primaryNativeScale}× native RRDBNet) model does not genuinely support a separate 16× detail-synthesis profile without compounding artifacts. CN Upscaler never fakes enhancement profiles."
                        )
                    )
                }
            }
        }
    }
}
