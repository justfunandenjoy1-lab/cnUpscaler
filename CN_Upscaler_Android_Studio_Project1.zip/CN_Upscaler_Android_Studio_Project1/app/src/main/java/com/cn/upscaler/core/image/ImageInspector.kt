package com.cn.upscaler.core.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import com.cn.upscaler.core.common.ErrorCode
import com.cn.upscaler.core.common.MemoryBudgetMonitor

/*
 * Inspects image headers via BitmapFactory.Options(inJustDecodeBounds = true) and ExifInterface
 * without allocating full-resolution Bitmaps in memory.
 */
class ImageInspector(
    private val context: Context,
    private val memoryMonitor: MemoryBudgetMonitor
) {
    fun inspect(uri: Uri): ImageValidationResult {
        val resolver = context.contentResolver
        val (filename, fileSize) = queryDisplayNameAndSize(uri)
        val mimeType = resolver.getType(uri)

        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        try {
            resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
                true
            } ?: return ImageValidationResult.Invalid(
                uriString = uri.toString(),
                reason = "Unable to open input stream for selected URI.",
                errorCode = ErrorCode.FILE_NOT_FOUND
            )
        } catch (sec: SecurityException) {
            return ImageValidationResult.Invalid(
                uriString = uri.toString(),
                reason = "Read permission revoked or inaccessible URI: ${sec.message}",
                errorCode = ErrorCode.PERMISSION_REVOKED
            )
        } catch (t: Throwable) {
            return ImageValidationResult.Invalid(
                uriString = uri.toString(),
                reason = "Failed to inspect image header: ${t.message}",
                errorCode = ErrorCode.CORRUPTED_IMAGE
            )
        }

        val detectedFormat = ImageFormat.fromMimeTypeOrName(
            options.outMimeType ?: mimeType,
            filename
        )
        val exifOrientation = try {
            resolver.openInputStream(uri)?.use { stream ->
                ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Throwable) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val hasAlpha = options.outConfig == Bitmap.Config.ARGB_8888 &&
            (detectedFormat == ImageFormat.PNG || detectedFormat == ImageFormat.WEBP)

        return ImageValidationRules.validateBounds(
            uriString = uri.toString(),
            filename = filename,
            rawWidth = options.outWidth,
            rawHeight = options.outHeight,
            exifOrientation = exifOrientation,
            format = detectedFormat,
            hasAlpha = hasAlpha,
            fileSizeBytes = fileSize,
            availableHeapBytes = memoryMonitor.getAvailableHeapBytes()
        )
    }

    private fun queryDisplayNameAndSize(uri: Uri): Pair<String, Long> {
        var displayName = uri.lastPathSegment?.substringAfterLast('/') ?: "image"
        var size = -1L
        try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0 && !cursor.isNull(nameIdx)) {
                        displayName = cursor.getString(nameIdx)
                    }
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                        size = cursor.getLong(sizeIdx)
                    }
                }
            }
        } catch (_: Throwable) {
            // Fallback to file descriptor length below
        }
        if (size <= 0L) {
            try {
                context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                    size = afd.length
                }
            } catch (_: Throwable) {
                // Handled by validation
            }
        }
        return displayName to size
    }
}
