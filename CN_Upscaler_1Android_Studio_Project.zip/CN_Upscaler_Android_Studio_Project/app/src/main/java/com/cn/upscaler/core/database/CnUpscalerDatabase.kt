package com.cn.upscaler.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [JobEntity::class],
    version = 71,
    exportSchema = false
)
abstract class CnUpscalerDatabase : RoomDatabase() {
    abstract fun jobDao(): JobDao

    companion object {
        private const val DB_NAME = "cn_upscaler_jobs.db"

        fun create(context: Context): CnUpscalerDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                CnUpscalerDatabase::class.java,
                DB_NAME
            )
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}
