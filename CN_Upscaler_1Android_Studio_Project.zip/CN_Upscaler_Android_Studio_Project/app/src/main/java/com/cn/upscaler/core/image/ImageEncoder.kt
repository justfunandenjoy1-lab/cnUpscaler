package com.cn.upscaler.core.image

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import com.cn.upscaler.core.common.AppResult
import com.cn.upscaler.core.common.ErrorCode
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

data class EncodingConfig(
    val format: ImageFormat = ImageFormat.JPEG,
    val jpegQuality: Int = DEFAULT_JPEG_QUALITY,
    val webpQuality: Int = 95
) {
    init {
        require(jpegQuality in MIN_JPEG_QUALITY..MAX_JPEG_QUALITY) {
            "JPEG quality ($jpegQuality) must be between $MIN_JPEG_QUALITY and $MAX_JPEG_QUALITY."
        }
    }

    companion object {
        const val MIN_JPEG_QUALITY = 70
        const val MAX_JPEG_QUALITY = 100
        const val DEFAULT_JPEG_QUALITY = 95
    }
}

data class EncodedImageVerification(
    val outputFile: File,
    val format: ImageFormat,
    val verifiedWidth: Int,
    val verifiedHeight: Int,
    val fileSizeBytes: Long,
    val transparencyPreserved: Boolean,
    val transparencyDiscardedWarning: String?
)

/*
 * v80 Adobe Stock QC-Pass Encoder:
 * Uses JPEG Quality 94-95 (with a strict minimum floor of Quality 92) so 100% (1:1) zoom
 * inspection on Adobe Stock / Shutterstock shows ZERO 8x8 DCT quantization blocks or chroma
 * subsampling artifacts, while keeping 4K UHD files balanced around 2.8 MB - 5.5 MB.
 */
object ImageEncoder {

    fun encodeToFile(
        bitmap: Bitmap,
        destFile: File,
        config: EncodingConfig,
        sourceHasAlpha: Boolean
    ): AppResult<EncodedImageVerification> {
        val usableSpace = destFile.parentFile?.usableSpace ?: Long.MAX_VALUE
        val minRequiredSpace = (bitmap.width.toLong() * bitmap.height.toLong() * 2L).coerceAtLeast(8L * 1024L * 1024L)
        if (usableSpace < minRequiredSpace) {
            return AppResult.Error(
                message = "Insufficient device storage space (${usableSpace / (1024 * 1024)} MB free).",
                errorCode = ErrorCode.INSUFFICIENT_STORAGE
            )
        }

        val transparencyWarning = if (sourceHasAlpha && !config.format.supportsTransparency) {
            "Source image contained alpha transparency, which was flattened because ${config.format.displayName} does not support transparency."
        } else {
            null
        }

        val compressFormat = resolveCompressFormat(config.format, config.webpQuality)
        val initialQuality = when (config.format) {
            ImageFormat.JPEG -> config.jpegQuality.coerceIn(92, EncodingConfig.MAX_JPEG_QUALITY)
            ImageFormat.PNG -> 100
            ImageFormat.WEBP -> config.webpQuality.coerceIn(90, 100)
            ImageFormat.UNKNOWN -> EncodingConfig.DEFAULT_JPEG_QUALITY
        }

        // Balanced Adobe Stock QC-compliant ceiling (never drops below Quality 92 so 8x8 DCT blocks never appear):
        val pixels = bitmap.width.toLong() * bitmap.height.toLong()
        val maxBalancedBytes: Long = when {
            pixels <= 5_000_000L  -> 3_200_000L  // <= 2K UHD: ~2.0 - 3.2 MB
            pixels <= 10_000_000L -> 5_500_000L  // <= 4K UHD: ~3.0 - 5.5 MB
            pixels <= 20_000_000L -> 9_500_000L  // <= 8K UHD: ~5.5 - 9.5 MB
            else                  -> 14_000_000L // 16K UHD:   ~8.0 - 14.0 MB
        }

        try {
            if (config.format == ImageFormat.JPEG || config.format == ImageFormat.WEBP) {
                val baos = ByteArrayOutputStream(3 * 1024 * 1024)
                var curQ = initialQuality.coerceIn(92, 95)
                var encodedBytes: ByteArray
                while (true) {
                    baos.reset()
                    val ok = bitmap.compress(compressFormat, curQ, baos)
                    if (!ok) {
                        destFile.delete()
                        return AppResult.Error(
                            message = "Android Bitmap.compress failed for format ${config.format.displayName}.",
                            errorCode = ErrorCode.ENCODING_FAILED
                        )
                    }
                    encodedBytes = baos.toByteArray()
                    if (encodedBytes.size <= maxBalancedBytes || curQ <= 92) {
                        break
                    }
                    curQ = (curQ - 1).coerceAtLeast(92)
                }
                FileOutputStream(destFile).use { fos ->
                    fos.write(encodedBytes)
                    fos.flush()
                }
            } else {
                FileOutputStream(destFile).use { fos ->
                    val ok = bitmap.compress(compressFormat, initialQuality, fos)
                    fos.flush()
                    if (!ok) {
                        destFile.delete()
                        return AppResult.Error(
                            message = "Android Bitmap.compress failed for format ${config.format.displayName}.",
                            errorCode = ErrorCode.ENCODING_FAILED
                        )
                    }
                }
            }
        } catch (t: Throwable) {
            destFile.delete()
            return AppResult.Error(
                message = "I/O error while encoding image: ${t.message}",
                cause = t,
                errorCode = ErrorCode.ENCODING_FAILED
            )
        }

        val verifyOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(destFile.absolutePath, verifyOptions)
        if (verifyOptions.outWidth != bitmap.width || verifyOptions.outHeight != bitmap.height) {
            return AppResult.Error(
                message = "Post-encode verification mismatch: expected ${bitmap.width}×${bitmap.height}, found ${verifyOptions.outWidth}×${verifyOptions.outHeight}.",
                errorCode = ErrorCode.ENCODING_FAILED
            )
        }

        return AppResult.Success(
            EncodedImageVerification(
                outputFile = destFile,
                format = config.format,
                verifiedWidth = verifyOptions.outWidth,
                verifiedHeight = verifyOptions.outHeight,
                fileSizeBytes = destFile.length(),
                transparencyPreserved = sourceHasAlpha && config.format.supportsTransparency,
                transparencyDiscardedWarning = transparencyWarning
            )
        )
    }

    @Suppress("DEPRECATION")
    private fun resolveCompressFormat(format: ImageFormat, webpQuality: Int): Bitmap.CompressFormat {
        return when (format) {
            ImageFormat.JPEG, ImageFormat.UNKNOWN -> Bitmap.CompressFormat.JPEG
            ImageFormat.PNG -> Bitmap.CompressFormat.PNG
            ImageFormat.WEBP -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (webpQuality >= 100) {
                        Bitmap.CompressFormat.WEBP_LOSSLESS
                    } else {
                        Bitmap.CompressFormat.WEBP_LOSSY
                    }
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
        }
    }
}
