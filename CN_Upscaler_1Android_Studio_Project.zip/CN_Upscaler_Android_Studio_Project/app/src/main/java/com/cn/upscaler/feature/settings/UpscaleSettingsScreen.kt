package com.cn.upscaler.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cn.upscaler.app.MainUiState
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.common.MemoryBudgetMonitor
import com.cn.upscaler.core.designsystem.MetricPill
import com.cn.upscaler.core.designsystem.WarningBanner
import com.cn.upscaler.core.designsystem.formatBytes
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.metadata.UserMetadataConfig
import com.cn.upscaler.core.processing.PostProcessingConfig
import com.cn.upscaler.core.processing.ResolutionCalculator
import com.cn.upscaler.core.processing.TargetResolution
import kotlin.math.roundToInt

private data class AiPresetOption(
    val id: String,
    val label: String,
    val noiseReduction: Float,
    val deblur: Float,
    val sharpness: Float,
    val facePreservation: Float
)

private val AI_MODEL_PRESETS = listOf(
    AiPresetOption("PORTRAIT", "Portrait & Face", 0.65f, 0.80f, 0.78f, 0.90f),
    AiPresetOption("GENERAL", "General Photo", 0.60f, 0.80f, 0.78f, 0.88f),
    AiPresetOption("OLD_PHOTO", "Old Photo Restore", 0.82f, 0.82f, 0.72f, 0.90f),
    AiPresetOption("LOW_LIGHT", "Low-Light Denoise", 0.92f, 0.68f, 0.58f, 0.90f),
    AiPresetOption("LANDSCAPE", "Landscape & Product", 0.35f, 0.80f, 0.78f, 0.88f),
    AiPresetOption("TEXT", "Design, Logo & Text", 0.30f, 0.85f, 0.82f, 0.96f)
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UpscaleSettingsScreen(
    uiState: MainUiState,
    memoryMonitor: MemoryBudgetMonitor,
    onSelectTargetResolution: (TargetResolution) -> Unit,
    onSelectEnhancementLevel: (EnhancementLevel) -> Unit,
    onUpdateOutputFormat: (ImageFormat, Int) -> Unit,
    onUpdateUserMetadata: (UserMetadataConfig) -> Unit,
    onUpdatePostProcessing: (PostProcessingConfig) -> Unit,
    onStartBatchProcessing: () -> Unit
) {
    val validCandidates = uiState.selectedCandidates.filter { it.isValid }
    val primaryReport = validCandidates.firstOrNull()?.inspectionReport
    val currentSettings = uiState.settings
    val post = currentSettings.postProcessingConfig

    var selectedPreset by remember { mutableStateOf(post.aiModelPreset) }
    var enableDenoise by remember { mutableStateOf(post.enableSubtleDenoise) }
    var enableSharp by remember { mutableStateOf(post.enableUnsharpMask) }
    var noiseSlider by remember { mutableFloatStateOf(post.aiNoiseReduction) }
    var deblurSlider by remember { mutableFloatStateOf(post.aiDeblurStrength) }
    var sharpSlider by remember { mutableFloatStateOf(post.aiSharpnessStrength) }
    var faceSlider by remember { mutableFloatStateOf(post.aiFacePreservation) }

    LaunchedEffect(post) {
        selectedPreset = post.aiModelPreset
        enableDenoise = post.enableSubtleDenoise
        enableSharp = post.enableUnsharpMask
        noiseSlider = post.aiNoiseReduction
        deblurSlider = post.aiDeblurStrength
        sharpSlider = post.aiSharpnessStrength
        faceSlider = post.aiFacePreservation
    }

    fun emitPostUpdate(
        preset: String = selectedPreset,
        denoiseOn: Boolean = enableDenoise,
        sharpOn: Boolean = enableSharp,
        noise: Float = noiseSlider,
        deblur: Float = deblurSlider,
        sharp: Float = sharpSlider,
        face: Float = faceSlider
    ) {
        onUpdatePostProcessing(
            post.copy(
                enableSubtleDenoise = denoiseOn,
                enableUnsharpMask = sharpOn,
                aiModelPreset = preset,
                aiNoiseReduction = noise.coerceIn(0f, 1f),
                denoiseStrength = noise.coerceIn(0f, 1f),
                aiDeblurStrength = deblur.coerceIn(0f, 1f),
                aiSharpnessStrength = sharp.coerceIn(0f, 1f),
                sharpenAmount = (sharp * 0.50f).coerceIn(0f, 0.50f),
                aiFacePreservation = face.coerceIn(0f, 1f)
            )
        )
    }

    val samplePlan = remember(
        primaryReport,
        currentSettings.defaultTargetResolution,
        currentSettings.defaultEnhancementLevel,
        currentSettings.defaultOutputFormat,
        currentSettings.tileSize
    ) {
        if (primaryReport != null) {
            ResolutionCalculator.calculate(
                sourceWidth = primaryReport.orientedWidth,
                sourceHeight = primaryReport.orientedHeight,
                target = currentSettings.defaultTargetResolution,
                outputFormat = currentSettings.defaultOutputFormat,
                nativeModelScale = uiState.modelCapabilities.primaryNativeScale,
                tileSize = currentSettings.tileSize,
                availableHeapBytes = memoryMonitor.getMaxHeapBytes(),
                enhancementLevel = currentSettings.defaultEnhancementLevel
            )
        } else {
            ResolutionCalculator.calculate(
                sourceWidth = 1920,
                sourceHeight = 1080,
                target = currentSettings.defaultTargetResolution,
                outputFormat = currentSettings.defaultOutputFormat,
                nativeModelScale = 4,
                tileSize = currentSettings.tileSize,
                availableHeapBytes = memoryMonitor.getMaxHeapBytes(),
                enhancementLevel = currentSettings.defaultEnhancementLevel
            )
        }
    }

    val activeProfile = uiState.enhancementProfiles.find {
        it.level == currentSettings.defaultEnhancementLevel
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Upscale & AI Profile Configuration",
            style = MaterialTheme.typography.titleLarge
        )

        // Section 1: Target Resolution
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "1. Target Output Resolution (Final Dimensions)",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Determines exact final output pixel dimensions while preserving the original aspect ratio without stretching.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TargetResolution.entries.forEach { target ->
                        FilterChip(
                            selected = currentSettings.defaultTargetResolution == target,
                            onClick = { onSelectTargetResolution(target) },
                            label = { Text(target.label) }
                        )
                    }
                }
            }
        }

        // Section 2: AI Enhancement Level
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "2. AI Enhancement Level (Neural Processing Profile)",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Selects the AI inference strategy. Does NOT multiply output dimensions by 4, 8, or 16.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EnhancementLevel.entries.forEach { level ->
                        FilterChip(
                            selected = currentSettings.defaultEnhancementLevel == level,
                            onClick = { onSelectEnhancementLevel(level) },
                            enabled = true,
                            label = { Text(level.displayName) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                if (activeProfile != null) {
                    Text(
                        text = "Active Pipeline Strategy: ${activeProfile.strategy.stagesDescription}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Section 3: AI Model Selection & Professional Restoration Controls (All 6 Controls Synced!)
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "3. AI Model Mode & Fine Quality Controls",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Every toggle and slider below directly controls the v70 Zero-Distortion Super-Resolution Engine (${post.describeActiveOperations()}).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AI_MODEL_PRESETS.forEach { preset ->
                        FilterChip(
                            selected = selectedPreset == preset.id,
                            onClick = {
                                selectedPreset = preset.id
                                noiseSlider = preset.noiseReduction
                                deblurSlider = preset.deblur
                                sharpSlider = preset.sharpness
                                faceSlider = preset.facePreservation
                                emitPostUpdate(
                                    preset = preset.id,
                                    noise = preset.noiseReduction,
                                    deblur = preset.deblur,
                                    sharp = preset.sharpness,
                                    face = preset.facePreservation
                                )
                            },
                            label = { Text(preset.label) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enable Coherent-Bilateral Noise Reduction", fontWeight = FontWeight.Medium)
                    Switch(
                        checked = enableDenoise,
                        onCheckedChange = {
                            enableDenoise = it
                            emitPostUpdate(denoiseOn = it)
                        }
                    )
                }
                if (enableDenoise) {
                    Text(
                        text = "Noise Reduction (দানাদার নয়েজ কমানো): ${(noiseSlider * 100).roundToInt()}%",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Slider(
                        value = noiseSlider,
                        onValueChange = {
                            noiseSlider = it.coerceIn(0f, 1f)
                            emitPostUpdate(noise = noiseSlider)
                        },
                        valueRange = 0f..1f
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Deblurring & Sub-Pixel IBP Clarity (ঝাপসা ভাব কমানো): ${(deblurSlider * 100).roundToInt()}%",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = deblurSlider,
                    onValueChange = {
                        deblurSlider = it.coerceIn(0f, 1f)
                        emitPostUpdate(deblur = deblurSlider)
                    },
                    valueRange = 0f..1f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enable Edge-Aware Sharpness", fontWeight = FontWeight.Medium)
                    Switch(
                        checked = enableSharp,
                        onCheckedChange = {
                            enableSharp = it
                            emitPostUpdate(sharpOn = it)
                        }
                    )
                }
                if (enableSharp) {
                    Text(
                        text = "Edge-Aware Sharpness (Halo-মুক্ত শার্পনেস): ${(sharpSlider * 100).roundToInt()}%",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Slider(
                        value = sharpSlider,
                        onValueChange = {
                            sharpSlider = it.coerceIn(0f, 1f)
                            emitPostUpdate(sharp = sharpSlider)
                        },
                        valueRange = 0f..1f
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Face, Eye & Hair Identity Preservation (মুখ ও চোখ সংরক্ষণ): ${(faceSlider * 100).roundToInt()}%",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = faceSlider,
                    onValueChange = {
                        faceSlider = it.coerceIn(0f, 1f)
                        emitPostUpdate(face = faceSlider)
                    },
                    valueRange = 0f..1f
                )
            }
        }

        // Section 4: Live Resolution & Memory Calculation Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (primaryReport != null) {
                        "Calculated Output Preview (${primaryReport.filename})"
                    } else {
                        "Calculated Output Preview (1920 × 1080 Reference)"
                    },
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricPill("Original", "${samplePlan.sourceWidth} × ${samplePlan.sourceHeight}")
                    MetricPill("Target", samplePlan.targetResolution.shortLabel)
                    MetricPill("Final Output", "${samplePlan.outputWidth} × ${samplePlan.outputHeight}")
                    MetricPill(
                        "Pixel Count",
                        String.format("%.2f MP", samplePlan.estimatedOutputPixels / 1_000_000.0)
                    )
                    MetricPill("Est. File Size", formatBytes(samplePlan.estimatedStorageBytes))
                    MetricPill("Est. Peak RAM", formatBytes(samplePlan.estimatedPeakMemoryBytes))
                }
            }
        }

        // Section 5: Output Encoding Format & Quality
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("4. Output Encoding Format", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ImageFormat.JPEG, ImageFormat.PNG, ImageFormat.WEBP).forEach { fmt ->
                        FilterChip(
                            selected = currentSettings.defaultOutputFormat == fmt,
                            onClick = { onUpdateOutputFormat(fmt, currentSettings.jpegQuality) },
                            label = { Text(fmt.displayName) }
                        )
                    }
                }
                if (currentSettings.defaultOutputFormat == ImageFormat.JPEG) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "JPEG Quality: ${currentSettings.jpegQuality} (Default: 98, Range: 80–100)",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Slider(
                        value = currentSettings.jpegQuality.toFloat(),
                        onValueChange = {
                            onUpdateOutputFormat(ImageFormat.JPEG, it.roundToInt().coerceIn(80, 100))
                        },
                        valueRange = 80f..100f,
                        steps = 19
                    )
                }
                if (validCandidates.any { it.inspectionReport?.hasAlpha == true } &&
                    !currentSettings.defaultOutputFormat.supportsTransparency
                ) {
                    WarningBanner(
                        title = "Transparency Flattening Warning",
                        messages = listOf(
                            "One or more selected images contain alpha transparency. Select PNG or WebP to preserve alpha channels."
                        )
                    )
                }
            }
        }

        // Section 6: Metadata & Privacy Controls
        MetadataEditorCard(
            config = currentSettings.userMetadataConfig,
            onUpdate = onUpdateUserMetadata
        )

        Button(
            onClick = onStartBatchProcessing,
            enabled = validCandidates.isNotEmpty(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Start AI Super-Resolution (${validCandidates.size} image${if (validCandidates.size == 1) "" else "s"})",
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun MetadataEditorCard(
    config: UserMetadataConfig,
    onUpdate: (UserMetadataConfig) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var titleText by remember { mutableStateOf(config.title) }
    var authorText by remember { mutableStateOf(config.author) }
    var descriptionText by remember { mutableStateOf(config.description) }
    var keywordsText by remember { mutableStateOf(config.keywords) }
    var copyrightText by remember { mutableStateOf(config.copyright) }
    var stripGps by remember { mutableStateOf(config.stripSensitiveLocationMetadata) }
    var syncedFromDisk by remember { mutableStateOf(false) }

    if (!syncedFromDisk && (
        config.title.isNotEmpty() ||
        config.author.isNotEmpty() ||
        config.description.isNotEmpty() ||
        config.keywords.isNotEmpty() ||
        config.copyright.isNotEmpty()
    )) {
        titleText = config.title
        authorText = config.author
        descriptionText = config.description
        keywordsText = config.keywords
        copyrightText = config.copyright
        stripGps = config.stripSensitiveLocationMetadata
        syncedFromDisk = true
    }

    fun emitCurrentMetadata() {
        onUpdate(
            config.copy(
                title = titleText,
                author = authorText,
                description = descriptionText,
                keywords = keywordsText,
                copyright = copyrightText,
                stripSensitiveLocationMetadata = stripGps
            )
        )
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("5. Metadata & Privacy Engine", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "Writes Software=CN Upscaler, AI model provenance, and dimensions. Strips GPS location by default.",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = stripGps,
                    onCheckedChange = {
                        stripGps = it
                        syncedFromDisk = true
                        emitCurrentMetadata()
                    }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            FilterChip(
                selected = expanded,
                onClick = { expanded = !expanded },
                label = { Text(if (expanded) "Hide Optional User Metadata Fields" else "Edit Optional Title / Author / Copyright") }
            )
            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = titleText,
                    onValueChange = {
                        titleText = it
                        syncedFromDisk = true
                        emitCurrentMetadata()
                    },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = authorText,
                    onValueChange = {
                        authorText = it
                        syncedFromDisk = true
                        emitCurrentMetadata()
                    },
                    label = { Text("Author / Artist") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = descriptionText,
                    onValueChange = {
                        descriptionText = it
                        syncedFromDisk = true
                        emitCurrentMetadata()
                    },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = keywordsText,
                    onValueChange = {
                        keywordsText = it
                        syncedFromDisk = true
                        emitCurrentMetadata()
                    },
                    label = { Text("Keywords (comma-separated)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = copyrightText,
                    onValueChange = {
                        copyrightText = it
                        syncedFromDisk = true
                        emitCurrentMetadata()
                    },
                    label = { Text("Copyright") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
