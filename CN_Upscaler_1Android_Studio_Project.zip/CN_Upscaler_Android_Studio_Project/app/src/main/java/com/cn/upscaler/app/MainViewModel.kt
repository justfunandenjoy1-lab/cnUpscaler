package com.cn.upscaler.app

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.ai.EnhancementProfile
import com.cn.upscaler.core.ai.ExecutionProviderPreference
import com.cn.upscaler.core.ai.ModelAvailability
import com.cn.upscaler.core.ai.ModelCapabilities
import com.cn.upscaler.core.ai.SupportedModelCatalog
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.image.ImageValidationResult
import com.cn.upscaler.core.metadata.UserMetadataConfig
import com.cn.upscaler.core.processing.PostProcessingConfig
import com.cn.upscaler.core.processing.TargetResolution
import com.cn.upscaler.domain.model.AppSettings
import com.cn.upscaler.domain.model.SelectedImageCandidate
import com.cn.upscaler.domain.model.ThemeMode
import com.cn.upscaler.domain.model.UpscaleJob
import com.cn.upscaler.worker.BatchUpscaleWorker
import java.util.UUID
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class MainUiState(
    val settings: AppSettings = AppSettings(),
    val modelAvailability: ModelAvailability = ModelAvailability.Unavailable(
        expectedSpecs = SupportedModelCatalog.ALL_SPECS,
        checkedLocations = emptyList(),
        reason = "Initializing Super-Resolution Engine..."
    ),
    val modelCapabilities: ModelCapabilities = ModelCapabilities(
        primaryModelAvailable = true,
        primaryModelId = SupportedModelCatalog.REAL_ESRGAN_X4_PLUS.id,
        primaryModelName = "Hybrid Bicubic + Diagonal NEDI + IBP Super-Resolution Engine",
        primaryModelVersion = "v41.0-True-Pixel-SR",
        primaryNativeScale = 4,
        secondaryRefinementModelAvailable = true,
        secondaryModelId = SupportedModelCatalog.REAL_ESR_GENERAL_X4_V3.id,
        supportsMultiPass8xProfile = true,
        supportsExtreme16xProfile = true
    ),
    val enhancementProfiles: List<EnhancementProfile> = emptyList(),
    val selectedCandidates: List<SelectedImageCandidate> = emptyList(),
    val activeQueue: List<UpscaleJob> = emptyList(),
    val historyJobs: List<UpscaleJob> = emptyList(),
    val focusedResultJobId: String? = null,
    val statusBannerMessage: String? = null
)

class MainViewModel(
    private val appContext: Context,
    private val container: AppContainer
) : ViewModel() {

    private val _selectedCandidates = MutableStateFlow<List<SelectedImageCandidate>>(emptyList())
    private val _modelAvailability = MutableStateFlow<ModelAvailability>(
        container.modelVerifier.verifyInstalledModels()
    )
    private val _focusedResultJobId = MutableStateFlow<String?>(null)
    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    private var metadataSaveJob: Job? = null
    private var postSaveJob: Job? = null
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    private val baseFlow = combine(
        container.settingsRepository.settingsFlow,
        _modelAvailability,
        _selectedCandidates,
        container.jobRepository.activeQueueFlow,
        container.jobRepository.historyFlow
    ) { settings, availability, candidates, activeQueue, history ->
        val capabilities = container.modelVerifier.resolveCapabilities(
            availability = availability,
            enableMultiPass8x = true
        )
        val profiles = container.profileResolver.resolveProfiles(capabilities)
        MainUiState(
            settings = settings,
            modelAvailability = availability,
            modelCapabilities = capabilities,
            enhancementProfiles = profiles,
            selectedCandidates = candidates,
            activeQueue = activeQueue,
            historyJobs = history
        )
    }

    val uiState: StateFlow<MainUiState> = combine(
        baseFlow,
        _focusedResultJobId,
        _statusBannerMessage
    ) { base, focusedId, banner ->
        base.copy(
            focusedResultJobId = focusedId,
            statusBannerMessage = banner
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MainUiState()
    )

    init {
        refreshModelStatus()
    }

    fun refreshModelStatus() {
        viewModelScope.launch {
            val currentSettings = container.settingsRepository.getCurrentSettings()
            val availability = withContext(container.dispatchers.io) {
                container.modelVerifier.verifyInstalledModels(currentSettings.preferredModelId)
            }
            _modelAvailability.value = availability
        }
    }

    fun importOnnxModel(uri: Uri, targetModelId: String) {
        viewModelScope.launch {
            val spec = SupportedModelCatalog.findById(targetModelId)
            val result = withContext(container.dispatchers.io) {
                container.modelVerifier.importModelFromUri(uri, spec)
            }
            _modelAvailability.value = result
            _statusBannerMessage.value = "Activated ${spec.displayName} engine."
        }
    }

    fun clearBannerMessage() {
        _statusBannerMessage.value = null
    }

    fun onImagesPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val inspected = withContext(container.dispatchers.io) {
                uris.map { uri ->
                    container.safUriPermissionManager.takePersistableReadPermissionIfSupported(uri)
                    when (val res = container.imageInspector.inspect(uri)) {
                        is ImageValidationResult.Valid -> SelectedImageCandidate(
                            id = UUID.randomUUID().toString(),
                            uriString = uri.toString(),
                            inspectionReport = res.report,
                            validationWarnings = res.warnings,
                            validationError = null
                        )
                        is ImageValidationResult.Invalid -> SelectedImageCandidate(
                            id = UUID.randomUUID().toString(),
                            uriString = uri.toString(),
                            inspectionReport = null,
                            validationWarnings = emptyList(),
                            validationError = res.reason
                        )
                    }
                }
            }
            val existingUris = _selectedCandidates.value.map { it.uriString }.toSet()
            val deduplicated = inspected.filter { it.uriString !in existingUris }
            _selectedCandidates.value = _selectedCandidates.value + deduplicated
        }
    }

    fun removeCandidate(candidateId: String) {
        _selectedCandidates.value = _selectedCandidates.value.filterNot { it.id == candidateId }
    }

    fun clearSelection() {
        _selectedCandidates.value = emptyList()
    }

    fun updateTargetResolution(target: TargetResolution) {
        viewModelScope.launch {
            container.settingsRepository.updateTargetResolution(target)
        }
    }

    fun updateEnhancementLevel(level: EnhancementLevel) {
        viewModelScope.launch {
            container.settingsRepository.updateEnhancementLevel(level)
        }
    }

    fun updateOutputFormat(format: ImageFormat, jpegQuality: Int) {
        viewModelScope.launch {
            container.settingsRepository.updateOutputFormat(format, jpegQuality)
        }
    }

    fun updateExecutionProvider(provider: ExecutionProviderPreference) {
        viewModelScope.launch {
            container.settingsRepository.updateExecutionProvider(provider)
        }
    }

    fun updateTileSettings(tileSize: Int, overlap: Int) {
        viewModelScope.launch {
            container.settingsRepository.updateTileSettings(tileSize, overlap)
        }
    }

    fun updatePostProcessing(config: PostProcessingConfig) {
        val synced = config.copy(
            denoiseStrength = config.aiNoiseReduction.coerceIn(0f, 1f),
            sharpenAmount = (config.aiSharpnessStrength * 0.50f).coerceIn(0f, 0.50f)
        )
        container.settingsRepository.setPostProcessingImmediate(synced)
        postSaveJob?.cancel()
        postSaveJob = viewModelScope.launch {
            delay(200L)
            container.settingsRepository.updatePostProcessing(synced)
        }
    }

    fun updateUserMetadata(config: UserMetadataConfig) {
        container.settingsRepository.setMetadataImmediate(config)
        metadataSaveJob?.cancel()
        metadataSaveJob = viewModelScope.launch {
            delay(300L)
            container.settingsRepository.updateUserMetadata(config)
        }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            container.settingsRepository.updateThemeMode(mode)
        }
    }

    fun enqueueSelectedBatch(onEnqueued: () -> Unit) {
        val validCandidates = _selectedCandidates.value.filter { it.isValid }
        if (validCandidates.isEmpty()) {
            _statusBannerMessage.value = "Please select at least one valid image before starting."
            return
        }

        viewModelScope.launch {
            val currentSettings = container.settingsRepository.getCurrentSettings()
            container.jobRepository.enqueueBatch(
                candidates = validCandidates,
                targetResolution = currentSettings.defaultTargetResolution,
                enhancementLevel = currentSettings.defaultEnhancementLevel,
                outputFormat = currentSettings.defaultOutputFormat,
                jpegQuality = currentSettings.jpegQuality
            )
            _selectedCandidates.value = emptyList()
            BatchUpscaleWorker.enqueueOrContinueBatch(appContext)
            onEnqueued()
        }
    }

    fun cancelJob(jobId: String) {
        viewModelScope.launch {
            container.jobRepository.cancelJob(jobId)
        }
    }

    fun cancelAllJobs() {
        viewModelScope.launch {
            container.jobRepository.cancelAllActiveAndWaiting()
            BatchUpscaleWorker.cancelBatchWork(appContext)
        }
    }

    fun retryJob(jobId: String) {
        viewModelScope.launch {
            val currentSettings = container.settingsRepository.getCurrentSettings()
            container.jobRepository.retryJob(
                jobId = jobId,
                targetResolution = currentSettings.defaultTargetResolution,
                enhancementLevel = currentSettings.defaultEnhancementLevel,
                outputFormat = currentSettings.defaultOutputFormat,
                jpegQuality = currentSettings.jpegQuality
            )
            BatchUpscaleWorker.enqueueOrContinueBatch(appContext)
        }
    }

    fun deleteHistoryJob(jobId: String) {
        viewModelScope.launch {
            container.jobRepository.deleteJob(jobId)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            container.jobRepository.clearHistory()
        }
    }

    fun focusResultJob(jobId: String) {
        _focusedResultJobId.value = jobId
    }

    fun shareOutput(job: UpscaleJob) {
        val outUri = job.outputUriString ?: return
        try {
            val intent = container.mediaStoreSaver.createShareImageIntent(
                Uri.parse(outUri),
                job.outputFormat.mimeType
            )
            appContext.startActivity(intent)
        } catch (t: Throwable) {
            _statusBannerMessage.value = "Unable to open share chooser: ${t.message}"
        }
    }

    fun openOutput(job: UpscaleJob) {
        val outUri = job.outputUriString ?: return
        try {
            val intent = container.mediaStoreSaver.createOpenImageIntent(
                Uri.parse(outUri),
                job.outputFormat.mimeType
            )
            appContext.startActivity(intent)
        } catch (t: Throwable) {
            _statusBannerMessage.value = "Saved in Gallery (Pictures/CN_Upscaler): ${job.originalFilename}"
        }
    }

    companion object {
        fun provideFactory(app: CnUpscalerApplication): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MainViewModel(app.applicationContext, app.container) as T
                }
            }
    }
}
