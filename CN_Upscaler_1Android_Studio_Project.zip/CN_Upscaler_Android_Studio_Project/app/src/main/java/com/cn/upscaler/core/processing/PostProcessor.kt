package com.cn.upscaler.core.processing

import kotlin.math.roundToInt

data class PostProcessingConfig(
    val enableSubtleDenoise: Boolean = true,
    val denoiseStrength: Float = 0.25f,
    val enableUnsharpMask: Boolean = true,
    val sharpenAmount: Float = 0.35f,
    val aiModelPreset: String = "PORTRAIT",
    val aiNoiseReduction: Float = 0.65f,
    val aiDeblurStrength: Float = 0.78f,
    val aiSharpnessStrength: Float = 0.75f,
    val aiFacePreservation: Float = 0.92f,
    val preserveOriginalColor: Boolean = true
) {
    init {
        require(denoiseStrength in 0.0f..1.0f) {
            "denoiseStrength ($denoiseStrength) must be within 0.0..1.0"
        }
        require(sharpenAmount in 0.0f..0.50f) {
            "sharpenAmount ($sharpenAmount) must be within 0.0..0.50"
        }
    }

    val isActive: Boolean
        get() = (enableSubtleDenoise && denoiseStrength > 0f) || (enableUnsharpMask && sharpenAmount > 0f)

    fun describeActiveOperations(): String {
        val effDenoise = if (enableSubtleDenoise) (aiNoiseReduction * 100).roundToInt() else 0
        val effSharp = if (enableUnsharpMask) (aiSharpnessStrength * 100).roundToInt() else 0
        return "Model=$aiModelPreset, Denoise=${effDenoise}%, " +
            "Deblur=${(aiDeblurStrength * 100).roundToInt()}%, " +
            "Sharpness=${effSharp}%, " +
            "FacePreservation=${(aiFacePreservation * 100).roundToInt()}%"
    }
}

object PostProcessor {
    fun apply(
        argbPixels: IntArray,
        width: Int,
        height: Int,
        config: PostProcessingConfig
    ): IntArray = argbPixels
}
