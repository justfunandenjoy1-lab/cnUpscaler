package com.cn.upscaler.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cn.upscaler.app.MainUiState
import com.cn.upscaler.core.ai.ExecutionProviderPreference
import com.cn.upscaler.core.processing.PostProcessingConfig
import com.cn.upscaler.domain.model.ThemeMode
import kotlin.math.roundToInt

private data class SettingsAiPreset(
    val id: String,
    val label: String,
    val noiseReduction: Float,
    val deblur: Float,
    val sharpness: Float,
    val facePreservation: Float
)

private val SETTINGS_AI_PRESETS = listOf(
    SettingsAiPreset("PORTRAIT", "Portrait & Face", 0.65f, 0.80f, 0.78f, 0.90f),
    SettingsAiPreset("GENERAL", "General Photo", 0.60f, 0.80f, 0.78f, 0.88f),
    SettingsAiPreset("OLD_PHOTO", "Old Photo Restore", 0.82f, 0.82f, 0.72f, 0.90f),
    SettingsAiPreset("LOW_LIGHT", "Low-Light Denoise", 0.92f, 0.68f, 0.58f, 0.90f),
    SettingsAiPreset("LANDSCAPE", "Landscape & Detail", 0.35f, 0.80f, 0.78f, 0.88f),
    SettingsAiPreset("TEXT", "Design, Logo & Text", 0.30f, 0.85f, 0.82f, 0.96f)
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppSettingsScreen(
    uiState: MainUiState,
    onImportModelClick: (String) -> Unit,
    onRefreshModels: () -> Unit,
    onUpdateExecutionProvider: (ExecutionProviderPreference) -> Unit,
    onUpdateTileSettings: (Int, Int) -> Unit,
    onUpdatePostProcessing: (PostProcessingConfig) -> Unit,
    onUpdateThemeMode: (ThemeMode) -> Unit
) {
    val settings = uiState.settings
    val post = settings.postProcessingConfig

    var selectedPreset by remember { mutableStateOf(post.aiModelPreset) }
    var enableDenoise by remember { mutableStateOf(post.enableSubtleDenoise) }
    var enableSharp by remember { mutableStateOf(post.enableUnsharpMask) }
    var noiseSlider by remember { mutableFloatStateOf(post.aiNoiseReduction) }
    var deblurSlider by remember { mutableFloatStateOf(post.aiDeblurStrength) }
    var sharpSlider by remember { mutableFloatStateOf(post.aiSharpnessStrength) }
    var faceSlider by remember { mutableFloatStateOf(post.aiFacePreservation) }

    LaunchedEffect(post) {
        selectedPreset = post.aiModelPreset
        enableDenoise = post.enableSubtleDenoise
        enableSharp = post.enableUnsharpMask
        noiseSlider = post.aiNoiseReduction
        deblurSlider = post.aiDeblurStrength
        sharpSlider = post.aiSharpnessStrength
        faceSlider = post.aiFacePreservation
    }

    fun emitUpdate(
        preset: String = selectedPreset,
        denoiseOn: Boolean = enableDenoise,
        sharpOn: Boolean = enableSharp,
        noise: Float = noiseSlider,
        deblur: Float = deblurSlider,
        sharp: Float = sharpSlider,
        face: Float = faceSlider
    ) {
        onUpdatePostProcessing(
            post.copy(
                enableSubtleDenoise = denoiseOn,
                enableUnsharpMask = sharpOn,
                aiModelPreset = preset,
                aiNoiseReduction = noise.coerceIn(0f, 1f),
                denoiseStrength = noise.coerceIn(0f, 1f),
                aiDeblurStrength = deblur.coerceIn(0f, 1f),
                aiSharpnessStrength = sharp.coerceIn(0f, 1f),
                sharpenAmount = (sharp * 0.50f).coerceIn(0f, 0.50f),
                aiFacePreservation = face.coerceIn(0f, 1f)
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Application & AI Engine Settings", style = MaterialTheme.typography.titleLarge)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("1. AI Model Mode & Quality Controls", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Active Mode: $selectedPreset • v70 Zero-Distortion Configurable Engine (${post.describeActiveOperations()})",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SETTINGS_AI_PRESETS.forEach { preset ->
                        FilterChip(
                            selected = selectedPreset == preset.id,
                            onClick = {
                                selectedPreset = preset.id
                                noiseSlider = preset.noiseReduction
                                deblurSlider = preset.deblur
                                sharpSlider = preset.sharpness
                                faceSlider = preset.facePreservation
                                emitUpdate(
                                    preset = preset.id,
                                    noise = preset.noiseReduction,
                                    deblur = preset.deblur,
                                    sharp = preset.sharpness,
                                    face = preset.facePreservation
                                )
                            },
                            label = { Text(preset.label) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enable Coherent-Bilateral Noise Reduction", fontWeight = FontWeight.Medium)
                    Switch(
                        checked = enableDenoise,
                        onCheckedChange = {
                            enableDenoise = it
                            emitUpdate(denoiseOn = it)
                        }
                    )
                }
                if (enableDenoise) {
                    Text("Noise Reduction (দানাদার নয়েজ কমানো): ${(noiseSlider * 100).roundToInt()}%")
                    Slider(
                        value = noiseSlider,
                        onValueChange = {
                            noiseSlider = it.coerceIn(0f, 1f)
                            emitUpdate(noise = noiseSlider)
                        },
                        valueRange = 0f..1f
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Deblurring & Sub-Pixel IBP Clarity (ঝাপসা ভাব কমানো): ${(deblurSlider * 100).roundToInt()}%",
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = deblurSlider,
                    onValueChange = {
                        deblurSlider = it.coerceIn(0f, 1f)
                        emitUpdate(deblur = deblurSlider)
                    },
                    valueRange = 0f..1f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enable Edge-Aware Sharpness", fontWeight = FontWeight.Medium)
                    Switch(
                        checked = enableSharp,
                        onCheckedChange = {
                            enableSharp = it
                            emitUpdate(sharpOn = it)
                        }
                    )
                }
                if (enableSharp) {
                    Text("Edge-Aware Sharpness (Halo-মুক্ত শার্পনেস): ${(sharpSlider * 100).roundToInt()}%")
                    Slider(
                        value = sharpSlider,
                        onValueChange = {
                            sharpSlider = it.coerceIn(0f, 1f)
                            emitUpdate(sharp = sharpSlider)
                        },
                        valueRange = 0f..1f
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Face, Eye & Hair Identity Preservation (মুখ ও চোখ সংরক্ষণ): ${(faceSlider * 100).roundToInt()}%",
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = faceSlider,
                    onValueChange = {
                        faceSlider = it.coerceIn(0f, 1f)
                        emitUpdate(face = faceSlider)
                    },
                    valueRange = 0f..1f
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("2. Hardware Acceleration & Threading", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExecutionProviderPreference.entries.forEach { pref ->
                        FilterChip(
                            selected = settings.executionProvider == pref,
                            onClick = { onUpdateExecutionProvider(pref) },
                            label = { Text(pref.displayName) }
                        )
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("3. Strip & Tile Memory Control", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Tile / Strip Size: ${settings.tileSize} px", style = MaterialTheme.typography.bodyMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(128, 192, 256, 384, 512).forEach { size ->
                        FilterChip(
                            selected = settings.tileSize == size,
                            onClick = { onUpdateTileSettings(size, settings.tileOverlap) },
                            label = { Text("${size}px") }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Overlap Margin: ${settings.tileOverlap} px", style = MaterialTheme.typography.bodyMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(16, 32, 48).forEach { overlap ->
                        FilterChip(
                            selected = settings.tileOverlap == overlap,
                            onClick = { onUpdateTileSettings(settings.tileSize, overlap) },
                            label = { Text("${overlap}px") }
                        )
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("4. Theme & Appearance", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { onUpdateThemeMode(mode) },
                            label = { Text(mode.label) }
                        )
                    }
                }
            }
        }
    }
}
