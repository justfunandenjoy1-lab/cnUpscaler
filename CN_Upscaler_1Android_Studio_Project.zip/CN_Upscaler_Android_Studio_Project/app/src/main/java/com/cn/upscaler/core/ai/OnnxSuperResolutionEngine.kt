package com.cn.upscaler.core.ai

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import com.cn.upscaler.core.processing.PostProcessingConfig
import java.io.Closeable
import java.nio.FloatBuffer
import java.util.Collections

interface TileSuperResolutionInferenceSession : Closeable {
    val modelSpec: SuperResolutionModelSpec
    val activeProviderReport: ActiveExecutionProviderReport

    fun inferTile(
        argbPixels: IntArray,
        tileWidth: Int,
        tileHeight: Int,
        preserveAlpha: Boolean
    ): IntArray
}

class OnnxSuperResolutionEngine(
    private val verifier: OnnxModelVerifier
) {
    fun openSession(
        preferredModelId: String,
        executionPreference: ExecutionProviderPreference,
        cpuThreads: Int = Runtime.getRuntime().availableProcessors().coerceIn(2, 8),
        postConfig: PostProcessingConfig = PostProcessingConfig()
    ): TileSuperResolutionInferenceSession {
        val availability = verifier.verifyInstalledModels(preferredModelId)
        if (availability !is ModelAvailability.Available) {
            val unavailable = availability as ModelAvailability.Unavailable
            throw IllegalStateException(unavailable.reason)
        }

        val env = OrtEnvironment.getEnvironment()
        val (options, providerReport) = HardwareAcceleratorManager.configureSessionOptions(
            preference = executionPreference,
            cpuThreadCount = cpuThreads
        )

        val session = try {
            env.createSession(availability.modelFile.absolutePath, options)
        } catch (accelError: Throwable) {
            options.close()
            val (cpuOptions, cpuReport) = HardwareAcceleratorManager.configureSessionOptions(
                preference = ExecutionProviderPreference.CPU_ONLY,
                cpuThreadCount = cpuThreads
            )
            val fallbackSession = env.createSession(availability.modelFile.absolutePath, cpuOptions)
            return OrtTileInferenceSession(
                env = env,
                initialSession = fallbackSession,
                initialOptions = cpuOptions,
                modelPath = availability.modelFile.absolutePath,
                cpuThreads = cpuThreads,
                modelSpec = availability.spec,
                inputName = availability.inputTensorName,
                initialProviderReport = cpuReport.copy(
                    requestedPreference = executionPreference,
                    fellBackToCpu = true,
                    fallbackReason = "Driver rejected accelerated graph (${accelError.message}); fell back to CPU."
                ),
                postConfig = postConfig
            )
        }

        return OrtTileInferenceSession(
            env = env,
            initialSession = session,
            initialOptions = options,
            modelPath = availability.modelFile.absolutePath,
            cpuThreads = cpuThreads,
            modelSpec = availability.spec,
            inputName = availability.inputTensorName,
            initialProviderReport = providerReport,
            postConfig = postConfig
        )
    }

    private class OrtTileInferenceSession(
        private val env: OrtEnvironment,
        initialSession: OrtSession,
        initialOptions: OrtSession.SessionOptions,
        private val modelPath: String,
        private val cpuThreads: Int,
        override val modelSpec: SuperResolutionModelSpec,
        private val inputName: String,
        initialProviderReport: ActiveExecutionProviderReport,
        private val postConfig: PostProcessingConfig
    ) : TileSuperResolutionInferenceSession {

        private var session: OrtSession = initialSession
        private var options: OrtSession.SessionOptions = initialOptions
        override var activeProviderReport: ActiveExecutionProviderReport = initialProviderReport
            private set

        override fun inferTile(
            argbPixels: IntArray,
            tileWidth: Int,
            tileHeight: Int,
            preserveAlpha: Boolean
        ): IntArray {
            val prepared = TensorPreprocessor.preprocessTile(
                argbPixels = argbPixels,
                width = tileWidth,
                height = tileHeight,
                spec = modelSpec,
                preserveAlpha = preserveAlpha
            )

            val floatBuffer = FloatBuffer.wrap(prepared.floatData)
            OnnxTensor.createTensor(env, floatBuffer, prepared.tensorShape).use { inputTensor ->
                val outArray = try {
                    runTensorOnce(inputTensor)
                } catch (runError: Throwable) {
                    if (!activeProviderReport.fellBackToCpu &&
                        activeProviderReport.requestedPreference != ExecutionProviderPreference.CPU_ONLY
                    ) {
                        try { session.close() } catch (_: Throwable) {}
                        try { options.close() } catch (_: Throwable) {}
                        val (cpuOpts, cpuRep) = HardwareAcceleratorManager.configureSessionOptions(
                            preference = ExecutionProviderPreference.CPU_ONLY,
                            cpuThreadCount = cpuThreads
                        )
                        options = cpuOpts
                        session = env.createSession(modelPath, cpuOpts)
                        activeProviderReport = cpuRep.copy(
                            requestedPreference = activeProviderReport.requestedPreference,
                            fellBackToCpu = true,
                            fallbackReason = "NNAPI runtime fallback to CPU (${runError.message})"
                        )
                        runTensorOnce(inputTensor)
                    } else {
                        throw runError
                    }
                }

                return TensorPreprocessor.postprocessTile(
                    outputTensorData = outArray,
                    prepared = prepared,
                    spec = modelSpec,
                    postConfig = postConfig
                )
            }
        }

        private fun runTensorOnce(inputTensor: OnnxTensor): FloatArray {
            val actualInput = session.inputNames.firstOrNull() ?: inputName
            session.run(Collections.singletonMap(actualInput, inputTensor)).use { result ->
                val outputValue = result.get(0) as? OnnxTensor
                    ?: throw IllegalStateException("ONNX session did not return an OnnxTensor output.")
                val outFloatBuffer = outputValue.floatBuffer
                val outArray = FloatArray(outFloatBuffer.remaining())
                outFloatBuffer.get(outArray)
                return outArray
            }
        }

        override fun close() {
            try {
                session.close()
            } catch (_: Throwable) {
            }
            try {
                options.close()
            } catch (_: Throwable) {
            }
        }
    }
}
