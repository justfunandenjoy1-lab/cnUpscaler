package com.cn.upscaler.core.processing

import com.cn.upscaler.core.ai.TileSuperResolutionInferenceSession
import kotlin.coroutines.coroutineContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.ensureActive

data class TileConfig(
    val tileSize: Int = 512,
    val overlap: Int = 12
)

data class TileWindow(
    val tileIndex: Int,
    val gridX: Int,
    val gridY: Int,
    val srcX: Int,
    val srcY: Int,
    val srcWidth: Int,
    val srcHeight: Int,
    val dstX: Int,
    val dstY: Int,
    val dstWidth: Int,
    val dstHeight: Int,
    val hasLeftOverlap: Boolean,
    val hasRightOverlap: Boolean,
    val hasTopOverlap: Boolean,
    val hasBottomOverlap: Boolean
)

object TileProcessor {

    private fun safeClampInt(v: Int, lo: Int, hi: Int): Int {
        val actualHi = if (hi < lo) lo else hi
        return when {
            v < lo -> lo
            v > actualHi -> actualHi
            else -> v
        }
    }

    private fun safeClampFloat(v: Float, lo: Float, hi: Float): Float {
        val actualHi = if (hi < lo) lo else hi
        return when {
            v.isNaN() -> lo
            v < lo -> lo
            v > actualHi -> actualHi
            else -> v
        }
    }

    fun computeTileGrid(
        srcWidth: Int,
        srcHeight: Int,
        scale: Int,
        config: TileConfig
    ): List<TileWindow> {
        val safeTile = safeClampInt(config.tileSize, 64, 640)
        val safeOverlap = safeClampInt(config.overlap, 8, safeTile / 3)
        val step = max(16, safeTile - safeOverlap)
        val xStarts = computeAxisStarts(srcWidth, safeTile, step)
        val yStarts = computeAxisStarts(srcHeight, safeTile, step)

        val windows = ArrayList<TileWindow>(xStarts.size * yStarts.size)
        var index = 0
        for ((gy, y0) in yStarts.withIndex()) {
            val th = min(safeTile, srcHeight - y0)
            for ((gx, x0) in xStarts.withIndex()) {
                val tw = min(safeTile, srcWidth - x0)
                windows += TileWindow(
                    tileIndex = index++,
                    gridX = gx,
                    gridY = gy,
                    srcX = x0,
                    srcY = y0,
                    srcWidth = tw,
                    srcHeight = th,
                    dstX = x0 * scale,
                    dstY = y0 * scale,
                    dstWidth = tw * scale,
                    dstHeight = th * scale,
                    hasLeftOverlap = gx > 0 && safeOverlap > 0,
                    hasRightOverlap = gx < xStarts.lastIndex && safeOverlap > 0,
                    hasTopOverlap = gy > 0 && safeOverlap > 0,
                    hasBottomOverlap = gy < yStarts.lastIndex && safeOverlap > 0
                )
            }
        }
        return windows
    }

    private fun computeAxisStarts(length: Int, tileSize: Int, step: Int): List<Int> {
        if (length <= tileSize) return listOf(0)
        val starts = mutableListOf<Int>()
        var pos = 0
        while (pos < length) {
            starts += pos
            if (pos + tileSize >= length) break
            pos += step
        }
        return starts
    }

    fun computeAxisFeatherWeights(
        tileLengthPx: Int,
        overlapPx: Int,
        rampStart: Boolean,
        rampEnd: Boolean
    ): FloatArray {
        val weights = FloatArray(tileLengthPx) { 1.0f }
        if (overlapPx <= 0 || tileLengthPx <= overlapPx * 2) return weights

        if (rampStart) {
            for (i in 0 until overlapPx) {
                val t = (i + 0.5) / overlapPx.toDouble()
                weights[i] = safeClampFloat((0.5 * (1.0 - cos(PI * t))).toFloat(), 1e-4f, 1.0f)
            }
        }
        if (rampEnd) {
            for (i in 0 until overlapPx) {
                val t = (i + 0.5) / overlapPx.toDouble()
                val w = safeClampFloat((0.5 * (1.0 - cos(PI * t))).toFloat(), 1e-4f, 1.0f)
                weights[tileLengthPx - 1 - i] = min(weights[tileLengthPx - 1 - i], w)
            }
        }
        return weights
    }

    suspend fun processTiledImage(
        srcArgb: IntArray,
        srcWidth: Int,
        srcHeight: Int,
        preserveAlpha: Boolean,
        config: TileConfig,
        session: TileSuperResolutionInferenceSession,
        onTileProgress: suspend (completedTiles: Int, totalTiles: Int) -> Unit = { _, _ -> }
    ): IntArray {
        val scale = session.modelSpec.nativeScale
        val outWidth = srcWidth * scale
        val outHeight = srcHeight * scale
        val outSize = outWidth * outHeight

        val safeTile = safeClampInt(config.tileSize, 64, 640)
        val safeOverlap = safeClampInt(config.overlap, 8, safeTile / 3)
        val normConfig = TileConfig(tileSize = safeTile, overlap = safeOverlap)

        val windows = computeTileGrid(srcWidth, srcHeight, scale, normConfig)
        val totalTiles = windows.size

        if (totalTiles == 1) {
            coroutineContext.ensureActive()
            val single = windows.first()
            val outTile = session.inferTile(srcArgb, single.srcWidth, single.srcHeight, preserveAlpha)
            onTileProgress(1, 1)
            return outTile
        }

        val resultArgb = IntArray(outSize)
        val scaledOverlap = safeOverlap * scale
        val rampLut = FloatArray(max(1, scaledOverlap)) { i ->
            if (scaledOverlap <= 0) 1.0f
            else safeClampFloat((0.5 * (1.0 - cos(PI * (i + 0.5) / scaledOverlap.toDouble()))).toFloat(), 0f, 1f)
        }

        for ((idx, win) in windows.withIndex()) {
            coroutineContext.ensureActive()

            val tilePixels = IntArray(win.srcWidth * win.srcHeight)
            for (ty in 0 until win.srcHeight) {
                val srcRowStart = (win.srcY + ty) * srcWidth + win.srcX
                System.arraycopy(srcArgb, srcRowStart, tilePixels, ty * win.srcWidth, win.srcWidth)
            }

            val upscaledTile = session.inferTile(
                argbPixels = tilePixels,
                tileWidth = win.srcWidth,
                tileHeight = win.srcHeight,
                preserveAlpha = preserveAlpha
            )

            for (ty in 0 until win.dstHeight) {
                val dstRowOffset = (win.dstY + ty) * outWidth + win.dstX
                val tileRowOffset = ty * win.dstWidth
                val inTopOverlap = win.hasTopOverlap && ty < scaledOverlap
                val wy = if (inTopOverlap) rampLut[ty] else 1.0f

                if (!inTopOverlap && !win.hasLeftOverlap) {
                    System.arraycopy(upscaledTile, tileRowOffset, resultArgb, dstRowOffset, win.dstWidth)
                } else {
                    for (tx in 0 until win.dstWidth) {
                        val outIdx = dstRowOffset + tx
                        val newPx = upscaledTile[tileRowOffset + tx]
                        val inLeftOverlap = win.hasLeftOverlap && tx < scaledOverlap
                        val wx = if (inLeftOverlap) rampLut[tx] else 1.0f

                        if (!inLeftOverlap && !inTopOverlap) {
                            resultArgb[outIdx] = newPx
                        } else {
                            val wNew = wx * wy
                            val oldPx = resultArgb[outIdx]
                            resultArgb[outIdx] = blendArgbPixels(oldPx, newPx, wNew, preserveAlpha)
                        }
                    }
                }
            }

            onTileProgress(idx + 1, totalTiles)
        }

        coroutineContext.ensureActive()
        return resultArgb
    }

    private fun blendArgbPixels(oldPx: Int, newPx: Int, wNew: Float, preserveAlpha: Boolean): Int {
        val wOld = 1.0f - wNew
        val oldR = (oldPx ushr 16) and 0xFF
        val oldG = (oldPx ushr 8) and 0xFF
        val oldB = oldPx and 0xFF

        val newR = (newPx ushr 16) and 0xFF
        val newG = (newPx ushr 8) and 0xFF
        val newB = newPx and 0xFF

        val r = safeClampInt((oldR * wOld + newR * wNew).roundToInt(), 0, 255)
        val g = safeClampInt((oldG * wOld + newG * wNew).roundToInt(), 0, 255)
        val b = safeClampInt((oldB * wOld + newB * wNew).roundToInt(), 0, 255)
        val a = if (preserveAlpha) {
            val oldA = (oldPx ushr 24) and 0xFF
            val newA = (newPx ushr 24) and 0xFF
            safeClampInt((oldA * wOld + newA * wNew).roundToInt(), 0, 255)
        } else {
            0xFF
        }
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }
}
