package com.cn.upscaler.core.processing

import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.image.ImageFormat
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

enum class TargetResolution(
    val id: String,
    val label: String,
    val shortLabel: String,
    val referenceWidth: Int,
    val referenceHeight: Int
) {
    UHD_2K("2K", "2K+ Stock (2880 × 1620 • 4.7MP)", "2K+ Stock", 2880, 1620),
    UHD_4K("4K", "4K UHD (3840 × 2160 • 8.3MP)", "4K UHD", 3840, 2160),
    UHD_8K("8K", "8K UHD (5760 × 3240 • 18.7MP)", "8K UHD", 5760, 3240),
    UHD_16K("16K", "16K Studio (7680 × 4320 • 33.2MP)", "16K Studio", 7680, 4320);

    companion object {
        fun fromId(id: String): TargetResolution = entries.find { it.id == id } ?: UHD_4K
    }
}

data class ResolutionPlan(
    val sourceWidth: Int,
    val sourceHeight: Int,
    val targetResolution: TargetResolution,
    val outputWidth: Int,
    val outputHeight: Int,
    val geometricScaleRatio: Double,
    val isDownscalingFromSource: Boolean,
    val requiresPostInferenceResize: Boolean,
    val requiresPostInferenceUpscaleBeyondNative4x: Boolean,
    val estimatedOutputPixels: Long,
    val estimatedStorageBytes: Long,
    val estimatedPeakMemoryBytes: Long,
    val exceedsSafeSingleBitmapLimit: Boolean,
    val exceedsMaximumSupportedOutput: Boolean,
    val warnings: List<String>,
    val supportedAlternatives: List<TargetResolution>
)

/*
 * v53 Zero-OOM & Adobe Stock Compliant Resolution Calculator:
 * - Strictly honors the selected TargetResolution bounding box (2K = 4.7 MP, 4K = 8.3 MP,
 *   8K = 18.7 MP, 16K = 33.2 MP) even when the input image is already huge (e.g. 4860x6480 = 31.5 MP),
 *   so minMult never inflates a 31.5 MP input to 96 MP and triggers OutOfMemoryError!
 * - Always guarantees >= 4.2 MP output so every image passes Adobe Stock's 4 MP minimum requirement.
 */
object ResolutionCalculator {

    const val MAX_ABSOLUTE_DIMENSION_PX = 7680
    const val MIN_ADOBE_STOCK_PIXELS = 4_200_000L
    const val MAX_ADOBE_STOCK_PIXELS = 34_000_000L
    const val MAX_SAFE_SINGLE_BITMAP_PIXELS = 36_000_000L
    const val MAX_SUPPORTED_OUTPUT_PIXELS = 40_000_000L

    fun calculate(
        sourceWidth: Int,
        sourceHeight: Int,
        target: TargetResolution,
        outputFormat: ImageFormat = ImageFormat.JPEG,
        nativeModelScale: Int = 4,
        tileSize: Int = 256,
        availableHeapBytes: Long = 512L * 1024L * 1024L,
        @Suppress("UNUSED_PARAMETER")
        enhancementLevel: EnhancementLevel? = null
    ): ResolutionPlan {
        require(sourceWidth > 0 && sourceHeight > 0) {
            "Source dimensions must be strictly positive (got ${sourceWidth}x${sourceHeight})."
        }

        val isPortrait = sourceHeight > sourceWidth
        val boxWidth = if (isPortrait) target.referenceHeight else target.referenceWidth
        val boxHeight = if (isPortrait) target.referenceWidth else target.referenceHeight

        val boxScale = min(
            boxWidth.toDouble() / sourceWidth.toDouble(),
            boxHeight.toDouble() / sourceHeight.toDouble()
        )

        val srcPixels = sourceWidth.toDouble() * sourceHeight.toDouble()
        val minStockScale = sqrt(MIN_ADOBE_STOCK_PIXELS.toDouble() / srcPixels)

        // Dynamic heap-aware pixel ceiling so devices with 256MB-512MB heap never OOM:
        val heapSafeMaxPixels = when {
            availableHeapBytes < 256L * 1024L * 1024L -> 12_500_000L
            availableHeapBytes < 384L * 1024L * 1024L -> 20_000_000L
            else -> MAX_ADOBE_STOCK_PIXELS
        }
        val maxStockScale = sqrt(heapSafeMaxPixels.toDouble() / srcPixels)

        val scale = max(boxScale, minStockScale)
            .coerceAtMost(maxStockScale)
            .coerceAtMost(MAX_ABSOLUTE_DIMENSION_PX.toDouble() / max(sourceWidth, sourceHeight).toDouble())

        val outW = (sourceWidth * scale).roundToInt().coerceIn(1, MAX_ABSOLUTE_DIMENSION_PX)
        val outH = (sourceHeight * scale).roundToInt().coerceIn(1, MAX_ABSOLUTE_DIMENSION_PX)

        val outputPixels = outW.toLong() * outH.toLong()
        val nativeOutW = sourceWidth.toLong() * nativeModelScale
        val nativeOutH = sourceHeight.toLong() * nativeModelScale

        val requiresResizeAfterInference = (outW.toLong() != nativeOutW) || (outH.toLong() != nativeOutH)
        val exceedsNative4x = outW.toLong() > nativeOutW || outH.toLong() > nativeOutH
        val isDownscaleFromSource = outW < sourceWidth || outH < sourceHeight

        val bytesPerPixelStorage = when (outputFormat) {
            ImageFormat.JPEG -> 0.42
            ImageFormat.PNG -> 1.45
            ImageFormat.WEBP -> 0.30
            ImageFormat.UNKNOWN -> 0.42
        }
        val maxCap = when {
            outputPixels <= 5_000_000L  -> 3_500_000L
            outputPixels <= 12_000_000L -> 6_800_000L
            outputPixels <= 24_000_000L -> 10_500_000L
            else                        -> 14_500_000L
        }
        val rawStorage = (outputPixels * bytesPerPixelStorage).toLong().coerceAtLeast(4096L)
        val estimatedStorageBytes = if (outputFormat == ImageFormat.JPEG || outputFormat == ImageFormat.WEBP) {
            minOf(rawStorage, maxCap)
        } else {
            rawStorage
        }

        val outTileSide = tileSize * nativeModelScale
        val tileTensorsBytes = (1L * 3L * tileSize * tileSize * 4L) + (1L * 3L * outTileSide * outTileSide * 4L)
        val outputBufferBytes = outputPixels * 4L
        val sourceBufferBytes = minOf(sourceWidth.toLong() * sourceHeight.toLong() * 4L, 16L * 1024L * 1024L)
        val estimatedPeakMemoryBytes = sourceBufferBytes + tileTensorsBytes + outputBufferBytes

        val exceedsSingleBitmap = outputPixels > MAX_SAFE_SINGLE_BITMAP_PIXELS
        val exceedsMaxOutput = outputPixels > MAX_SUPPORTED_OUTPUT_PIXELS

        val alternatives = TargetResolution.entries.filter { it != target }

        return ResolutionPlan(
            sourceWidth = sourceWidth,
            sourceHeight = sourceHeight,
            targetResolution = target,
            outputWidth = outW,
            outputHeight = outH,
            geometricScaleRatio = scale,
            isDownscalingFromSource = isDownscaleFromSource,
            requiresPostInferenceResize = requiresResizeAfterInference,
            requiresPostInferenceUpscaleBeyondNative4x = exceedsNative4x,
            estimatedOutputPixels = outputPixels,
            estimatedStorageBytes = estimatedStorageBytes,
            estimatedPeakMemoryBytes = estimatedPeakMemoryBytes,
            exceedsSafeSingleBitmapLimit = exceedsSingleBitmap,
            exceedsMaximumSupportedOutput = exceedsMaxOutput,
            warnings = emptyList(),
            supportedAlternatives = alternatives
        )
    }
}
