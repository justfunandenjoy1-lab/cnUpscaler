package com.cn.upscaler.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cn.upscaler.app.MainUiState
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.designsystem.AsyncUriThumbnail
import com.cn.upscaler.core.designsystem.StatusBadge
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.image.SafeBitmapDecoder
import com.cn.upscaler.core.processing.PostProcessingConfig
import com.cn.upscaler.core.processing.TargetResolution
import com.cn.upscaler.domain.model.JobStatus

private data class HomePresetItem(
    val id: String,
    val label: String,
    val noise: Float,
    val deblur: Float,
    val sharp: Float,
    val face: Float
)

private val HOME_AI_PRESETS = listOf(
    HomePresetItem("PORTRAIT", "Portrait & Face", 0.65f, 0.80f, 0.78f, 0.90f),
    HomePresetItem("GENERAL", "General Photo", 0.60f, 0.80f, 0.78f, 0.88f),
    HomePresetItem("OLD_PHOTO", "Old Photo Restore", 0.82f, 0.82f, 0.72f, 0.90f),
    HomePresetItem("LOW_LIGHT", "Low-Light Denoise", 0.92f, 0.68f, 0.58f, 0.90f),
    HomePresetItem("LANDSCAPE", "Landscape & Detail", 0.35f, 0.80f, 0.78f, 0.88f),
    HomePresetItem("TEXT", "Document & Text", 0.45f, 0.88f, 0.85f, 0.88f)
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    uiState: MainUiState,
    bitmapDecoder: SafeBitmapDecoder,
    onAddImagesClick: () -> Unit,
    onSelectTargetResolution: (TargetResolution) -> Unit,
    onSelectEnhancementLevel: (EnhancementLevel) -> Unit,
    onUpdateOutputFormat: (ImageFormat, Int) -> Unit = { _, _ -> },
    onUpdatePostProcessing: (PostProcessingConfig) -> Unit = {},
    onOpenProcessingQueue: () -> Unit,
    onOpenResult: (String) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAbout: () -> Unit
) {
    val post = uiState.settings.postProcessingConfig

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "CN Upscaler",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "v41 True Sub-Pixel Bicubic + Diagonal NEDI + IBP Super-Resolution",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onAddImagesClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Add Images to Upscale", fontWeight = FontWeight.Bold)
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Active AI Engine: ${post.aiModelPreset} Mode (v41.0 Ready)",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "16-Tap Catmull-Rom Bicubic + Diagonal Edge-Directed NEDI + Iterative Back-Projection (IBP) + Target UHD Clarity",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Quick Output & AI Profile Controls", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "1. Target Output Resolution (Final Dimensions):",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    TargetResolution.entries.forEach { target ->
                        FilterChip(
                            selected = uiState.settings.defaultTargetResolution == target,
                            onClick = { onSelectTargetResolution(target) },
                            label = { Text(target.shortLabel) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "2. AI Enhancement Level (Detail Intensity):",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    EnhancementLevel.entries.forEach { level ->
                        FilterChip(
                            selected = uiState.settings.defaultEnhancementLevel == level,
                            onClick = { onSelectEnhancementLevel(level) },
                            enabled = true,
                            label = { Text(level.shortBadge) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "3. AI Scene & Model Mode:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    HOME_AI_PRESETS.forEach { preset ->
                        FilterChip(
                            selected = post.aiModelPreset == preset.id,
                            onClick = {
                                onUpdatePostProcessing(
                                    post.copy(
                                        aiModelPreset = preset.id,
                                        aiNoiseReduction = preset.noise,
                                        aiDeblurStrength = preset.deblur,
                                        aiSharpnessStrength = preset.sharp,
                                        aiFacePreservation = preset.face
                                    )
                                )
                            },
                            label = { Text(preset.label) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "4. Output Format:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    listOf(ImageFormat.JPEG, ImageFormat.PNG, ImageFormat.WEBP).forEach { fmt ->
                        FilterChip(
                            selected = uiState.settings.defaultOutputFormat == fmt,
                            onClick = { onUpdateOutputFormat(fmt, uiState.settings.jpegQuality) },
                            label = { Text(fmt.displayName) }
                        )
                    }
                }
            }
        }

        if (uiState.activeQueue.isNotEmpty()) {
            val activeJob = uiState.activeQueue.firstOrNull { it.status == JobStatus.PROCESSING }
                ?: uiState.activeQueue.first()
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenProcessingQueue() },
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Active Batch Queue (${uiState.activeQueue.size} remaining)",
                            style = MaterialTheme.typography.titleMedium
                        )
                        StatusBadge(activeJob.status)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${activeJob.originalFilename} • ${activeJob.currentStageText}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { activeJob.progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recent Processing Summaries", style = MaterialTheme.typography.titleMedium)
                    OutlinedButton(onClick = onOpenHistory) {
                        Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("All History")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                val recentCompleted = uiState.historyJobs.take(3)
                if (recentCompleted.isEmpty()) {
                    Text(
                        text = "No processed images yet. Tap 'Add Images to Upscale' above to start.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    recentCompleted.forEach { job ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenResult(job.id) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncUriThumbnail(
                                uriString = job.outputUriString ?: job.inputUriString,
                                decoder = bitmapDecoder,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(job.originalFilename, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "${job.originalWidth}×${job.originalHeight} -> ${job.outputWidth ?: "-"}×${job.outputHeight ?: "-"} (${job.targetResolution.shortLabel} • ${job.enhancementLevel.shortBadge})",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusBadge(job.status)
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onOpenSettings,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Settings, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Fine Settings")
            }
            OutlinedButton(
                onClick = onOpenAbout,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Info, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("About & Privacy")
            }
        }
    }
}
