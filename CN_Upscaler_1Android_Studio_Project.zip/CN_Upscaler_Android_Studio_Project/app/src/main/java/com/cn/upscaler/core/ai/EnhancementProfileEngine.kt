package com.cn.upscaler.core.ai

/*
 * CRITICAL DEFINITION:
 * The 4x, 8x, and 16x options are AI Enhancement Levels (processing profiles),
 * NOT geometric width/height multipliers.
 * They never multiply original width or height by 4, 8, or 16; final dimensions are
 * strictly governed by TargetResolution.
 */
enum class EnhancementLevel(
    val id: String,
    val displayName: String,
    val shortBadge: String,
    val technicalSummary: String
) {
    LEVEL_4X(
        id = "ENHANCE_4X",
        displayName = "4× AI Enhancement",
        shortBadge = "4× AI Profile",
        technicalSummary = "Semantic Guided Denoising + 3-Pass Clamped IBP Deconvolution + Studio Vibrance."
    ),
    LEVEL_8X(
        id = "ENHANCE_8X",
        displayName = "8× AI Enhancement",
        shortBadge = "8× AI Profile",
        technicalSummary = "Dual-Branch Semantic Guided Denoising + Curvature-Gated 3-Pass IBP + 3D Local Clarity + Studio Tone & Vibrance."
    ),
    LEVEL_16X(
        id = "ENHANCE_16X",
        displayName = "16× AI Enhancement",
        shortBadge = "16× Studio Pro",
        technicalSummary = "Studio AI Photo Enhancer Master: Semantic Skin/Feature Separation + Curvature-Gated 3-Pass IBP + Dark-Feature Eyelash/Eyebrow Enhancer + 3D Clarity + Studio S-Curve & Vibrance + Exact 2K/4K/8K/16K UHD Fit."
    );

    companion object {
        fun fromId(id: String): EnhancementLevel = entries.find { it.id == id } ?: LEVEL_4X
    }
}

data class ModelCapabilities(
    val primaryModelAvailable: Boolean,
    val primaryModelId: String,
    val primaryModelName: String,
    val primaryModelVersion: String,
    val primaryNativeScale: Int,
    val secondaryRefinementModelAvailable: Boolean,
    val secondaryModelId: String?,
    val supportsMultiPass8xProfile: Boolean,
    val supportsExtreme16xProfile: Boolean
)

sealed interface EnhancementStrategy {
    val level: EnhancementLevel
    val isSupported: Boolean
    val stagesDescription: String
    val limitationNotice: String?

    data class SinglePassEnhancementStrategy(
        override val level: EnhancementLevel = EnhancementLevel.LEVEL_4X,
        val modelId: String,
        val modelName: String,
        val modelVersion: String,
        val nativeScale: Int = 4
    ) : EnhancementStrategy {
        override val isSupported: Boolean = true
        override val stagesDescription: String =
            "Stage 1: Semantic Guided Denoising -> Stage 2: Curvature-Gated 3-Pass IBP Deconvolution -> Stage 3: Exact Target Resolution UHD Fit"
        override val limitationNotice: String? = null
    }

    data class MultiPassEnhancementStrategy(
        override val level: EnhancementLevel = EnhancementLevel.LEVEL_8X,
        val firstPassModelId: String,
        val secondPassModelId: String,
        val modelName: String,
        val modelVersion: String,
        val intermediateDownsampleFactor: Float = 0.5f
    ) : EnhancementStrategy {
        override val isSupported: Boolean = true
        override val stagesDescription: String =
            if (level == EnhancementLevel.LEVEL_16X) {
                "Stage 1: Semantic Skin/Feature Guided Denoising -> Stage 2: Curvature-Gated 3-Pass IBP + Dark-Feature Eyelash/Eyebrow Boost -> Stage 3: 3D Local Clarity + Studio S-Curve & Vibrance -> Stage 4: Adaptive Band-Streaming Exact 2K/4K/8K/16K UHD Master"
            } else {
                "Stage 1: Semantic Skin/Feature Guided Denoising -> Stage 2: Curvature-Gated 3-Pass IBP -> Stage 3: 3D Local Clarity & Vibrance -> Stage 4: Exact Target UHD Fit"
            }
        override val limitationNotice: String =
            if (level == EnhancementLevel.LEVEL_16X) {
                "16× Studio Pro executes Curvature-Gated 3-Pass IBP Deconvolution, Dark-Feature Eyelash/Eyebrow Enhancement, 3D Local Clarity, and Studio Vibrance with adaptive band-streaming for exact 2K/4K/8K/16K UHD output."
            } else {
                "8× AI Profile executes Curvature-Gated 3-Pass IBP Deconvolution and 3D Local Clarity while final pixel dimensions remain governed by Target Resolution."
            }
    }

    data class UnsupportedEnhancementStrategy(
        override val level: EnhancementLevel,
        val reason: String
    ) : EnhancementStrategy {
        override val isSupported: Boolean = false
        override val stagesDescription: String = "Unavailable ($reason)"
        override val limitationNotice: String = reason
    }
}

data class EnhancementProfile(
    val level: EnhancementLevel,
    val strategy: EnhancementStrategy
) {
    val isAvailable: Boolean get() = strategy.isSupported
}

class EnhancementProfileResolver {

    fun resolveProfiles(capabilities: ModelCapabilities): List<EnhancementProfile> {
        return EnhancementLevel.entries.map { level ->
            resolveProfile(level, capabilities)
        }
    }

    fun resolveProfile(
        level: EnhancementLevel,
        capabilities: ModelCapabilities
    ): EnhancementProfile {
        if (!capabilities.primaryModelAvailable) {
            return EnhancementProfile(
                level = level,
                strategy = EnhancementStrategy.UnsupportedEnhancementStrategy(
                    level = level,
                    reason = "No verified super-resolution engine is available."
                )
            )
        }

        return when (level) {
            EnhancementLevel.LEVEL_4X -> EnhancementProfile(
                level = level,
                strategy = EnhancementStrategy.SinglePassEnhancementStrategy(
                    level = level,
                    modelId = capabilities.primaryModelId,
                    modelName = capabilities.primaryModelName,
                    modelVersion = capabilities.primaryModelVersion,
                    nativeScale = capabilities.primaryNativeScale
                )
            )

            EnhancementLevel.LEVEL_8X -> EnhancementProfile(
                level = level,
                strategy = EnhancementStrategy.MultiPassEnhancementStrategy(
                    level = level,
                    firstPassModelId = capabilities.primaryModelId,
                    secondPassModelId = capabilities.secondaryModelId ?: capabilities.primaryModelId,
                    modelName = capabilities.primaryModelName,
                    modelVersion = capabilities.primaryModelVersion
                )
            )

            EnhancementLevel.LEVEL_16X -> EnhancementProfile(
                level = level,
                strategy = EnhancementStrategy.MultiPassEnhancementStrategy(
                    level = level,
                    firstPassModelId = capabilities.primaryModelId,
                    secondPassModelId = capabilities.secondaryModelId ?: capabilities.primaryModelId,
                    modelName = capabilities.primaryModelName,
                    modelVersion = capabilities.primaryModelVersion,
                    intermediateDownsampleFactor = 1.0f
                )
            )
        }
    }
}
