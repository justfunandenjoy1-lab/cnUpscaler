package com.cn.upscaler.core.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.cn.upscaler.core.common.AppResult
import com.cn.upscaler.core.common.ErrorCode
import com.cn.upscaler.core.common.MemoryBudgetMonitor

class SafeBitmapDecoder(
    private val context: Context,
    private val memoryMonitor: MemoryBudgetMonitor
) {
    fun decodeForProcessing(
        uri: Uri,
        report: ImageInspectionReport
    ): AppResult<Bitmap> {
        return try {
            // Preserve 100% full 1x native resolution on all images up to 4096x4096 (16.7 MP)
            // so 2752x1536 (4.2 MP) is decoded with inSampleSize = 1 (zero pixel loss!)
            val sampleSize = calculateInSampleSize(
                rawWidth = report.rawWidth,
                rawHeight = report.rawHeight,
                reqWidth = 4096,
                reqHeight = 4096
            )
            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inMutable = true
                inDither = false
                inScaled = false
                inSampleSize = sampleSize
            }
            val rawBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            } ?: return AppResult.Error(
                message = "Unable to decode bitmap stream for ${report.filename}.",
                errorCode = ErrorCode.CORRUPTED_IMAGE
            )

            val oriented = ExifOrientationHelper.applyOrientation(rawBitmap, report.exifOrientation)
            AppResult.Success(oriented)
        } catch (oom: OutOfMemoryError) {
            System.gc()
            try {
                val fallbackSample = (calculateInSampleSize(report.rawWidth, report.rawHeight, 2048, 2048) * 2).coerceAtLeast(2)
                val fallbackOpts = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                    inMutable = true
                    inDither = false
                    inScaled = false
                    inSampleSize = fallbackSample
                }
                val rawFallback = context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, fallbackOpts)
                } ?: return AppResult.Error(
                    message = "Out of memory while decoding ${report.filename}.",
                    cause = oom,
                    errorCode = ErrorCode.INSUFFICIENT_MEMORY
                )
                val orientedFallback = ExifOrientationHelper.applyOrientation(rawFallback, report.exifOrientation)
                AppResult.Success(orientedFallback)
            } catch (oom2: OutOfMemoryError) {
                System.gc()
                AppResult.Error(
                    message = "Out of memory while decoding ${report.filename}.",
                    cause = oom2,
                    errorCode = ErrorCode.INSUFFICIENT_MEMORY
                )
            }
        } catch (t: Throwable) {
            AppResult.Error(
                message = "Failed to decode ${report.filename}: ${t.message}",
                cause = t,
                errorCode = ErrorCode.CORRUPTED_IMAGE
            )
        }
    }

    fun decodeThumbnail(
        uri: Uri,
        maxDimensionPx: Int = 512
    ): AppResult<Bitmap> {
        return try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOpts)
            } ?: return AppResult.Error(
                message = "Unable to open thumbnail stream.",
                errorCode = ErrorCode.FILE_NOT_FOUND
            )

            if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) {
                return AppResult.Error(
                    message = "Invalid thumbnail dimensions.",
                    errorCode = ErrorCode.INVALID_DIMENSIONS
                )
            }

            val sampleSize = calculateInSampleSize(
                rawWidth = boundsOpts.outWidth,
                rawHeight = boundsOpts.outHeight,
                reqWidth = maxDimensionPx,
                reqHeight = maxDimensionPx
            )
            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inDither = false
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val raw = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: return AppResult.Error(
                message = "Failed to decode thumbnail bitmap.",
                errorCode = ErrorCode.CORRUPTED_IMAGE
            )

            val exif = try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    ExifInterface(stream).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL
                    )
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (_: Throwable) {
                ExifInterface.ORIENTATION_NORMAL
            }

            val oriented = ExifOrientationHelper.applyOrientation(raw, exif)
            AppResult.Success(oriented)
        } catch (oom: OutOfMemoryError) {
            System.gc()
            AppResult.Error(
                message = "Out of memory decoding thumbnail.",
                cause = oom,
                errorCode = ErrorCode.INSUFFICIENT_MEMORY
            )
        } catch (t: Throwable) {
            AppResult.Error(
                message = "Thumbnail error: ${t.message}",
                cause = t,
                errorCode = ErrorCode.UNKNOWN
            )
        }
    }

    companion object {
        fun calculateInSampleSize(
            rawWidth: Int,
            rawHeight: Int,
            reqWidth: Int,
            reqHeight: Int
        ): Int {
            var inSampleSize = 1
            val maxDim = maxOf(rawWidth, rawHeight)
            val reqMax = maxOf(reqWidth, reqHeight)
            while ((maxDim / inSampleSize) > reqMax) {
                inSampleSize *= 2
            }
            return inSampleSize.coerceAtLeast(1)
        }
    }
}
