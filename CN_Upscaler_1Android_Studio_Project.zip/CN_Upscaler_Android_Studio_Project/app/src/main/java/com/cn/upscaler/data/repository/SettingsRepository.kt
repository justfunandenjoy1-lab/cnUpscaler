package com.cn.upscaler.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.cn.upscaler.core.ai.EnhancementLevel
import com.cn.upscaler.core.ai.ExecutionProviderPreference
import com.cn.upscaler.core.ai.SupportedModelCatalog
import com.cn.upscaler.core.image.ImageFormat
import com.cn.upscaler.core.metadata.UserMetadataConfig
import com.cn.upscaler.core.processing.PostProcessingConfig
import com.cn.upscaler.core.processing.TargetResolution
import com.cn.upscaler.domain.model.AppSettings
import com.cn.upscaler.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "cn_upscaler_settings")

class SettingsRepository(
    private val context: Context
) {
    private object Keys {
        val TARGET_RESOLUTION = stringPreferencesKey("default_target_resolution_v82")
        val ENHANCEMENT_LEVEL = stringPreferencesKey("default_enhancement_level_v82")
        val OUTPUT_FORMAT = stringPreferencesKey("default_output_format_v82")
        val JPEG_QUALITY = intPreferencesKey("jpeg_quality_v82")
        val PREFERRED_MODEL_ID = stringPreferencesKey("preferred_model_id_v82")
        val EXECUTION_PROVIDER = stringPreferencesKey("execution_provider_v82")
        val TILE_SIZE = intPreferencesKey("tile_size_v82")
        val TILE_OVERLAP_INT = intPreferencesKey("tile_overlap_v82")
        val ENABLE_MULTIPASS_8X = booleanPreferencesKey("enable_multipass_8x_v82")
        val ENABLE_DENOISE = booleanPreferencesKey("enable_denoise_v82")
        val DENOISE_STRENGTH = floatPreferencesKey("denoise_strength_v82")
        val ENABLE_SHARPEN = booleanPreferencesKey("enable_sharpen_v82")
        val SHARPEN_AMOUNT = floatPreferencesKey("sharpen_amount_v82")
        val AI_MODEL_PRESET = stringPreferencesKey("ai_model_preset_v82")
        val AI_NOISE_REDUCTION = floatPreferencesKey("ai_noise_reduction_v82")
        val AI_DEBLUR_STRENGTH = floatPreferencesKey("ai_deblur_strength_v82")
        val AI_SHARPNESS_STRENGTH = floatPreferencesKey("ai_sharpness_strength_v82")
        val AI_FACE_PRESERVATION = floatPreferencesKey("ai_face_preservation_v82")
        val PRESERVE_ORIGINAL_COLOR = booleanPreferencesKey("preserve_original_color_v82")
        val META_TITLE = stringPreferencesKey("meta_title")
        val META_AUTHOR = stringPreferencesKey("meta_author")
        val META_DESCRIPTION = stringPreferencesKey("meta_description")
        val META_KEYWORDS = stringPreferencesKey("meta_keywords")
        val META_COPYRIGHT = stringPreferencesKey("meta_copyright")
        val PRESERVE_ORIGINAL_EXIF = booleanPreferencesKey("preserve_original_exif")
        val STRIP_SENSITIVE_GPS = booleanPreferencesKey("strip_sensitive_gps")
        val THEME_MODE = stringPreferencesKey("theme_mode")
    }

    private val inMemoryMetadataOverride = MutableStateFlow<UserMetadataConfig?>(null)
    private val inMemoryPostOverride = MutableStateFlow<PostProcessingConfig?>(null)

    private val diskSettingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            defaultTargetResolution = TargetResolution.fromId(
                prefs[Keys.TARGET_RESOLUTION] ?: TargetResolution.UHD_4K.id
            ),
            defaultEnhancementLevel = EnhancementLevel.fromId(
                prefs[Keys.ENHANCEMENT_LEVEL] ?: EnhancementLevel.LEVEL_8X.id
            ),
            defaultOutputFormat = runCatching {
                ImageFormat.valueOf(prefs[Keys.OUTPUT_FORMAT] ?: ImageFormat.JPEG.name)
            }.getOrDefault(ImageFormat.JPEG),
            jpegQuality = (prefs[Keys.JPEG_QUALITY] ?: 95).coerceIn(70, 100),
            preferredModelId = prefs[Keys.PREFERRED_MODEL_ID] ?: SupportedModelCatalog.REAL_ESR_GENERAL_X4_V3.id,
            executionProvider = ExecutionProviderPreference.fromId(
                prefs[Keys.EXECUTION_PROVIDER] ?: ExecutionProviderPreference.AUTO.id
            ),
            tileSize = (prefs[Keys.TILE_SIZE] ?: 512).coerceIn(128, 512),
            tileOverlap = (prefs[Keys.TILE_OVERLAP_INT] ?: 12).coerceIn(12, 64),
            enableMultiPass8x = prefs[Keys.ENABLE_MULTIPASS_8X] ?: true,
            postProcessingConfig = PostProcessingConfig(
                enableSubtleDenoise = prefs[Keys.ENABLE_DENOISE] ?: true,
                denoiseStrength = (prefs[Keys.DENOISE_STRENGTH] ?: 0.30f).coerceIn(0f, 1f),
                enableUnsharpMask = prefs[Keys.ENABLE_SHARPEN] ?: true,
                sharpenAmount = (prefs[Keys.SHARPEN_AMOUNT] ?: 0.38f).coerceIn(0f, 0.50f),
                aiModelPreset = prefs[Keys.AI_MODEL_PRESET] ?: "PORTRAIT",
                aiNoiseReduction = (prefs[Keys.AI_NOISE_REDUCTION] ?: 0.70f).coerceIn(0f, 1f),
                aiDeblurStrength = (prefs[Keys.AI_DEBLUR_STRENGTH] ?: 0.80f).coerceIn(0f, 1f),
                aiSharpnessStrength = (prefs[Keys.AI_SHARPNESS_STRENGTH] ?: 0.78f).coerceIn(0f, 1f),
                aiFacePreservation = (prefs[Keys.AI_FACE_PRESERVATION] ?: 0.95f).coerceIn(0f, 1f),
                preserveOriginalColor = prefs[Keys.PRESERVE_ORIGINAL_COLOR] ?: true
            ),
            userMetadataConfig = UserMetadataConfig(
                title = prefs[Keys.META_TITLE].orEmpty(),
                author = prefs[Keys.META_AUTHOR].orEmpty(),
                description = prefs[Keys.META_DESCRIPTION].orEmpty(),
                keywords = prefs[Keys.META_KEYWORDS].orEmpty(),
                copyright = prefs[Keys.META_COPYRIGHT].orEmpty(),
                preserveSafeOriginalExif = prefs[Keys.PRESERVE_ORIGINAL_EXIF] ?: true,
                stripSensitiveLocationMetadata = prefs[Keys.STRIP_SENSITIVE_GPS] ?: true
            ),
            themeMode = ThemeMode.fromId(prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.id)
        )
    }

    val settingsFlow: Flow<AppSettings> = combine(
        diskSettingsFlow,
        inMemoryMetadataOverride,
        inMemoryPostOverride
    ) { diskSettings, metaOverride, postOverride ->
        var current = diskSettings
        if (metaOverride != null) current = current.copy(userMetadataConfig = metaOverride)
        if (postOverride != null) current = current.copy(postProcessingConfig = postOverride)
        current
    }

    suspend fun getCurrentSettings(): AppSettings {
        var current = diskSettingsFlow.first()
        inMemoryMetadataOverride.value?.let { current = current.copy(userMetadataConfig = it) }
        inMemoryPostOverride.value?.let { current = current.copy(postProcessingConfig = it) }
        return current
    }

    fun setMetadataImmediate(config: UserMetadataConfig) {
        inMemoryMetadataOverride.value = config
    }

    fun setPostProcessingImmediate(config: PostProcessingConfig) {
        inMemoryPostOverride.value = config
    }

    suspend fun updateTargetResolution(target: TargetResolution) {
        context.dataStore.edit { it[Keys.TARGET_RESOLUTION] = target.id }
    }

    suspend fun updateEnhancementLevel(level: EnhancementLevel) {
        context.dataStore.edit { it[Keys.ENHANCEMENT_LEVEL] = level.id }
    }

    suspend fun updateOutputFormat(format: ImageFormat, jpegQuality: Int) {
        context.dataStore.edit {
            it[Keys.OUTPUT_FORMAT] = format.name
            it[Keys.JPEG_QUALITY] = jpegQuality.coerceIn(70, 100)
        }
    }

    suspend fun updateExecutionProvider(provider: ExecutionProviderPreference) {
        context.dataStore.edit { it[Keys.EXECUTION_PROVIDER] = provider.id }
    }

    suspend fun updateTileSettings(tileSize: Int, overlap: Int) {
        context.dataStore.edit {
            it[Keys.TILE_SIZE] = tileSize.coerceIn(128, 512)
            it[Keys.TILE_OVERLAP_INT] = overlap.coerceIn(12, (tileSize / 3).coerceAtMost(64))
        }
    }

    suspend fun updatePreferredModel(modelId: String) {
        context.dataStore.edit { it[Keys.PREFERRED_MODEL_ID] = modelId }
    }

    suspend fun updatePostProcessing(config: PostProcessingConfig) {
        inMemoryPostOverride.value = config
        context.dataStore.edit {
            it[Keys.ENABLE_DENOISE] = config.enableSubtleDenoise
            it[Keys.DENOISE_STRENGTH] = config.denoiseStrength.coerceIn(0f, 1f)
            it[Keys.ENABLE_SHARPEN] = config.enableUnsharpMask
            it[Keys.SHARPEN_AMOUNT] = config.sharpenAmount.coerceIn(0f, 0.50f)
            it[Keys.AI_MODEL_PRESET] = config.aiModelPreset
            it[Keys.AI_NOISE_REDUCTION] = config.aiNoiseReduction.coerceIn(0f, 1f)
            it[Keys.AI_DEBLUR_STRENGTH] = config.aiDeblurStrength.coerceIn(0f, 1f)
            it[Keys.AI_SHARPNESS_STRENGTH] = config.aiSharpnessStrength.coerceIn(0f, 1f)
            it[Keys.AI_FACE_PRESERVATION] = config.aiFacePreservation.coerceIn(0f, 1f)
            it[Keys.PRESERVE_ORIGINAL_COLOR] = config.preserveOriginalColor
        }
    }

    suspend fun updateUserMetadata(config: UserMetadataConfig) {
        inMemoryMetadataOverride.value = config
        context.dataStore.edit {
            it[Keys.META_TITLE] = config.title
            it[Keys.META_AUTHOR] = config.author
            it[Keys.META_DESCRIPTION] = config.description
            it[Keys.META_KEYWORDS] = config.keywords
            it[Keys.META_COPYRIGHT] = config.copyright
            it[Keys.PRESERVE_ORIGINAL_EXIF] = config.preserveSafeOriginalExif
            it[Keys.STRIP_SENSITIVE_GPS] = config.stripSensitiveLocationMetadata
        }
    }

    suspend fun updateThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.id }
    }
}
