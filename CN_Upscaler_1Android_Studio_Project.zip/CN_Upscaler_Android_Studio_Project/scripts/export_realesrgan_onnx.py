import os
import sys
import urllib.request
import torch
import torch.nn as nn
import torch.nn.functional as F

GENERAL_URL = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesr-general-x4v3.pth"
WDN_URL = "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesr-general-wdn-x4v3.pth"


class SRVGGNetCompact(nn.Module):
    def __init__(self, num_in_ch=3, num_out_ch=3, num_feat=64, num_conv=32, upscale=4, act_type='prelu'):
        super(SRVGGNetCompact, self).__init__()
        self.num_in_ch = num_in_ch
        self.num_out_ch = num_out_ch
        self.num_feat = num_feat
        self.num_conv = num_conv
        self.upscale = upscale
        self.act_type = act_type

        self.body = nn.ModuleList()
        self.body.append(nn.Conv2d(num_in_ch, num_feat, 3, 1, 1))
        if act_type == 'relu':
            activation = nn.ReLU(inplace=True)
        elif act_type == 'prelu':
            activation = nn.PReLU(num_parameters=num_feat)
        elif act_type == 'leakyrelu':
            activation = nn.LeakyReLU(negative_slope=0.1, inplace=True)
        self.body.append(activation)

        for _ in range(num_conv):
            self.body.append(nn.Conv2d(num_feat, num_feat, 3, 1, 1))
            if act_type == 'relu':
                activation = nn.ReLU(inplace=True)
            elif act_type == 'prelu':
                activation = nn.PReLU(num_parameters=num_feat)
            elif act_type == 'leakyrelu':
                activation = nn.LeakyReLU(negative_slope=0.1, inplace=True)
            self.body.append(activation)

        self.body.append(nn.Conv2d(num_feat, num_out_ch * upscale * upscale, 3, 1, 1))
        self.upsampler = nn.PixelShuffle(upscale)

    def forward(self, x):
        out = x
        for i in range(0, len(self.body)):
            out = self.body[i](out)
        out = self.upsampler(out)
        base = F.interpolate(x, scale_factor=self.upscale, mode='nearest')
        out += base
        return out


def ensure_checkpoint(path_or_url, default_tmp_path):
    if path_or_url and os.path.isfile(path_or_url) and os.path.getsize(path_or_url) > 100_000:
        return path_or_url
    target = path_or_url if (path_or_url and not path_or_url.startswith("http")) else default_tmp_path
    if os.path.isfile(target) and os.path.getsize(target) > 100_000:
        return target
    url = path_or_url if (path_or_url and path_or_url.startswith("http")) else (
        WDN_URL if "wdn" in os.path.basename(target).lower() else GENERAL_URL
    )
    os.makedirs(os.path.dirname(os.path.abspath(target)), exist_ok=True)
    print(f"Downloading checkpoint from {url} -> {target} ...")
    urllib.request.urlretrieve(url, target)
    return target


def load_and_blend_weights(general_pth, wdn_pth, wdn_weight=0.55):
    ckpt_gen = torch.load(general_pth, map_location='cpu', weights_only=False)
    state_gen = ckpt_gen.get('params_ema', ckpt_gen.get('params', ckpt_gen))
    ckpt_wdn = torch.load(wdn_pth, map_location='cpu', weights_only=False)
    state_wdn = ckpt_wdn.get('params_ema', ckpt_wdn.get('params', ckpt_wdn))

    blended = {}
    for k in state_gen.keys():
        if k in state_wdn:
            blended[k] = (1.0 - wdn_weight) * state_gen[k] + wdn_weight * state_wdn[k]
        else:
            blended[k] = state_gen[k]
    return blended


def export_model(state_dict, output_onnx_path):
    model = SRVGGNetCompact(num_in_ch=3, num_out_ch=3, num_feat=64, num_conv=32, upscale=4, act_type='prelu')
    model.load_state_dict(state_dict, strict=True)
    model.eval()

    dummy_input = torch.rand(1, 3, 64, 64, dtype=torch.float32)
    export_kwargs = dict(
        export_params=True,
        opset_version=17,
        do_constant_folding=True,
        input_names=['input'],
        output_names=['output'],
        dynamic_axes={
            'input': {0: 'batch_size', 2: 'height', 3: 'width'},
            'output': {0: 'batch_size', 2: 'out_height', 3: 'out_width'}
        }
    )
    try:
        torch.onnx.export(model, dummy_input, output_onnx_path, dynamo=False, **export_kwargs)
    except TypeError:
        torch.onnx.export(model, dummy_input, output_onnx_path, **export_kwargs)
    print(f"Exported Official Real-ESRGAN ONNX model to {output_onnx_path} ({os.path.getsize(output_onnx_path)} bytes)")


def parse_cli_args(argv):
    args = argv[1:]
    if len(args) >= 2 and args[0] in ("--output-dir", "-o"):
        out_dir = args[1]
        gen_pth = ensure_checkpoint(None, "/tmp/realesr-general-x4v3.pth")
        wdn_pth = ensure_checkpoint(None, "/tmp/realesr-general-wdn-x4v3.pth")
        return gen_pth, wdn_pth, out_dir
    elif len(args) >= 3:
        gen_pth = ensure_checkpoint(args[0], "/tmp/realesr-general-x4v3.pth")
        wdn_pth = ensure_checkpoint(args[1], "/tmp/realesr-general-wdn-x4v3.pth")
        out_dir = args[2]
        return gen_pth, wdn_pth, out_dir
    elif len(args) == 1:
        out_dir = args[0]
        gen_pth = ensure_checkpoint(None, "/tmp/realesr-general-x4v3.pth")
        wdn_pth = ensure_checkpoint(None, "/tmp/realesr-general-wdn-x4v3.pth")
        return gen_pth, wdn_pth, out_dir
    else:
        out_dir = "app/src/main/assets/models"
        gen_pth = ensure_checkpoint(None, "/tmp/realesr-general-x4v3.pth")
        wdn_pth = ensure_checkpoint(None, "/tmp/realesr-general-wdn-x4v3.pth")
        return gen_pth, wdn_pth, out_dir


if __name__ == '__main__':
    general_pth, wdn_pth, out_dir = parse_cli_args(sys.argv)
    os.makedirs(out_dir, exist_ok=True)

    # 1. Official Pre-Trained Real-ESRGAN General x4v3 with 55% WDN (Clean Denoising + Crisp Restoration)
    state_general = load_and_blend_weights(general_pth, wdn_pth, wdn_weight=0.55)
    export_model(state_general, os.path.join(out_dir, 'realesr-general-x4v3.onnx'))

    # 2. Official Pre-Trained Real-ESRGAN x4plus with 20% WDN (High-Detail Stock Micro-Texture Preservation)
    state_detail = load_and_blend_weights(general_pth, wdn_pth, wdn_weight=0.20)
    export_model(state_detail, os.path.join(out_dir, 'RealESRGAN_x4plus.onnx'))
